# Foodyo - Pi Network Food Delivery App

A modern food delivery application built with Next.js and integrated with Pi Network for payments and authentication.

## Features

- 🍕 Browse restaurants and menus
- 🛒 Shopping cart functionality
- 🔐 Pi Network authentication
- 💳 Pi Network payments (ready for integration)
- 📱 Mobile-responsive design
- 🎨 Modern UI with Tailwind CSS

## Pi Network Integration

This app is configured for **Pi Testnet**. It includes:

- Pi SDK authentication
- Automatic sandbox mode detection
- Payment capabilities (can be enabled)
- User authentication via Pi accounts

## Deployment Instructions

### 1. Deploy to Vercel

#### Option A: Direct Upload
1. Download the ZIP file
2. Go to [vercel.com](https://vercel.com)
3. Sign up/login (free account)
4. Click "Add New Project"
5. Upload the ZIP file
6. Click "Deploy"
7. Copy your production URL (e.g., `https://foodyo-xyz.vercel.app`)

#### Option B: GitHub
1. Push code to GitHub repository
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your GitHub repository
5. Click "Deploy"
6. Copy your production URL

### 2. Configure in Pi Developer Portal

1. Go to [developers.pi.network](https://developers.pi.network)
2. Login with your Pi account
3. Find or create your Foodyo app
4. In Settings, add your production URL
5. Select **"Pi Testnet"** as network
6. Save changes

### 3. Test in Pi Browser

1. Open **Pi Browser** app on your phone
2. Go to **Pi Utilities** → **Your Apps**
3. Open **Foodyo**
4. Test login with "Sign in with Pi Network"
5. Approve authentication
6. Start ordering food!

## Local Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Open http://localhost:3000
```

For local testing with Pi SDK:
1. Set your development URL in Pi Developer Portal
2. Authorize sandbox mode in Pi Browser
3. The app will auto-detect localhost and enable sandbox mode

## Environment Variables

No environment variables required for basic Pi authentication.
The app auto-detects sandbox mode based on hostname.

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS v4
- **UI Components**: shadcn/ui
- **Authentication**: Pi Network SDK
- **State Management**: React Context API
- **Payments**: Pi Network (ready to integrate)

## Demo Data

The app includes:
- 10 pre-approved restaurants
- 100 food items with images
- Multiple categories (Pizza, Burgers, BBQ, Desserts, etc.)

## Support

For issues:
- Pi Network Integration: [pi-apps documentation](https://pi-apps.github.io/community-developer-guide/)
- Deployment: [Vercel Support](https://vercel.com/help)
- App Issues: Check browser console for Pi SDK logs

## Next Steps

1. ✅ Deploy to production
2. ✅ Add to Pi Developer Portal
3. ✅ Test in Pi Browser
4. Complete Pi Testnet checklist
5. Apply for Mainnet migration
6. Claim foodyo.pi domain

---

Built with ❤️ for the Pi Network community
```

```json file="" isHidden
