"use client"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useCart } from "@/lib/cart-context"
import { SignInPrompt } from "./sign-in-prompt"

const dishes = [
  {
    id: "popular-1",
    name: "Margherita Pizza",
    restaurant: "Bella Italia",
    rating: 4.6,
    price: 12.99,
    image: "/placeholder.svg?height=200&width=200",
    badge: "Popular",
  },
  {
    id: "popular-2",
    name: "Salmon Sushi Roll",
    restaurant: "Sushi Master",
    rating: 4.8,
    price: 15.99,
    image: "/placeholder.svg?height=200&width=200",
    badge: "New",
  },
  {
    id: "popular-3",
    name: "Caesar Salad",
    restaurant: "Green Bowl",
    rating: 4.5,
    price: 9.99,
    image: "/placeholder.svg?height=200&width=200",
    badge: "Popular",
  },
  {
    id: "popular-4",
    name: "Beef Burger",
    restaurant: "Burger House",
    rating: 4.7,
    price: 13.99,
    image: "/placeholder.svg?height=200&width=200",
    badge: "Popular",
  },
]

export function PopularDishes() {
  const { isGuest } = useAuth()
  const { addToCart, addToFavorites } = useCart()
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)

  const handleFavoriteClick = (dish: (typeof dishes)[0]) => {
    if (isGuest) {
      setShowSignInPrompt(true)
    } else {
      addToFavorites({
        id: dish.id,
        name: dish.name,
        restaurant: dish.restaurant,
        price: dish.price,
        image: dish.image,
        description: `${dish.restaurant} • ${dish.rating} ⭐`,
      })
    }
  }

  const handleDishClick = (dish: (typeof dishes)[0]) => {
    if (isGuest) {
      setShowSignInPrompt(true)
    } else {
      addToCart({
        id: dish.id,
        name: dish.name,
        restaurant: dish.restaurant,
        price: dish.price,
        image: dish.image,
      })
    }
  }

  return (
    <>
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Popular Dishes</h2>
          <button className="text-sm font-medium" style={{ color: "#FF6600" }}>
            See all
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {dishes.map((dish) => (
            <Card
              key={dish.id}
              className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-border"
              onClick={() => handleDishClick(dish)}
            >
              <div className="relative">
                <img src={dish.image || "/placeholder.svg"} alt={dish.name} className="w-full h-36 object-cover" />
                <Badge
                  className="absolute top-2 left-2 font-semibold text-xs px-2 py-0.5"
                  style={{
                    backgroundColor: dish.badge === "New" ? "#4CAF50" : "#FF6600",
                    color: "#FFFFFF",
                  }}
                >
                  {dish.badge}
                </Badge>
                <Button
                  size="icon"
                  variant="ghost"
                  className="absolute top-2 right-2 w-8 h-8 bg-card/80 backdrop-blur hover:bg-card"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleFavoriteClick(dish)
                  }}
                >
                  <Heart className="w-4 h-4" />
                </Button>
              </div>
              <div className="p-3">
                <h3 className="font-semibold text-sm mb-0.5 text-foreground text-balance">{dish.name}</h3>
                <p className="text-xs text-muted-foreground mb-2">{dish.restaurant}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 fill-current" style={{ color: "#FFC107" }} />
                    <span className="text-xs font-medium text-foreground">{dish.rating}</span>
                  </div>
                  <p className="text-sm font-bold" style={{ color: "#FF6600" }}>
                    ${dish.price.toFixed(2)}
                  </p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
    </>
  )
}
