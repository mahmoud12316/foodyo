"use client"

import { useState, useEffect, useRef } from "react"
import { MapPin, Search, Loader2, Locate, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import type { google } from "google-maps"

type MapPickerProps = {
  latitude: number | null
  longitude: number | null
  onLocationSelect: (lat: number, lng: number, address: string) => void
  required?: boolean
}

export default function MapPicker({ latitude, longitude, onLocationSelect, required = false }: MapPickerProps) {
  const [isPickerOpen, setIsPickerOpen] = useState(false)
  const [selectedLat, setSelectedLat] = useState<number | null>(latitude)
  const [selectedLng, setSelectedLng] = useState<number | null>(longitude)
  const [selectedAddress, setSelectedAddress] = useState<string>("")
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [isGettingLocation, setIsGettingLocation] = useState(false)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [mapError, setMapError] = useState<string | null>(null)

  const mapRef = useRef<HTMLDivElement>(null)
  const googleMapRef = useRef<google.maps.Map | null>(null)
  const markerRef = useRef<google.maps.Marker | null>(null)
  const geocoderRef = useRef<google.maps.Geocoder | null>(null)
  const isInitializingRef = useRef(false)
  const mapListenersRef = useRef<google.maps.MapsEventListener[]>([])
  const isMountedRef = useRef(true)

  useEffect(() => {
    isMountedRef.current = true
    return () => {
      isMountedRef.current = false
    }
  }, [])

  useEffect(() => {
    if (!isPickerOpen) {
      setTimeout(() => {
        if (!isMountedRef.current) return
        cleanupMap()
      }, 0)
      return
    }

    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY

    if (!apiKey) {
      setMapError(
        "Google Maps API key is not configured. Please add NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to your environment variables.",
      )
      return
    }

    setMapError(null)

    if (!(window as any).google?.maps) {
      const script = document.createElement("script")
      script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`
      script.async = true
      script.defer = true
      script.onload = () => {
        if (!isMountedRef.current) return
        setMapLoaded(true)
        setTimeout(() => {
          if (isMountedRef.current) {
            initializeGoogleMap()
          }
        }, 100)
      }
      script.onerror = () => {
        if (!isMountedRef.current) return
        setMapError(
          "Failed to load Google Maps. This could be due to:\n\n" +
            "1. Invalid API key\n" +
            "2. Billing not enabled on your Google Cloud project\n" +
            "3. API restrictions blocking this domain\n" +
            "4. Network connection issues\n\n" +
            "Please check your Google Cloud Console settings.",
        )
      }
      document.head.appendChild(script)
    } else {
      if (!isMountedRef.current) return
      setMapLoaded(true)
      setTimeout(() => {
        if (isMountedRef.current) {
          initializeGoogleMap()
        }
      }, 100)
    }

    return () => {
      // Cleanup handled separately with setTimeout
    }
  }, [isPickerOpen])

  const cleanupMap = () => {
    if (!isMountedRef.current && googleMapRef.current) {
      return
    }

    try {
      mapListenersRef.current.forEach((listener) => {
        try {
          if (listener && typeof listener.remove === "function") {
            listener.remove()
          }
        } catch (e) {
          // Ignore cleanup errors
        }
      })
      mapListenersRef.current = []

      if (markerRef.current) {
        try {
          markerRef.current.setMap(null)
        } catch (e) {
          // Ignore
        }
        markerRef.current = null
      }

      googleMapRef.current = null
      geocoderRef.current = null
      isInitializingRef.current = false
    } catch (error) {
      // Silently handle any cleanup errors
    }
  }

  const initializeGoogleMap = () => {
    if (!isMountedRef.current || isInitializingRef.current || !mapRef.current || !(window as any).google?.maps) {
      return
    }

    isInitializingRef.current = true

    try {
      const google = (window as any).google

      geocoderRef.current = new google.maps.Geocoder()

      const initialCenter = {
        lat: latitude !== null ? latitude : 31.9454,
        lng: longitude !== null ? longitude : 36.09,
      }

      const initialZoom = latitude !== null ? 13 : 8

      if (mapRef.current && !googleMapRef.current) {
        const map = new google.maps.Map(mapRef.current, {
          center: initialCenter,
          zoom: initialZoom,
          mapTypeControl: true,
          streetViewControl: false,
          fullscreenControl: false,
          zoomControl: true,
        })

        googleMapRef.current = map

        const clickListener = map.addListener("click", (event: any) => {
          if (!isMountedRef.current) return

          const lat = Number(event.latLng.lat().toFixed(6))
          const lng = Number(event.latLng.lng().toFixed(6))

          setSelectedLat(lat)
          setSelectedLng(lng)
          updateMarker(lat, lng)
          reverseGeocode(lat, lng)
        })
        mapListenersRef.current.push(clickListener)

        if (latitude !== null && longitude !== null) {
          updateMarker(latitude, longitude)
        }
      }
    } catch (error) {
      console.error("Map initialization error:", error)
      setMapError("Failed to initialize map. Please refresh the page and try again.")
    } finally {
      isInitializingRef.current = false
    }
  }

  const updateMarker = (lat: number, lng: number) => {
    if (!googleMapRef.current || !isMountedRef.current) return

    try {
      const google = (window as any).google
      const position = { lat, lng }

      if (markerRef.current) {
        markerRef.current.setPosition(position)
      } else {
        markerRef.current = new google.maps.Marker({
          position,
          map: googleMapRef.current,
          animation: google.maps.Animation.DROP,
        })
      }

      googleMapRef.current.panTo(position)
    } catch (error) {
      console.error("Marker update error:", error)
    }
  }

  const reverseGeocode = async (lat: number, lng: number) => {
    if (!geocoderRef.current || !isMountedRef.current) return

    try {
      const result = await geocoderRef.current.geocode({
        location: { lat, lng },
      })

      if (!isMountedRef.current) return

      if (result.results && result.results.length > 0) {
        setSelectedAddress(result.results[0].formatted_address)
      } else {
        setSelectedAddress(`${lat}, ${lng}`)
      }
    } catch (error) {
      if (isMountedRef.current) {
        setSelectedAddress(`${lat}, ${lng}`)
      }
    }
  }

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      alert("Please enter an address or location to search.")
      return
    }

    if (!geocoderRef.current) {
      alert("Map is not ready. Please wait a moment and try again.")
      return
    }

    setIsSearching(true)

    try {
      if (isPlusCode(searchQuery)) {
        await handlePlusCodeSearch(searchQuery)
      } else {
        const result = await geocoderRef.current.geocode({
          address: searchQuery,
          region: "jo",
          componentRestrictions:
            searchQuery.toLowerCase().includes("zarqa") || searchQuery.toLowerCase().includes("jordan")
              ? { country: "JO" }
              : undefined,
        })

        if (!isMountedRef.current) return

        if (result.results && result.results.length > 0) {
          const location = result.results[0].geometry.location
          const lat = Number(location.lat().toFixed(6))
          const lng = Number(location.lng().toFixed(6))

          setSelectedLat(lat)
          setSelectedLng(lng)
          setSelectedAddress(result.results[0].formatted_address)

          updateMarker(lat, lng)

          if (googleMapRef.current) {
            googleMapRef.current.setZoom(17)
          }
        } else {
          alert(
            `Unable to find location: "${searchQuery}"\n\n` +
              "Please try:\n" +
              "• Adding more details (e.g., 'Zarqa, Jordan')\n" +
              "• Using a nearby landmark\n" +
              "• Clicking directly on the map\n" +
              "• Using the GPS button for your current location",
          )
        }
      }
    } catch (error) {
      if (isMountedRef.current) {
        alert("Search failed. Please try a different address or use the GPS button to set your location.")
      }
    } finally {
      if (isMountedRef.current) {
        setIsSearching(false)
      }
    }
  }

  const handlePlusCodeSearch = async (query: string) => {
    if (!geocoderRef.current || !isMountedRef.current) return

    try {
      const result = await geocoderRef.current.geocode({
        address: query,
        region: "jo",
      })

      if (!isMountedRef.current) return

      if (result.results && result.results.length > 0) {
        const location = result.results[0].geometry.location
        const lat = Number(location.lat().toFixed(6))
        const lng = Number(location.lng().toFixed(6))

        setSelectedLat(lat)
        setSelectedLng(lng)
        setSelectedAddress(result.results[0].formatted_address || query)

        updateMarker(lat, lng)

        if (googleMapRef.current) {
          googleMapRef.current.setZoom(18)
        }
      } else {
        alert(`Unable to resolve Plus Code: "${query}"\n\nPlease ensure the Plus Code is valid.`)
      }
    } catch (error) {
      if (isMountedRef.current) {
        alert("Plus Code search failed. Please try again or enter a standard address.")
      }
    }
  }

  const isPlusCode = (query: string): boolean => {
    const trimmed = query.replace(/\s+/g, "").toUpperCase()
    return /[23456789CFGHJMPQRVWX]{4,8}\+[23456789CFGHJMPQRVWX]{2,}/.test(trimmed)
  }

  const handleAutoLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser.")
      return
    }

    setIsGettingLocation(true)

    navigator.geolocation.getCurrentPosition(
      (position) => {
        if (!isMountedRef.current) return

        const lat = Number(position.coords.latitude.toFixed(6))
        const lng = Number(position.coords.longitude.toFixed(6))

        setSelectedLat(lat)
        setSelectedLng(lng)

        updateMarker(lat, lng)
        reverseGeocode(lat, lng)

        if (googleMapRef.current) {
          googleMapRef.current.setZoom(15)
        }

        setIsGettingLocation(false)
      },
      (error) => {
        if (!isMountedRef.current) return

        setIsGettingLocation(false)
        let message = "Unable to get your location. "

        switch (error.code) {
          case error.PERMISSION_DENIED:
            message += "Please allow location access in your browser settings."
            break
          case error.POSITION_UNAVAILABLE:
            message += "Location information is unavailable."
            break
          case error.TIMEOUT:
            message += "Location request timed out."
            break
          default:
            message += "An unknown error occurred."
        }

        alert(message)
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  }

  const handleConfirmLocation = () => {
    if (selectedLat !== null && selectedLng !== null) {
      onLocationSelect(selectedLat, selectedLng, selectedAddress || `${selectedLat}, ${selectedLng}`)
      setIsPickerOpen(false)
    }
  }

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="location-display">
          Restaurant Location {required && <span className="text-red-500">*</span>}
        </Label>
        <div className="flex gap-2">
          <Input
            id="location-display"
            value={
              selectedLat !== null && selectedLng !== null ? `${selectedLat}, ${selectedLng}` : "No location selected"
            }
            readOnly
            className="flex-1"
          />
          <Button type="button" onClick={() => setIsPickerOpen(true)} variant="outline">
            <MapPin className="mr-2 h-4 w-4" />
            {selectedLat !== null ? "Change" : "Select"} Location
          </Button>
        </div>
        {selectedAddress && <p className="text-sm text-muted-foreground">{selectedAddress}</p>}
      </div>

      {isPickerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="w-full max-w-4xl bg-background p-6 rounded-lg shadow-lg max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-semibold mb-4">Select Restaurant Location</h2>

            <div className="space-y-4">
              {mapError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Map Configuration Error</AlertTitle>
                  <AlertDescription className="whitespace-pre-line">{mapError}</AlertDescription>
                </Alert>
              )}

              {!mapError && (
                <>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Search address or Plus Code (e.g., 33PW+JWM, Zarqa)"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                      className="flex-1"
                    />
                    <Button onClick={handleSearch} disabled={isSearching}>
                      {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                    </Button>
                    <Button onClick={handleAutoLocation} disabled={isGettingLocation} variant="outline">
                      {isGettingLocation ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Locate className="h-4 w-4" />
                      )}
                    </Button>
                  </div>

                  <div ref={mapRef} className="w-full h-[500px] rounded-lg border bg-muted">
                    {!mapLoaded && (
                      <div className="w-full h-full flex items-center justify-center">
                        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
                      </div>
                    )}
                  </div>

                  {selectedLat !== null && selectedLng !== null && (
                    <div className="p-4 bg-muted rounded-lg">
                      <p className="text-sm font-medium">Selected Coordinates:</p>
                      <p className="text-sm text-muted-foreground">
                        Latitude: {selectedLat}, Longitude: {selectedLng}
                      </p>
                      {selectedAddress && (
                        <p className="text-sm text-muted-foreground mt-1">Address: {selectedAddress}</p>
                      )}
                    </div>
                  )}
                </>
              )}

              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setIsPickerOpen(false)}>
                  Cancel
                </Button>
                <Button
                  type="button"
                  onClick={handleConfirmLocation}
                  disabled={selectedLat === null || selectedLng === null || mapError !== null}
                >
                  Confirm Location
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
