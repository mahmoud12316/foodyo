"use client"

import { ShoppingCart, User, Menu, MapPin, ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { SideNav } from "./side-nav"
import { useAuth } from "@/lib/auth-context"
import { useCart } from "@/lib/cart-context"
import { SignInPrompt } from "./sign-in-prompt"
import { useRouter } from "next/navigation"
import { useLocation } from "@/lib/location-context"
import { LocationModal } from "./location-modal"

export function Header() {
  const { isAuthenticated, isGuest, userName } = useAuth()
  const { itemCount } = useCart()
  const { currentLocation, openLocationModal } = useLocation()
  const [isSideNavOpen, setIsSideNavOpen] = useState(false)
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)
  const router = useRouter()

  const handleCartClick = () => {
    if (isGuest) {
      setShowSignInPrompt(true)
    } else {
      router.push("/cart")
    }
  }

  const handleProfileClick = () => {
    if (isGuest) {
      setShowSignInPrompt(true)
    } else {
      console.log("[v0] Opening profile")
    }
  }

  return (
    <>
      <header className="sticky top-0 z-50 bg-white shadow-sm">
        {/* Location Bar */}
        <div className="bg-gradient-to-r from-primary/5 to-accent/5 border-b border-border/50">
          <div className="container mx-auto px-4 py-3 max-w-7xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary" />
                <div className="flex items-center gap-1">
                  <span className="text-sm font-medium text-foreground">Deliver to:</span>
                  <button
                    onClick={openLocationModal}
                    className="text-sm font-semibold text-primary hover:text-primary/80 flex items-center gap-1 transition-colors"
                  >
                    {currentLocation.address}
                    <ChevronDown className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="h-9 w-9 relative" onClick={handleCartClick}>
                  <ShoppingCart className="w-5 h-5 text-foreground" />
                  {itemCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </Button>
                <Button variant="ghost" size="icon" className="h-9 w-9" onClick={handleProfileClick}>
                  <User className="w-5 h-5 text-foreground" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Header */}
        <div className="container mx-auto px-4 py-4 max-w-7xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="h-10 w-10" onClick={() => setIsSideNavOpen(true)}>
                <Menu className="w-6 h-6 text-foreground" />
              </Button>
              <h1 className="text-3xl font-bold text-[#FF0000] opacity-100">Foodyo</h1>
            </div>

            {isAuthenticated && userName && (
              <div className="hidden md:block">
                <p className="text-sm text-muted-foreground">
                  Hi, <span className="font-semibold text-foreground">{userName}</span>
                </p>
              </div>
            )}
          </div>
        </div>
      </header>

      <SideNav isOpen={isSideNavOpen} onClose={() => setIsSideNavOpen(false)} />
      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
      <LocationModal />
    </>
  )
}
