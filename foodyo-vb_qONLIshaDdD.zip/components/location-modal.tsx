"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { MapPin, Loader2, AlertCircle, Navigation } from "lucide-react"
import { useLocation } from "@/lib/location-context"
import { Alert, AlertDescription } from "@/components/ui/alert"

// Leaflet types
interface LeafletMap {
  setView: (center: [number, number], zoom: number) => void
  getCenter: () => { lat: number; lng: number }
  on: (event: string, handler: (e: any) => void) => void
  remove: () => void
}

export function LocationModal() {
  const { isLocationModalOpen, closeLocationModal, setLocation } = useLocation()
  const [mapCenter, setMapCenter] = useState({ lat: 32.0728, lng: 36.0881 }) // Zarqa, Jordan
  const [selectedAddress, setSelectedAddress] = useState("Select location on map")
  const [isLoadingLocation, setIsLoadingLocation] = useState(false)
  const [locationError, setLocationError] = useState<string | null>(null)
  const [isMapReady, setIsMapReady] = useState(false)
  const mapContainerRef = useRef<HTMLDivElement>(null)
  const mapInstanceRef = useRef<LeafletMap | null>(null)
  const [isLoadingAddress, setIsLoadingAddress] = useState(false)

  useEffect(() => {
    if (!isLocationModalOpen) return

    // Load Leaflet CSS immediately
    if (!document.getElementById("leaflet-css")) {
      const link = document.createElement("link")
      link.id = "leaflet-css"
      link.rel = "stylesheet"
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      link.integrity = "sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
      link.crossOrigin = ""
      document.head.appendChild(link)
    }
  }, [isLocationModalOpen])

  useEffect(() => {
    if (!isLocationModalOpen || !mapContainerRef.current || mapInstanceRef.current) return

    const initMap = async () => {
      try {
        // Wait a bit for CSS to load
        await new Promise((resolve) => setTimeout(resolve, 100))

        // @ts-ignore - Leaflet will be loaded dynamically
        const L = (await import("leaflet")).default

        if (!mapContainerRef.current) return

        const map = L.map(mapContainerRef.current, {
          zoomControl: true,
          attributionControl: true,
        }).setView([mapCenter.lat, mapCenter.lng], 15)

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: "&copy; OpenStreetMap contributors",
        }).addTo(map)

        mapInstanceRef.current = map

        // Update center when map is moved
        map.on("moveend", () => {
          const center = map.getCenter()
          setMapCenter({ lat: center.lat, lng: center.lng })
          reverseGeocode(center.lat, center.lng)
        })

        setIsMapReady(true)

        // Initial reverse geocode
        reverseGeocode(mapCenter.lat, mapCenter.lng)
      } catch (error) {
        console.error("Error loading map:", error)
        setLocationError("Failed to load map. Please try again.")
        setIsMapReady(true)
      }
    }

    initMap()

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove()
        mapInstanceRef.current = null
      }
      setIsMapReady(false)
    }
  }, [isLocationModalOpen, mapCenter.lat, mapCenter.lng])

  // Get user's current location
  useEffect(() => {
    if (isLocationModalOpen && navigator.geolocation) {
      setIsLoadingLocation(true)

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords
          setMapCenter({ lat: latitude, lng: longitude })

          // Update map view if map is ready
          if (mapInstanceRef.current) {
            mapInstanceRef.current.setView([latitude, longitude], 15)
          }

          reverseGeocode(latitude, longitude)
          setIsLoadingLocation(false)
        },
        (error) => {
          console.error("Geolocation error:", error)
          setLocationError("Unable to get your location. Please select manually on the map.")
          setIsLoadingLocation(false)
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        },
      )
    }
  }, [isLocationModalOpen])

  const reverseGeocode = useCallback(async (lat: number, lng: number) => {
    setIsLoadingAddress(true)
    try {
      // Use Nominatim (OpenStreetMap) for reverse geocoding
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&accept-language=en`,
        {
          headers: {
            "User-Agent": "Foodyo App",
          },
        },
      )
      const data = await response.json()

      if (data.display_name) {
        setSelectedAddress(data.display_name)
      } else {
        setSelectedAddress(`${lat.toFixed(6)}, ${lng.toFixed(6)}`)
      }
    } catch (error) {
      console.error("Geocoding error:", error)
      setSelectedAddress(`${lat.toFixed(6)}, ${lng.toFixed(6)}`)
    } finally {
      setIsLoadingAddress(false)
    }
  }, [])

  const handleConfirmLocation = () => {
    setLocation(selectedAddress, mapCenter.lat, mapCenter.lng)
    setLocationError(null)
  }

  return (
    <Dialog open={isLocationModalOpen} onOpenChange={closeLocationModal}>
      <DialogContent className="sm:max-w-full sm:h-screen p-0 gap-0">
        {/* Map Container */}
        <div className="relative w-full h-full flex flex-col">
          {/* Loading Overlay */}
          {isLoadingLocation && (
            <div className="absolute inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
              <div className="text-center">
                <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
                <p className="text-lg font-medium">Getting your location...</p>
              </div>
            </div>
          )}

          {/* Map Display */}
          <div className="flex-1 relative">
            <div ref={mapContainerRef} className="w-full h-full" style={{ minHeight: "400px" }} />

            {/* Center Pin - stays fixed while map moves */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-full z-[1000] pointer-events-none">
              <MapPin className="w-12 h-12 text-primary drop-shadow-lg" fill="currentColor" />
            </div>

            {/* Instructions */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white dark:bg-gray-800 px-4 py-2 rounded-full shadow-lg border border-border z-[1000]">
              <p className="text-sm font-medium">Drag map to select location</p>
            </div>

            {/* Coordinates Display */}
            <div className="absolute bottom-32 left-4 bg-white dark:bg-gray-800 px-3 py-2 rounded-lg shadow-md border border-border z-[1000]">
              <p className="text-xs text-muted-foreground">
                {mapCenter.lat.toFixed(6)}, {mapCenter.lng.toFixed(6)}
              </p>
            </div>
          </div>

          {/* Bottom Confirmation Panel */}
          <div className="bg-background border-t border-border p-4 space-y-3 z-[1000]">
            {/* Error Alert */}
            {locationError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{locationError}</AlertDescription>
              </Alert>
            )}

            {/* Selected Address */}
            <div className="flex items-start gap-3 p-3 bg-accent/10 rounded-lg border border-border">
              <MapPin className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm text-muted-foreground mb-1">Delivery Address</p>
                {isLoadingAddress ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <p className="text-sm text-muted-foreground">Loading address...</p>
                  </div>
                ) : (
                  <p className="font-medium text-foreground line-clamp-2">{selectedAddress}</p>
                )}
              </div>
            </div>

            {/* Confirm Button - Always enabled, prominent blue styling */}
            <Button
              onClick={handleConfirmLocation}
              size="lg"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-6 text-base"
            >
              <Navigation className="w-5 h-5 mr-2" />
              Confirm This Location
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
