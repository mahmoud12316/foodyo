"use client"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useRouter } from "next/navigation"

interface SignInPromptProps {
  isOpen: boolean
  onClose: () => void
}

export function SignInPrompt({ isOpen, onClose }: SignInPromptProps) {
  const router = useRouter()

  const handleSignIn = () => {
    onClose()
    router.push("/login")
  }

  const handleCreateAccount = () => {
    onClose()
    router.push("/signup")
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-center text-xl">Sign In Required</DialogTitle>
          <DialogDescription className="text-center pt-2">
            Please sign in or create an account to continue.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col gap-3 pt-4">
          <Button onClick={handleSignIn} className="w-full bg-orange-500 hover:bg-orange-600">
            Sign In
          </Button>
          <Button onClick={handleCreateAccount} variant="outline" className="w-full bg-transparent">
            Create Account
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
