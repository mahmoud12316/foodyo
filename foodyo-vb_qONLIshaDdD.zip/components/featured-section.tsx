"use client"

import type React from "react"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Plus } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { useState } from "react"
import { SignInPrompt } from "./sign-in-prompt"
import { useRouter } from "next/navigation"

const featured = [
  {
    id: "featured-1",
    name: "Truffle Mushroom Pizza",
    restaurant: "Bella Italia",
    restaurantId: 1,
    rating: 4.8,
    price: 18.99,
    image: "/placeholder.svg?height=200&width=400",
    badge: "Popular",
  },
  {
    id: "featured-2",
    name: "Dragon Roll Sushi",
    restaurant: "Sushi Master",
    restaurantId: 3,
    rating: 4.9,
    price: 22.99,
    image: "/placeholder.svg?height=200&width=400",
    badge: "New",
  },
  {
    id: "featured-3",
    name: "Wagyu Beef Burger",
    restaurant: "Burger House",
    restaurantId: 2,
    rating: 4.7,
    price: 16.99,
    image: "/placeholder.svg?height=200&width=400",
    badge: "Popular",
  },
]

export function FeaturedSection() {
  const { addToCart } = useCart()
  const { isGuest } = useAuth()
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)
  const router = useRouter()

  const handleAddToCart = (dish: (typeof featured)[0], e: React.MouseEvent) => {
    e.stopPropagation()
    const isOpen = JSON.parse(localStorage.getItem(`restaurant_${dish.restaurantId}_isOpen`) || "true")

    if (!isOpen) {
      return // Don't add to cart if restaurant is closed
    }

    if (isGuest) {
      setShowSignInPrompt(true)
    } else {
      addToCart({
        id: dish.id,
        name: dish.name,
        restaurant: dish.restaurant,
        price: dish.price,
        image: dish.image,
      })
    }
  }

  return (
    <>
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">Featured</h2>
          <button
            onClick={() => router.push("/restaurants")}
            className="text-sm font-medium"
            style={{ color: "#FF6600" }}
          >
            See all
          </button>
        </div>
        <div className="space-y-4">
          {featured.map((dish) => {
            const isOpen = JSON.parse(localStorage.getItem(`restaurant_${dish.restaurantId}_isOpen`) || "true")

            return (
              <Card
                key={dish.id}
                onClick={() => router.push(`/restaurants/${dish.restaurantId}`)}
                className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-border"
              >
                <div className="relative">
                  <img src={dish.image || "/placeholder.svg"} alt={dish.name} className="w-full h-48 object-cover" />
                  <Badge
                    className="absolute top-3 left-3 font-semibold text-xs px-3 py-1"
                    style={{
                      backgroundColor: dish.badge === "New" ? "#4CAF50" : "#FF6600",
                      color: "#FFFFFF",
                    }}
                  >
                    {dish.badge}
                  </Badge>
                  {!isOpen && (
                    <Badge className="absolute top-3 right-3 font-semibold text-xs px-3 py-1 bg-red-600 text-white">
                      Closed
                    </Badge>
                  )}
                </div>
                <div className="p-4">
                  <div className="mb-3">
                    <h3 className="font-semibold text-base text-foreground text-balance mb-1">{dish.name}</h3>
                    <p className="text-sm text-muted-foreground">{dish.restaurant}</p>
                    {!isOpen && <p className="text-xs text-red-600 font-medium mt-1">Restaurant closed</p>}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-current" style={{ color: "#FFC107" }} />
                        <span className="text-sm font-medium text-foreground">{dish.rating}</span>
                      </div>
                      <p className="text-base font-bold" style={{ color: "#FF6600" }}>
                        ${dish.price.toFixed(2)}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      className="bg-[#FF6600] hover:bg-[#FF6600]/90 text-white"
                      onClick={(e) => handleAddToCart(dish, e)}
                      disabled={!isOpen}
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      {isOpen ? "Add" : "Closed"}
                    </Button>
                  </div>
                </div>
              </Card>
            )
          })}
        </div>
      </div>
      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
    </>
  )
}
