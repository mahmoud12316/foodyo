"use client"

import { Search, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useState, useEffect } from "react"
import { getAllRestaurants, getAllMeals } from "@/lib/demo-data"
import { SearchResults } from "./search-results"

interface Restaurant {
  id: number
  name: string
  category: string
  image: string
  rating: number
  deliveryTime: string
  deliveryFee: number
  status: string
}

interface Meal {
  id: number
  restaurantId: number
  name: string
  description: string
  price: number
  image: string
}

export function SearchBar() {
  const [isFocused, setIsFocused] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [meals, setMeals] = useState<Meal[]>([])
  const [filteredRestaurants, setFilteredRestaurants] = useState<Restaurant[]>([])
  const [filteredMeals, setFilteredMeals] = useState<Meal[]>([])
  const [showResults, setShowResults] = useState(false)

  useEffect(() => {
    const loadedRestaurants = getAllRestaurants().filter((r) => r.status === "approved")
    const loadedMeals = getAllMeals()
    setRestaurants(loadedRestaurants)
    setMeals(loadedMeals)
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredRestaurants([])
      setFilteredMeals([])
      setShowResults(false)
      return
    }

    const query = searchQuery.toLowerCase()

    // Filter restaurants by name, category, or cuisine
    const matchedRestaurants = restaurants.filter(
      (restaurant) =>
        restaurant.name.toLowerCase().includes(query) || restaurant.category.toLowerCase().includes(query),
    )

    // Filter meals by name or description
    const matchedMeals = meals.filter(
      (meal) => meal.name.toLowerCase().includes(query) || meal.description.toLowerCase().includes(query),
    )

    setFilteredRestaurants(matchedRestaurants)
    setFilteredMeals(matchedMeals)
    setShowResults(true)
  }, [searchQuery, restaurants, meals])

  const handleClear = () => {
    setSearchQuery("")
    setShowResults(false)
  }

  return (
    <div className="relative mb-8">
      <div className="relative">
        <Search
          className={`absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 transition-colors ${
            isFocused ? "text-primary" : "text-muted-foreground"
          }`}
        />
        <Input
          type="search"
          placeholder="Search for restaurants or meals..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            // Delay to allow click on results
            setTimeout(() => setIsFocused(false), 200)
          }}
          className="pl-12 pr-12 h-14 bg-white border-border rounded-xl shadow-sm hover:shadow-md focus:shadow-md transition-shadow text-base"
        />
        {searchQuery && (
          <button
            onClick={handleClear}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {showResults && (isFocused || searchQuery) && (
        <SearchResults
          restaurants={filteredRestaurants}
          meals={filteredMeals}
          query={searchQuery}
          onClose={() => setShowResults(false)}
        />
      )}
    </div>
  )
}
