"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const offers = [
  {
    id: 1,
    title: "50% OFF",
    subtitle: "On your first order",
    bgColor: "from-orange-600 to-red-600",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 2,
    title: "Free Delivery",
    subtitle: "Orders above $20",
    bgColor: "from-green-600 to-teal-600",
    image: "/placeholder.svg?height=400&width=400",
  },
  {
    id: 3,
    title: "Buy 1 Get 1",
    subtitle: "On selected items",
    bgColor: "from-purple-600 to-pink-600",
    image: "/placeholder.svg?height=400&width=400",
  },
]

export function OffersCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [touchStart, setTouchStart] = useState(0)
  const [touchEnd, setTouchEnd] = useState(0)

  // Auto-slide every 5 seconds
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % offers.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + offers.length) % offers.length)
  }

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % offers.length)
  }

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX)
  }

  const handleTouchEnd = () => {
    if (touchStart - touchEnd > 75) {
      handleNext()
    }
    if (touchStart - touchEnd < -75) {
      handlePrevious()
    }
  }

  return (
    <div className="relative w-full overflow-hidden rounded-2xl mb-6 shadow-lg">
      <div
        className="flex transition-transform duration-500 ease-out"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {offers.map((offer) => (
          <div key={offer.id} className="min-w-full">
            <div className={`relative h-48 bg-gradient-to-r ${offer.bgColor} rounded-2xl overflow-hidden`}>
              <div className="absolute inset-0 flex items-center justify-between px-6">
                <div className="text-white z-10" style={{ textShadow: "0 2px 8px rgba(0,0,0,0.3)" }}>
                  <h2 className="text-4xl font-bold mb-2 drop-shadow-lg">{offer.title}</h2>
                  <p className="text-lg font-medium drop-shadow-md">{offer.subtitle}</p>
                </div>
                <img
                  src={offer.image || "/placeholder.svg"}
                  alt={offer.title}
                  className="h-40 w-40 object-cover rounded-xl shadow-2xl border-2 border-white/20"
                  loading="eager"
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Navigation Buttons */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full h-8 w-8"
        onClick={handlePrevious}
      >
        <ChevronLeft className="h-5 w-5 text-gray-800" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full h-8 w-8"
        onClick={handleNext}
      >
        <ChevronRight className="h-5 w-5 text-gray-800" />
      </Button>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
        {offers.map((_, index) => (
          <button
            key={index}
            className={`h-2 rounded-full transition-all ${index === currentIndex ? "w-6 bg-white" : "w-2 bg-white/50"}`}
            onClick={() => setCurrentIndex(index)}
          />
        ))}
      </div>
    </div>
  )
}
