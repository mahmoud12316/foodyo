"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Star } from "lucide-react"
import { getAllRestaurants, getMealsByRestaurantId, initializeDemoData, type Meal } from "@/lib/demo-data"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { SignInPrompt } from "./sign-in-prompt"

interface MealWithRestaurant extends Meal {
  restaurantName: string
  restaurantId: string
}

export function TopMeals() {
  const router = useRouter()
  const { addItem } = useCart()
  const { isGuest } = useAuth()
  const [meals, setMeals] = useState<MealWithRestaurant[]>([])
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)

  useEffect(() => {
    initializeDemoData()
    const allRestaurants = getAllRestaurants()
    const approvedRestaurants = allRestaurants.filter((r) => r.status === "approved" && r.isOpen)

    // Get 2 meals from each restaurant
    const topMeals: MealWithRestaurant[] = []
    approvedRestaurants.slice(0, 6).forEach((restaurant) => {
      const restaurantMeals = getMealsByRestaurantId(restaurant.id)
      const selectedMeals = restaurantMeals.slice(0, 2)
      selectedMeals.forEach((meal) => {
        topMeals.push({
          ...meal,
          restaurantName: restaurant.name,
          restaurantId: restaurant.id,
        })
      })
    })

    setMeals(topMeals.slice(0, 12))
  }, [])

  const handleAddToCart = (e: React.MouseEvent, meal: MealWithRestaurant) => {
    e.stopPropagation()
    if (isGuest) {
      setShowSignInPrompt(true)
      return
    }
    addItem({
      id: meal.id,
      name: meal.name,
      price: meal.price,
      quantity: 1,
      image: meal.image,
      restaurantId: meal.restaurantId,
      restaurantName: meal.restaurantName,
    })
  }

  if (meals.length === 0) return null

  return (
    <>
      <div className="mb-10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Top Meals</h2>
            <p className="text-sm text-muted-foreground mt-1">Most ordered dishes this week</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {meals.map((meal) => (
            <Card
              key={meal.id}
              onClick={() => router.push(`/restaurants/${meal.restaurantId}`)}
              className="overflow-hidden cursor-pointer hover:shadow-lg transition-all border-border bg-white group"
            >
              <div className="relative h-36">
                <img
                  src={meal.image || "/placeholder.svg"}
                  alt={meal.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <Button
                  size="icon"
                  onClick={(e) => handleAddToCart(e, meal)}
                  className="absolute bottom-2 right-2 h-8 w-8 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              <div className="p-3">
                <h3 className="font-semibold text-sm text-foreground text-balance line-clamp-1 mb-1">{meal.name}</h3>
                <p className="text-xs text-muted-foreground line-clamp-1 mb-2">{meal.restaurantName}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold text-primary">${meal.price}</span>
                  {meal.rating && (
                    <div className="flex items-center gap-0.5">
                      <Star className="w-3 h-3 fill-current text-yellow-500" />
                      <span className="text-xs font-medium text-foreground">{meal.rating}</span>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
    </>
  )
}
