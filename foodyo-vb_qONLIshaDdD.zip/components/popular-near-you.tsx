"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Clock, DollarSign } from "lucide-react"
import { getAllRestaurants, initializeDemoData, type Restaurant } from "@/lib/demo-data"

export function PopularNearYou() {
  const router = useRouter()
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])

  useEffect(() => {
    initializeDemoData()
    const allRestaurants = getAllRestaurants()
    const approvedRestaurants = allRestaurants.filter((r) => r.status === "approved" && r.isOpen)
    // Get 4 random restaurants
    const shuffled = approvedRestaurants.sort(() => 0.5 - Math.random())
    setRestaurants(shuffled.slice(0, 4))
  }, [])

  if (restaurants.length === 0) return null

  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Popular Near You</h2>
          <p className="text-sm text-muted-foreground mt-1">Best choices in your area</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {restaurants.map((restaurant) => (
          <Card
            key={restaurant.id}
            onClick={() => router.push(`/restaurants/${restaurant.id}`)}
            className="overflow-hidden cursor-pointer hover:shadow-lg transition-all border-border bg-white group"
          >
            <div className="relative h-40">
              <img
                src={restaurant.image || "/placeholder.svg"}
                alt={restaurant.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <Badge className="absolute top-2 right-2 font-semibold text-xs px-2 py-1 bg-white/90 text-foreground backdrop-blur-sm">
                {restaurant.category}
              </Badge>
            </div>

            <div className="p-3">
              <h3 className="font-semibold text-base text-foreground text-balance mb-1 line-clamp-1">
                {restaurant.name}
              </h3>
              <p className="text-xs text-muted-foreground line-clamp-1 mb-3">{restaurant.description}</p>

              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-current text-yellow-500" />
                  <span className="font-semibold text-foreground">{restaurant.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{restaurant.deliveryTime}</span>
                </div>
                <div className="flex items-center gap-0.5 text-muted-foreground">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>{restaurant.deliveryFee}</span>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
