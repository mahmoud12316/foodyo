"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Clock, MapPin } from "lucide-react"
import { getAllRestaurants, initializeDemoData, type Restaurant } from "@/lib/demo-data"

export function RestaurantsGrid() {
  const router = useRouter()
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Initialize demo data on component mount
    initializeDemoData()

    // Load restaurants from localStorage
    const loadRestaurants = () => {
      const allRestaurants = getAllRestaurants()
      const approvedRestaurants = allRestaurants.filter((r) => r.status === "approved")
      setRestaurants(approvedRestaurants)
      setLoading(false)
    }

    loadRestaurants()

    // Listen for storage changes (for admin updates)
    const handleStorageChange = () => {
      loadRestaurants()
    }

    window.addEventListener("storage", handleStorageChange)
    return () => window.removeEventListener("storage", handleStorageChange)
  }, [])

  if (loading) {
    return (
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-foreground mb-4">Restaurants Near You</h2>
        <div className="grid grid-cols-1 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-64 bg-muted animate-pulse rounded-lg" />
          ))}
        </div>
      </div>
    )
  }

  if (restaurants.length === 0) {
    return (
      <div className="mb-8">
        <h2 className="text-lg font-semibold text-foreground mb-4">Restaurants Near You</h2>
        <p className="text-muted-foreground text-center py-8">No restaurants available at the moment</p>
      </div>
    )
  }

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Restaurants Near You</h2>
        <span className="text-sm text-muted-foreground">{restaurants.length} restaurants</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {restaurants.map((restaurant) => (
          <Card
            key={restaurant.id}
            onClick={() => router.push(`/restaurants/${restaurant.id}`)}
            className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-border"
          >
            <div className="relative">
              <img
                src={restaurant.image || "/placeholder.svg"}
                alt={restaurant.name}
                className="w-full h-48 object-cover"
              />
              <Badge className="absolute top-3 left-3 font-semibold text-xs px-3 py-1 bg-[#FF6600] text-white">
                {restaurant.category}
              </Badge>
              {!restaurant.isOpen && (
                <Badge className="absolute top-3 right-3 font-semibold text-xs px-3 py-1 bg-red-600 text-white">
                  Closed
                </Badge>
              )}
            </div>

            <div className="p-4">
              <div className="mb-3">
                <h3 className="font-semibold text-base text-foreground text-balance mb-1">{restaurant.name}</h3>
                <p className="text-sm text-muted-foreground line-clamp-1">{restaurant.description}</p>
                {!restaurant.isOpen && <p className="text-xs text-red-600 font-medium mt-1">Restaurant closed</p>}
              </div>

              <div className="flex items-center gap-3 text-sm">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-current text-[#FFC107]" />
                  <span className="font-medium text-foreground">{restaurant.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{restaurant.deliveryTime}</span>
                </div>
              </div>

              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
                <MapPin className="w-3 h-3" />
                <span className="line-clamp-1">{restaurant.address}</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
