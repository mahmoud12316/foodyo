"use client"

import { Home, Search, Heart, User } from "lucide-react"
import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { SignInPrompt } from "./sign-in-prompt"

const navItems = [
  { icon: Home, label: "Home", requiresAuth: false },
  { icon: Search, label: "Search", requiresAuth: false },
  { icon: Heart, label: "Favorites", requiresAuth: true },
  { icon: User, label: "Profile", requiresAuth: true },
]

export function BottomNav() {
  const [active, setActive] = useState(0)
  const { isGuest } = useAuth()
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)

  const handleNavClick = (index: number, item: (typeof navItems)[0]) => {
    if (item.requiresAuth && isGuest) {
      setShowSignInPrompt(true)
    } else {
      setActive(index)
      console.log(`[v0] Navigating to ${item.label}`)
    }
  }

  return (
    <>
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="flex items-center justify-around py-3">
            {navItems.map((item, index) => {
              const Icon = item.icon
              const isActive = active === index
              return (
                <button
                  key={item.label}
                  onClick={() => handleNavClick(index, item)}
                  className="flex flex-col items-center gap-1 min-w-[60px]"
                >
                  <Icon
                    className={`w-6 h-6 transition-colors ${isActive ? "text-primary" : "text-muted-foreground"}`}
                  />
                  <span
                    className={`text-xs transition-colors ${
                      isActive ? "text-primary font-medium" : "text-muted-foreground"
                    }`}
                  >
                    {item.label}
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      </nav>
      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
    </>
  )
}
