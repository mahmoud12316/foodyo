"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

interface LogoutDialogProps {
  isOpen: boolean
  onCancel: () => void
  onConfirm: () => void
}

export function LogoutDialog({ isOpen, onCancel, onConfirm }: LogoutDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Logout</DialogTitle>
          <DialogDescription className="text-base pt-2">Are you sure you want to log out?</DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex gap-2 sm:gap-2">
          <Button
            variant="outline"
            onClick={onCancel}
            className="flex-1 border-gray-300 hover:bg-gray-50 bg-transparent"
          >
            Cancel
          </Button>
          <Button onClick={onConfirm} className="flex-1 bg-orange-500 hover:bg-orange-600 text-white">
            Logout
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
