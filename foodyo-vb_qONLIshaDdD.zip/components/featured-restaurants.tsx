"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Clock } from "lucide-react"
import { getAllRestaurants, initializeDemoData, type Restaurant } from "@/lib/demo-data"

export function FeaturedRestaurants() {
  const router = useRouter()
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    initializeDemoData()
    const allRestaurants = getAllRestaurants()
    const approvedRestaurants = allRestaurants.filter((r) => r.status === "approved" && r.isOpen)
    // Get top 5 restaurants with highest ratings
    const featured = approvedRestaurants.sort((a, b) => b.rating - a.rating).slice(0, 5)
    setRestaurants(featured)
  }, [])

  if (restaurants.length === 0) return null

  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Featured Restaurants</h2>
          <p className="text-sm text-muted-foreground mt-1">Top-rated places you&apos;ll love</p>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {restaurants.map((restaurant) => (
          <Card
            key={restaurant.id}
            onClick={() => router.push(`/restaurants/${restaurant.id}`)}
            className="flex-shrink-0 w-80 overflow-hidden cursor-pointer hover:shadow-xl transition-all border-border bg-white snap-start group"
          >
            <div className="relative h-52">
              <img
                src={restaurant.image || "/placeholder.svg"}
                alt={restaurant.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
              <Badge className="absolute top-3 left-3 font-semibold text-xs px-3 py-1 bg-primary text-primary-foreground shadow-lg">
                {restaurant.category}
              </Badge>
              <div className="absolute bottom-3 left-3 right-3">
                <h3 className="font-bold text-lg text-white text-balance mb-1">{restaurant.name}</h3>
                <p className="text-xs text-white/90 line-clamp-1">{restaurant.description}</p>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-current text-yellow-500" />
                    <span className="font-semibold text-foreground">{restaurant.rating}</span>
                  </div>
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{restaurant.deliveryTime}</span>
                  </div>
                </div>
                <Badge variant="secondary" className="text-xs font-medium">
                  ${restaurant.priceRange}
                </Badge>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
