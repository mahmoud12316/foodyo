"use client"

import { Card } from "@/components/ui/card"
import { useRef } from "react"
import { useRouter } from "next/navigation"
import { Pizza, Beef, Coffee, Cake, Fish, Sandwich, Croissant, Salad } from "lucide-react"

const categories = [
  {
    label: "Pizza",
    icon: Pizza,
    color: "from-orange-100 to-orange-50",
    iconColor: "text-orange-600",
  },
  {
    label: "Burgers",
    icon: Beef,
    color: "from-red-100 to-red-50",
    iconColor: "text-red-600",
  },
  {
    label: "Desserts",
    icon: Cake,
    color: "from-pink-100 to-pink-50",
    iconColor: "text-pink-600",
  },
  {
    label: "Drinks",
    icon: Coffee,
    color: "from-amber-100 to-amber-50",
    iconColor: "text-amber-600",
  },
  {
    label: "Sushi",
    icon: Fish,
    color: "from-blue-100 to-blue-50",
    iconColor: "text-blue-600",
  },
  {
    label: "Shawarma",
    icon: Sandwich,
    color: "from-yellow-100 to-yellow-50",
    iconColor: "text-yellow-700",
  },
  {
    label: "Breakfast",
    icon: Croissant,
    color: "from-orange-100 to-orange-50",
    iconColor: "text-orange-700",
  },
  {
    label: "Healthy",
    icon: Salad,
    color: "from-green-100 to-green-50",
    iconColor: "text-green-600",
  },
]

export function CategoryGrid() {
  const scrollRef = useRef<HTMLDivElement>(null)
  const router = useRouter()

  return (
    <div className="mb-8">
      <h2 className="text-xl font-bold mb-4 text-foreground px-1">Browse by Category</h2>
      <div
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide snap-x snap-mandatory"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {categories.map((category) => {
          const IconComponent = category.icon
          return (
            <Card
              key={category.label}
              onClick={() => router.push(`/restaurants?category=${encodeURIComponent(category.label)}`)}
              className="flex-shrink-0 w-24 p-4 flex flex-col items-center justify-center gap-2 cursor-pointer hover:shadow-md hover:scale-105 transition-all border-border bg-white snap-start"
            >
              <div
                className={`w-14 h-14 rounded-full flex items-center justify-center bg-gradient-to-br ${category.color}`}
              >
                <IconComponent className={`w-7 h-7 ${category.iconColor}`} />
              </div>
              <span className="text-xs font-medium text-foreground text-center leading-tight">{category.label}</span>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
