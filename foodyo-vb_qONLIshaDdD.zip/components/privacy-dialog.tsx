"use client"

import { X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useEffect } from "react"

interface PrivacyDialogProps {
  isOpen: boolean
  onClose: () => void
}

export function PrivacyDialog({ isOpen, onClose }: PrivacyDialogProps) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    if (isOpen) {
      document.addEventListener("keydown", handleEscape)
      document.body.style.overflow = "hidden"
    }
    return () => {
      document.removeEventListener("keydown", handleEscape)
      document.body.style.overflow = "unset"
    }
  }, [isOpen, onClose])

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={onClose}>
        {/* Dialog */}
        <div
          className="bg-white rounded-2xl shadow-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-800">Privacy Policy</h2>
            <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
              <X className="w-5 h-5 text-gray-600" />
            </Button>
          </div>

          {/* Content */}
          <div className="p-6 space-y-4 text-gray-700">
            <section>
              <h3 className="font-semibold text-gray-800 mb-2">Information We Collect</h3>
              <p className="text-sm leading-relaxed">
                We collect information you provide directly to us, such as your name, email address, phone number, and
                delivery address when you create an account or place an order.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-gray-800 mb-2">How We Use Your Information</h3>
              <p className="text-sm leading-relaxed">
                We use the information we collect to process your orders, communicate with you about your orders,
                provide customer support, and improve our services.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-gray-800 mb-2">Data Security</h3>
              <p className="text-sm leading-relaxed">
                We implement appropriate security measures to protect your personal information from unauthorized
                access, alteration, disclosure, or destruction.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-gray-800 mb-2">Third-Party Services</h3>
              <p className="text-sm leading-relaxed">
                We may share your information with third-party service providers who assist us in operating our app,
                processing payments, and delivering orders.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-gray-800 mb-2">Your Rights</h3>
              <p className="text-sm leading-relaxed">
                You have the right to access, update, or delete your personal information at any time. Contact us if you
                wish to exercise these rights.
              </p>
            </section>

            <section>
              <h3 className="font-semibold text-gray-800 mb-2">Contact Us</h3>
              <p className="text-sm leading-relaxed">
                If you have any questions about our privacy policy, please contact us at privacy@foodyo.com
              </p>
            </section>
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-gray-100">
            <Button onClick={onClose} className="w-full bg-orange-500 hover:bg-orange-600 text-white">
              Close
            </Button>
          </div>
        </div>
      </div>
    </>
  )
}
