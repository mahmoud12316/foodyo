"use client"

import { X, Home, Search, Heart, User, ShoppingBag, Settings, LogOut, LogIn, Store, Bike } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useEffect, useState } from "react"
import { LogoutDialog } from "./logout-dialog"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { SignInPrompt } from "./sign-in-prompt"

interface SideNavProps {
  isOpen: boolean
  onClose: () => void
}

const menuItems = [
  { icon: Home, label: "Home", href: "/", requiresAuth: false },
  { icon: Search, label: "Search", href: "/search", requiresAuth: false },
  { icon: Heart, label: "Favorites", href: "/favorites", requiresAuth: true },
  { icon: User, label: "Profile", href: "/profile", requiresAuth: true },
  { icon: ShoppingBag, label: "Orders", href: "/orders", requiresAuth: true },
  { icon: Settings, label: "Settings", href: "/settings", requiresAuth: false },
  { icon: Store, label: "Restaurant Partner Portal", href: "/partner/signup", requiresAuth: false },
  { icon: Bike, label: "Driver Registration", href: "/driver/signup", requiresAuth: false },
]

export function SideNav({ isOpen, onClose }: SideNavProps) {
  const { isAuthenticated, isGuest, userName, logout } = useAuth()
  const [showLogoutDialog, setShowLogoutDialog] = useState(false)
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose()
    }
    if (isOpen) {
      document.addEventListener("keydown", handleEscape)
      document.body.style.overflow = "hidden"
    }
    return () => {
      document.removeEventListener("keydown", handleEscape)
      document.body.style.overflow = "unset"
    }
  }, [isOpen, onClose])

  const handleMenuClick = (item: (typeof menuItems)[0]) => {
    if (item.requiresAuth && isGuest) {
      setShowSignInPrompt(true)
    } else {
      console.log(`[v0] Navigating to ${item.href}`)
      onClose()
      router.push(item.href)
    }
  }

  const handleLogout = () => {
    setShowLogoutDialog(true)
  }

  const handleConfirmLogout = () => {
    logout()
    setShowLogoutDialog(false)
    onClose()
    router.push("/")
  }

  const handleLogin = () => {
    onClose()
    router.push("/login")
  }

  return (
    <>
      {/* Backdrop overlay */}
      <div
        className={`fixed inset-0 bg-black/50 z-50 transition-opacity duration-300 ${
          isOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={onClose}
      />

      {/* Side navigation panel */}
      <div
        className={`fixed top-0 left-0 h-full w-80 bg-white z-50 shadow-2xl rounded-r-3xl transition-transform duration-300 ease-out ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Close button */}
          <div className="flex justify-end p-4">
            <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
              <X className="w-5 h-5 text-[#555555]" />
            </Button>
          </div>

          {/* User profile section */}
          <div className="px-6 pb-6 border-b border-gray-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="text-2xl font-bold text-[#FF0000] opacity-100">Foodyo</div>
            </div>
            {isAuthenticated && userName ? (
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src="/placeholder.svg?height=64&width=64" />
                  <AvatarFallback className="bg-orange-100 text-[#FF6B00] text-xl font-semibold">
                    {userName.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm text-gray-500">Hi,</p>
                  <p className="text-lg font-semibold text-gray-800">{userName}</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-gray-100 text-gray-600 text-xl font-semibold">
                    <User className="w-8 h-8" />
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm text-gray-500">Welcome,</p>
                  <p className="text-lg font-semibold text-gray-800">Guest</p>
                </div>
              </div>
            )}
          </div>

          {/* Menu items */}
          <nav className="flex-1 overflow-y-auto py-4">
            <ul className="space-y-1 px-3">
              {!isAuthenticated && (
                <li className="pb-4 mb-4 border-b border-gray-100">
                  <button
                    onClick={handleLogin}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-lg text-[#FF6B00] hover:bg-orange-50 transition-colors duration-200"
                  >
                    <LogIn className="w-5 h-5" />
                    <span className="font-medium">Login</span>
                  </button>
                </li>
              )}
              {menuItems.map((item) => {
                const Icon = item.icon
                return (
                  <li key={item.label}>
                    <button
                      onClick={() => handleMenuClick(item)}
                      className="w-full flex items-center gap-4 px-4 py-3 rounded-lg text-gray-700 hover:bg-orange-50 hover:text-[#FF6B00] transition-colors duration-200"
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                      {item.requiresAuth && isGuest && <span className="ml-auto text-xs text-gray-400">🔒</span>}
                    </button>
                  </li>
                )
              })}
              {isAuthenticated && (
                <li className="pt-4 mt-4 border-t border-gray-100">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-4 px-4 py-3 rounded-lg text-[#FF6B00] hover:bg-orange-50 transition-colors duration-200"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="font-medium">Logout</span>
                  </button>
                </li>
              )}
            </ul>
          </nav>
        </div>
      </div>

      <LogoutDialog
        isOpen={showLogoutDialog}
        onCancel={() => setShowLogoutDialog(false)}
        onConfirm={handleConfirmLogout}
      />
      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
    </>
  )
}
