"use client"

import { Star, Clock, DollarSign } from "lucide-react"
import { Card } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { getRestaurantById } from "@/lib/demo-data"

interface Restaurant {
  id: number
  name: string
  category: string
  image: string
  rating: number
  deliveryTime: string
  deliveryFee: number
  status: string
}

interface Meal {
  id: number
  restaurantId: number
  name: string
  description: string
  price: number
  image: string
}

interface SearchResultsProps {
  restaurants: Restaurant[]
  meals: Meal[]
  query: string
  onClose: () => void
}

export function SearchResults({ restaurants, meals, query, onClose }: SearchResultsProps) {
  const hasResults = restaurants.length > 0 || meals.length > 0

  return (
    <Card className="absolute top-full mt-2 w-full bg-white shadow-xl border rounded-xl overflow-hidden z-50 max-h-[500px] overflow-y-auto">
      <div className="p-4">
        {!hasResults ? (
          <div className="text-center py-8 text-muted-foreground">
            <p className="text-lg font-medium">No results found</p>
            <p className="text-sm mt-1">Try searching for something else</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Restaurants Section */}
            {restaurants.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Restaurants ({restaurants.length})
                </h3>
                <div className="space-y-2">
                  {restaurants.map((restaurant) => (
                    <Link
                      key={restaurant.id}
                      href={`/restaurants/${restaurant.id}`}
                      onClick={onClose}
                      className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="relative w-16 h-16 flex-shrink-0 rounded-lg overflow-hidden">
                        <Image
                          src={restaurant.image || "/placeholder.svg"}
                          alt={restaurant.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-sm truncate">{restaurant.name}</h4>
                        <p className="text-xs text-muted-foreground">{restaurant.category}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-xs font-medium">{restaurant.rating}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-muted-foreground" />
                            <span className="text-xs">{restaurant.deliveryTime}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-3 h-3 text-muted-foreground" />
                            <span className="text-xs">${restaurant.deliveryFee}</span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}

            {/* Meals Section */}
            {meals.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
                  Meals ({meals.length})
                </h3>
                <div className="space-y-2">
                  {meals.slice(0, 10).map((meal) => {
                    const restaurant = getRestaurantById(meal.restaurantId)
                    return (
                      <Link
                        key={meal.id}
                        href={`/restaurants/${meal.restaurantId}`}
                        onClick={onClose}
                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="relative w-16 h-16 flex-shrink-0 rounded-lg overflow-hidden">
                          <Image src={meal.image || "/placeholder.svg"} alt={meal.name} fill className="object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold text-sm truncate">{meal.name}</h4>
                          <p className="text-xs text-muted-foreground line-clamp-1">{meal.description}</p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-xs text-muted-foreground">from {restaurant?.name}</span>
                            <span className="text-sm font-bold text-primary">${meal.price}</span>
                          </div>
                        </div>
                      </Link>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </Card>
  )
}
