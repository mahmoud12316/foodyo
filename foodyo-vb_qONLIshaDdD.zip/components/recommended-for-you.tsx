"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Clock, MapPin } from "lucide-react"
import { getAllRestaurants, initializeDemoData, type Restaurant } from "@/lib/demo-data"

export function RecommendedForYou() {
  const router = useRouter()
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])

  useEffect(() => {
    initializeDemoData()
    const allRestaurants = getAllRestaurants()
    const approvedRestaurants = allRestaurants.filter((r) => r.status === "approved" && r.isOpen)
    // Get different restaurants than popular (last 6)
    const recommended = approvedRestaurants.slice(-6)
    setRestaurants(recommended)
  }, [])

  if (restaurants.length === 0) return null

  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Recommended for You</h2>
          <p className="text-sm text-muted-foreground mt-1">Personalized picks based on your taste</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {restaurants.map((restaurant) => (
          <Card
            key={restaurant.id}
            onClick={() => router.push(`/restaurants/${restaurant.id}`)}
            className="overflow-hidden cursor-pointer hover:shadow-lg transition-all border-border bg-white group"
          >
            <div className="relative h-48">
              <img
                src={restaurant.image || "/placeholder.svg"}
                alt={restaurant.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <Badge className="absolute top-3 left-3 font-semibold text-xs px-3 py-1 bg-primary text-primary-foreground shadow-md">
                {restaurant.category}
              </Badge>
            </div>

            <div className="p-4">
              <h3 className="font-semibold text-base text-foreground text-balance mb-1">{restaurant.name}</h3>
              <p className="text-sm text-muted-foreground line-clamp-1 mb-3">{restaurant.description}</p>

              <div className="flex items-center gap-3 text-sm mb-2">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-current text-yellow-500" />
                  <span className="font-semibold text-foreground">{restaurant.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{restaurant.deliveryTime}</span>
                </div>
              </div>

              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <MapPin className="w-3 h-3" />
                <span className="line-clamp-1">{restaurant.address}</span>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
