"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, ChevronRight } from "lucide-react"
import { useRouter, useSearchParams } from "next/navigation"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

type Restaurant = {
  id: number
  name: string
  category: string
  image: string
  description: string
  rating: number
  deliveryTime: string
  isPartnerApproved: boolean
  isOpen: boolean
}

export default function RestaurantsPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [filteredRestaurants, setFilteredRestaurants] = useState<Restaurant[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const category = searchParams.get("category")
    setSelectedCategory(category)
  }, [searchParams])

  useEffect(() => {
    const mockRestaurants: Restaurant[] = [
      {
        id: 1,
        name: "Pizza Palace",
        category: "Italian",
        image: "/placeholder.svg?height=300&width=400",
        description: "Authentic Italian pizzas with fresh ingredients",
        rating: 4.8,
        deliveryTime: "20-30 min",
        isPartnerApproved: true,
        isOpen: JSON.parse(localStorage.getItem("restaurant_1_isOpen") || "true"),
      },
      {
        id: 2,
        name: "Burger House",
        category: "American",
        image: "/placeholder.svg?height=300&width=400",
        description: "Juicy burgers made with premium beef",
        rating: 4.7,
        deliveryTime: "25-35 min",
        isPartnerApproved: true,
        isOpen: JSON.parse(localStorage.getItem("restaurant_2_isOpen") || "true"),
      },
      {
        id: 3,
        name: "Sushi Master",
        category: "Japanese",
        image: "/placeholder.svg?height=300&width=400",
        description: "Fresh sushi and traditional Japanese cuisine",
        rating: 4.9,
        deliveryTime: "30-40 min",
        isPartnerApproved: true,
        isOpen: JSON.parse(localStorage.getItem("restaurant_3_isOpen") || "true"),
      },
      {
        id: 4,
        name: "Green Bowl",
        category: "Healthy",
        image: "/placeholder.svg?height=300&width=400",
        description: "Fresh salads and healthy meal options",
        rating: 4.6,
        deliveryTime: "15-25 min",
        isPartnerApproved: true,
        isOpen: JSON.parse(localStorage.getItem("restaurant_4_isOpen") || "true"),
      },
    ]

    const approved = mockRestaurants.filter((r) => r.isPartnerApproved)
    setRestaurants(approved)
    setFilteredRestaurants(approved)
    setLoading(false)
  }, [])

  useEffect(() => {
    let filtered = restaurants

    if (selectedCategory) {
      filtered = filtered.filter((r) => r.category.toLowerCase() === selectedCategory.toLowerCase())
    }

    if (searchQuery.trim() !== "") {
      filtered = filtered.filter(
        (r) =>
          r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    setFilteredRestaurants(filtered)
  }, [searchQuery, restaurants, selectedCategory])

  const clearCategoryFilter = () => {
    setSelectedCategory(null)
    router.push("/restaurants")
  }

  if (loading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-4 py-6 max-w-2xl">
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 bg-muted animate-pulse rounded-lg" />
            ))}
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            {selectedCategory ? `${selectedCategory} Restaurants` : "All Restaurants"}
          </h1>

          {selectedCategory && (
            <Button variant="outline" size="sm" onClick={clearCategoryFilter} className="mb-4 bg-transparent">
              Clear Filter: {selectedCategory}
            </Button>
          )}

          <Input
            type="text"
            placeholder="Search restaurants..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
        </div>

        {filteredRestaurants.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No restaurants found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredRestaurants.map((restaurant) => (
              <Card
                key={restaurant.id}
                className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-border"
                onClick={() => router.push(`/restaurants/${restaurant.id}`)}
              >
                <div className="relative">
                  <img
                    src={restaurant.image || "/placeholder.svg"}
                    alt={restaurant.name}
                    className="w-full h-48 object-cover"
                  />
                  <Badge className="absolute top-3 left-3 font-semibold text-xs px-3 py-1 bg-[#FF6600] text-white">
                    {restaurant.category}
                  </Badge>
                  {!restaurant.isOpen && (
                    <Badge className="absolute top-3 right-3 font-semibold text-xs px-3 py-1 bg-red-600 text-white">
                      Closed
                    </Badge>
                  )}
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-foreground text-balance mb-1">{restaurant.name}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{restaurant.description}</p>
                      {!restaurant.isOpen && (
                        <p className="text-sm text-red-600 font-medium mt-1">Currently not accepting orders</p>
                      )}
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 ml-2" />
                  </div>
                  <div className="flex items-center gap-4 mt-3">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-current text-[#FFC107]" />
                      <span className="text-sm font-medium text-foreground">{restaurant.rating}</span>
                    </div>
                    <div className="flex items-center gap-1 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{restaurant.deliveryTime}</span>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
