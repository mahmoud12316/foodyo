"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, MapPin, Clock, ArrowLeft, Plus, Heart, AlertCircle } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { SignInPrompt } from "@/components/sign-in-prompt"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { getRestaurantById, getMealsByRestaurantId, type Restaurant, type Meal } from "@/lib/demo-data"

export default function RestaurantDetailPage() {
  const router = useRouter()
  const params = useParams()
  const restaurantId = params.id as string
  const { addToCart, addToFavorites, removeFromFavorites, isFavorite } = useCart()
  const { isGuest } = useAuth()

  const [restaurant, setRestaurant] = useState<Restaurant | null>(null)
  const [meals, setMeals] = useState<Meal[]>([])
  const [loading, setLoading] = useState(true)
  const [showSignInPrompt, setShowSignInPrompt] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string>("all")

  useEffect(() => {
    const restaurantData = getRestaurantById(Number(restaurantId))
    const mealsData = getMealsByRestaurantId(Number(restaurantId))

    console.log("[v0] Loading restaurant:", restaurantId, restaurantData)
    console.log("[v0] Loading meals:", mealsData.length)

    setRestaurant(restaurantData)
    setMeals(mealsData)
    setLoading(false)
  }, [restaurantId])

  const handleAddToCart = (meal: Meal) => {
    if (isGuest) {
      setShowSignInPrompt(true)
      return
    }

    if (!restaurant?.isOpen) {
      return
    }

    if (meal.availabilityStatus === "sold_out") {
      return
    }

    addToCart({
      id: `meal-${meal.id}`,
      name: meal.name,
      restaurant: restaurant.name,
      price: meal.price,
      image: meal.image,
    })
  }

  const handleToggleFavorite = (meal: Meal) => {
    if (isGuest) {
      setShowSignInPrompt(true)
      return
    }

    const favoriteId = `meal-${meal.id}`

    if (isFavorite(favoriteId)) {
      removeFromFavorites(favoriteId)
    } else {
      addToFavorites({
        id: favoriteId,
        name: meal.name,
        restaurant: restaurant?.name || "",
        price: meal.price,
        image: meal.image,
        description: meal.description,
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-4 py-6 max-w-2xl">
          <div className="space-y-4">
            <div className="h-64 bg-muted animate-pulse rounded-lg" />
            <div className="h-32 bg-muted animate-pulse rounded-lg" />
          </div>
        </main>
      </div>
    )
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-4 py-6 max-w-2xl">
          <div className="text-center py-12">
            <p className="text-muted-foreground">Restaurant not found</p>
            <Button onClick={() => router.push("/")} className="mt-4 bg-[#FF6600] hover:bg-[#FF6600]/90">
              Back to Home
            </Button>
          </div>
        </main>
      </div>
    )
  }

  const availableMeals = meals.filter((meal) => meal.availabilityStatus === "available")
  const soldOutMeals = meals.filter((meal) => meal.availabilityStatus === "sold_out")
  const categories = ["all", ...Array.from(new Set(meals.map((m) => m.category)))]

  const filteredMeals =
    selectedCategory === "all"
      ? [...availableMeals, ...soldOutMeals]
      : [
          ...availableMeals.filter((m) => m.category === selectedCategory),
          ...soldOutMeals.filter((m) => m.category === selectedCategory),
        ]

  return (
    <>
      <div className="min-h-screen">
        <Header />
        <main className="container mx-auto px-4 py-6 max-w-2xl">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4 -ml-2">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          {!restaurant.isOpen && (
            <Alert className="mb-6 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-900 font-semibold">Restaurant Currently Closed</AlertTitle>
              <AlertDescription className="text-red-800">
                This restaurant is not accepting new orders at the moment. Please check back later.
              </AlertDescription>
            </Alert>
          )}

          <div className="mb-6">
            <div className="relative mb-4">
              <img
                src={restaurant.image || "/placeholder.svg"}
                alt={restaurant.name}
                className="w-full h-64 object-cover rounded-lg"
              />
              {!restaurant.isOpen && (
                <div className="absolute inset-0 bg-black bg-opacity-50 rounded-lg flex items-center justify-center">
                  <Badge className="text-lg px-6 py-2 bg-red-600 text-white font-bold">CLOSED</Badge>
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-foreground text-balance mb-1">{restaurant.name}</h1>
                  <p className="text-muted-foreground">{restaurant.description}</p>
                </div>
                <Badge className="bg-[#FF6600] text-white">{restaurant.category}</Badge>
              </div>

              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-current text-[#FFC107]" />
                  <span className="font-medium text-foreground">{restaurant.rating}</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  <span>{restaurant.deliveryTime}</span>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground">
                  <MapPin className="w-4 h-4" />
                  <span className="text-xs">{restaurant.address}</span>
                </div>
              </div>
            </div>
          </div>

          {categories.length > 1 && (
            <div className="mb-6 flex gap-2 overflow-x-auto pb-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className={
                    selectedCategory === category
                      ? "bg-[#FF6600] hover:bg-[#FF6600]/90 text-white"
                      : "border-border text-foreground"
                  }
                >
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </Button>
              ))}
            </div>
          )}

          {availableMeals.filter((m) => selectedCategory === "all" || m.category === selectedCategory).length > 0 && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold text-foreground mb-4">Menu</h2>
              <div className="space-y-4">
                {availableMeals
                  .filter((m) => selectedCategory === "all" || m.category === selectedCategory)
                  .map((meal) => (
                    <Card key={meal.id} className="overflow-hidden border-border hover:shadow-md transition-shadow">
                      <div className="flex gap-4 p-4">
                        <img
                          src={meal.image || "/placeholder.svg"}
                          alt={meal.name}
                          className="w-24 h-24 object-cover rounded-lg flex-shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-1">
                            <h3 className="font-semibold text-base text-foreground text-balance">{meal.name}</h3>
                            <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleToggleFavorite(meal)}
                                className="h-8 w-8 rounded-full hover:bg-orange-50"
                              >
                                <Heart
                                  className={`w-5 h-5 ${
                                    isFavorite(`meal-${meal.id}`) ? "fill-[#FF6600] text-[#FF6600]" : "text-gray-400"
                                  }`}
                                />
                              </Button>
                              <Badge className="bg-green-600 text-white">Available</Badge>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{meal.description}</p>
                          <div className="flex items-center justify-between">
                            <p className="text-lg font-bold text-[#FF6600]">${meal.price.toFixed(2)}</p>
                            <Button
                              size="sm"
                              className="bg-[#FF6600] hover:bg-[#FF6600]/90 text-white"
                              onClick={() => handleAddToCart(meal)}
                              disabled={!restaurant.isOpen}
                            >
                              <Plus className="w-4 h-4 mr-1" />
                              {restaurant.isOpen ? "Add to Cart" : "Closed"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
              </div>
            </div>
          )}

          {soldOutMeals.filter((m) => selectedCategory === "all" || m.category === selectedCategory).length > 0 && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold text-muted-foreground mb-4">Currently Unavailable</h2>
              <div className="space-y-4">
                {soldOutMeals
                  .filter((m) => selectedCategory === "all" || m.category === selectedCategory)
                  .map((meal) => (
                    <Card key={meal.id} className="overflow-hidden border-border opacity-60">
                      <div className="flex gap-4 p-4">
                        <img
                          src={meal.image || "/placeholder.svg"}
                          alt={meal.name}
                          className="w-24 h-24 object-cover rounded-lg flex-shrink-0 grayscale"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-1">
                            <h3 className="font-semibold text-base text-foreground text-balance">{meal.name}</h3>
                            <Badge className="bg-red-600 text-white ml-2">Sold Out</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{meal.description}</p>
                          <p className="text-lg font-bold text-muted-foreground">${meal.price.toFixed(2)}</p>
                        </div>
                      </div>
                    </Card>
                  ))}
              </div>
            </div>
          )}

          {filteredMeals.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No meals found in this category</p>
            </div>
          )}
        </main>
      </div>

      <SignInPrompt isOpen={showSignInPrompt} onClose={() => setShowSignInPrompt(false)} />
    </>
  )
}
