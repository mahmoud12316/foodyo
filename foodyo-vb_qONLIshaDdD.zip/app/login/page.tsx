"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { authenticateWithPi } from "@/lib/pi-sdk"
import { toast } from "sonner"

const ADMIN_EMAIL = "admin@foodyo.com"
const ADMIN_PASSWORD = "Adminfood@yo12316"

export default function LoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isPiLoginLoading, setIsPiLoginLoading] = useState(false)
  const [isPiSDKReady, setIsPiSDKReady] = useState(false)
  const { login, loginWithPi } = useAuth()
  const router = useRouter()

  useEffect(() => {
    console.log("[Foodyo Pi] Login page mounted, checking SDK...")

    const checkSDK = () => {
      if (typeof window !== "undefined") {
        const hasPi = typeof window.Pi !== "undefined"
        const isInit = (window as any).piSDKInitialized === true

        console.log("[Foodyo Pi] SDK Check:", {
          hasPi,
          isInit,
          piObject: window.Pi,
          hostname: window.location.hostname,
        })

        // Only mark as ready if BOTH Pi object exists AND it's initialized
        if (hasPi && isInit) {
          console.log("[Foodyo Pi] ✓ SDK is fully ready!")
          setIsPiSDKReady(true)
          return true
        }
      }
      return false
    }

    // Check immediately
    if (checkSDK()) return

    // Listen for SDK ready event
    const handleSDKReady = () => {
      console.log("[Foodyo Pi] Received piSDKReady event")
      if (checkSDK()) {
        console.log("[Foodyo Pi] Event confirmed SDK is ready")
      }
    }

    window.addEventListener("piSDKReady", handleSDKReady)

    // Polling as fallback - check every 500ms for 15 seconds
    let attempts = 0
    const maxAttempts = 30 // 15 seconds

    const interval = setInterval(() => {
      attempts++

      if (checkSDK()) {
        console.log(`[Foodyo Pi] ✓ SDK ready after ${attempts} attempts`)
        clearInterval(interval)
      } else if (attempts >= maxAttempts) {
        console.warn("[Foodyo Pi] ⚠ SDK not detected after 15 seconds")
        console.warn("[Foodyo Pi] Please ensure you're in Pi Browser or have authorized sandbox mode")
        clearInterval(interval)
        // DO NOT enable button if SDK isn't actually loaded
        setError("Pi SDK could not be loaded. Please use Pi Browser or authorize sandbox mode.")
      }
    }, 500)

    return () => {
      window.removeEventListener("piSDKReady", handleSDKReady)
      clearInterval(interval)
    }
  }, [])

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
      login("Admin", "admin")
      router.push("/admin")
      return
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters")
      return
    }

    const userName = email.split("@")[0]
    login(userName, "user")

    router.push("/")
  }

  const handlePiLogin = async () => {
    console.log("[Foodyo Pi] Login button clicked")
    console.log("[Foodyo Pi] SDK State:", {
      ready: isPiSDKReady,
      hasPi: typeof window !== "undefined" && typeof window.Pi !== "undefined",
      isInit: typeof window !== "undefined" && (window as any).piSDKInitialized,
    })

    setIsPiLoginLoading(true)
    setError("")

    try {
      const piAuth = await authenticateWithPi(true, true)

      if (piAuth) {
        console.log("[Foodyo Pi] Authentication successful:", piAuth)
        loginWithPi(piAuth.user.username || piAuth.user.uid, piAuth)
        toast.success(`Welcome ${piAuth.user.username || "Pi User"}!`)
        router.push("/")
      } else {
        throw new Error("Authentication returned no data")
      }
    } catch (err: any) {
      console.error("[Foodyo Pi] Authentication error:", err)
      const errorMessage = err.message || "Pi authentication failed"
      setError(errorMessage)
      toast.error(errorMessage)
    } finally {
      setIsPiLoginLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="space-y-2 text-center">
          <div className="flex justify-center mb-4">
            <div className="text-4xl font-bold text-orange-500">Foodyo</div>
          </div>
          <CardTitle className="text-2xl font-bold">Welcome Back</CardTitle>
          <CardDescription>Sign in to continue to your account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <Button
              type="button"
              onClick={handlePiLogin}
              disabled={isPiLoginLoading || !isPiSDKReady}
              className="w-full h-12 bg-purple-600 hover:bg-purple-700 text-white font-medium flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isPiLoginLoading ? (
                <>
                  <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Connecting to Pi...</span>
                </>
              ) : (
                <>
                  <svg className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z" />
                  </svg>
                  <span>Sign in with Pi Network</span>
                </>
              )}
            </Button>
            {!isPiSDKReady && !error && (
              <p className="text-xs text-orange-500 mt-2 text-center animate-pulse">
                ⏳ Initializing Pi Network SDK...
              </p>
            )}
            {isPiSDKReady && (
              <p className="text-xs text-green-600 font-medium mt-2 text-center flex items-center justify-center gap-1">
                <span className="text-green-500">✓</span> Pi Network Ready
              </p>
            )}
          </div>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="bg-white px-4 text-gray-500">Or continue with email</span>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="h-11"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="h-11"
              />
            </div>
            {error && <p className="text-sm text-red-500">{error}</p>}
            <Button type="submit" className="w-full h-11 bg-orange-500 hover:bg-orange-600 text-white font-medium">
              Sign In
            </Button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Don&apos;t have an account?{" "}
              <Link href="/signup" className="text-orange-500 font-medium hover:text-orange-600">
                Create Account
              </Link>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
