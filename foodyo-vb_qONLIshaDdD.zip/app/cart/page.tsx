"use client"

import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Trash2, ShoppingBag, Plus, Minus } from "lucide-react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"

export default function CartPage() {
  const { items, removeFromCart, updateQuantity, itemCount } = useCart()
  const { isAuthenticated } = useAuth()
  const router = useRouter()

  const subtotal = items.reduce((total, item) => total + item.price * item.quantity, 0)
  const deliveryFee = items.length > 0 ? 5 : 0
  const total = subtotal + deliveryFee

  if (!isAuthenticated) {
    router.push("/login")
    return null
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <Header />

      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Cart</h1>

        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 px-4">
            <div className="bg-white rounded-full p-8 mb-6 shadow-sm">
              <ShoppingBag className="w-16 h-16 text-gray-300" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Your cart is empty!</h2>
            <p className="text-gray-500 text-center mb-6">Add some delicious meals to get started</p>
            <Button onClick={() => router.push("/")} className="bg-[#FF6600] hover:bg-[#FF5500] text-white">
              Browse Menu
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {items.map((item) => (
              <div key={item.id} className="bg-white rounded-xl p-4 shadow-sm">
                <div className="flex gap-4">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    className="w-24 h-24 rounded-lg object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{item.name}</h3>
                    <p className="text-sm text-gray-500 mb-2">{item.restaurant}</p>
                    {item.addons && item.addons.length > 0 && (
                      <div className="mb-2">
                        {item.addons.map((addon) => (
                          <p key={addon.id} className="text-xs text-gray-600">
                            + {addon.name} (+${addon.price.toFixed(2)})
                          </p>
                        ))}
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <p className="text-lg font-bold text-[#FF6600]">${item.price.toFixed(2)}</p>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 bg-transparent"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="font-semibold w-8 text-center">{item.quantity}</span>
                        <Button
                          variant="outline"
                          size="icon"
                          className="h-8 w-8 bg-transparent"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                    onClick={() => removeFromCart(item.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}

            <div className="bg-white rounded-xl p-6 shadow-sm space-y-3">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Delivery Fee</span>
                <span>${deliveryFee.toFixed(2)}</span>
              </div>
              <div className="border-t pt-3 flex justify-between text-lg font-bold text-gray-900">
                <span>Total</span>
                <span className="text-[#FF6600]">${total.toFixed(2)}</span>
              </div>
            </div>

            <Button
              className="w-full bg-[#FF6600] hover:bg-[#FF5500] text-white py-6 text-lg font-semibold"
              onClick={() => router.push("/checkout")}
            >
              Proceed to Checkout ({itemCount} {itemCount === 1 ? "item" : "items"})
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
