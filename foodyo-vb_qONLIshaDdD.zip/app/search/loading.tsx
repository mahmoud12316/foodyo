import { Header } from "@/components/header"

export default function Loading() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="space-y-4">
          <div className="h-14 bg-muted animate-pulse rounded-2xl" />
          <div className="h-48 bg-muted animate-pulse rounded-lg" />
          <div className="h-48 bg-muted animate-pulse rounded-lg" />
        </div>
      </main>
    </div>
  )
}
