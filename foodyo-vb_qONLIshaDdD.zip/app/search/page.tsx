"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Star, MapPin, ChevronRight } from "lucide-react"
import { useRouter } from "next/navigation"

type Restaurant = {
  id: number
  name: string
  category: string
  image: string
  description: string
  rating: number
  deliveryTime: string
}

type Meal = {
  id: number
  name: string
  restaurantId: number
  restaurantName: string
  category: string
  image: string
  price: number
  availabilityStatus: string
}

export default function SearchPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])
  const [meals, setMeals] = useState<Meal[]>([])
  const [filteredRestaurants, setFilteredRestaurants] = useState<Restaurant[]>([])
  const [filteredMeals, setFilteredMeals] = useState<Meal[]>([])

  useEffect(() => {
    // Fetch restaurants and meals from database
    // Mock data for demonstration
    const mockRestaurants: Restaurant[] = [
      {
        id: 1,
        name: "Pizza Palace",
        category: "Italian",
        image: "/placeholder.svg?height=300&width=400",
        description: "Authentic Italian pizzas",
        rating: 4.8,
        deliveryTime: "20-30 min",
      },
      {
        id: 2,
        name: "Burger House",
        category: "American",
        image: "/placeholder.svg?height=300&width=400",
        description: "Juicy burgers",
        rating: 4.7,
        deliveryTime: "25-35 min",
      },
    ]

    const mockMeals: Meal[] = [
      {
        id: 1,
        name: "Margherita Pizza",
        restaurantId: 1,
        restaurantName: "Pizza Palace",
        category: "Pizza",
        image: "/placeholder.svg?height=200&width=200",
        price: 12.99,
        availabilityStatus: "Available",
      },
      {
        id: 2,
        name: "Classic Burger",
        restaurantId: 2,
        restaurantName: "Burger House",
        category: "Burgers",
        image: "/placeholder.svg?height=200&width=200",
        price: 10.99,
        availabilityStatus: "Available",
      },
    ]

    setRestaurants(mockRestaurants)
    setMeals(mockMeals)
  }, [])

  useEffect(() => {
    if (searchQuery.trim() === "") {
      setFilteredRestaurants([])
      setFilteredMeals([])
    } else {
      const query = searchQuery.toLowerCase()

      const matchedRestaurants = restaurants.filter(
        (r) =>
          r.name.toLowerCase().includes(query) ||
          r.category.toLowerCase().includes(query) ||
          r.description.toLowerCase().includes(query),
      )

      const matchedMeals = meals.filter(
        (m) =>
          m.name.toLowerCase().includes(query) ||
          m.category.toLowerCase().includes(query) ||
          m.restaurantName.toLowerCase().includes(query),
      )

      setFilteredRestaurants(matchedRestaurants)
      setFilteredMeals(matchedMeals)
    }
  }, [searchQuery, restaurants, meals])

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search restaurants or meals..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-14 bg-white border-gray-200 rounded-2xl shadow-sm text-base"
              autoFocus
            />
          </div>
        </div>

        {searchQuery.trim() === "" ? (
          <div className="text-center py-12">
            <Search className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Start typing to search for restaurants or meals</p>
          </div>
        ) : (
          <div className="space-y-8">
            {filteredRestaurants.length > 0 && (
              <div>
                <h2 className="text-lg font-bold text-foreground mb-4">Restaurants ({filteredRestaurants.length})</h2>
                <div className="space-y-4">
                  {filteredRestaurants.map((restaurant) => (
                    <Card
                      key={restaurant.id}
                      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-border"
                      onClick={() => router.push(`/restaurants/${restaurant.id}`)}
                    >
                      <div className="relative">
                        <img
                          src={restaurant.image || "/placeholder.svg"}
                          alt={restaurant.name}
                          className="w-full h-40 object-cover"
                        />
                        <Badge className="absolute top-3 left-3 font-semibold text-xs px-3 py-1 bg-[#FF6600] text-white">
                          {restaurant.category}
                        </Badge>
                      </div>
                      <div className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="font-bold text-base text-foreground mb-1">{restaurant.name}</h3>
                            <p className="text-sm text-muted-foreground line-clamp-1">{restaurant.description}</p>
                          </div>
                          <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 ml-2" />
                        </div>
                        <div className="flex items-center gap-4 mt-2">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-current text-[#FFC107]" />
                            <span className="text-sm font-medium text-foreground">{restaurant.rating}</span>
                          </div>
                          <div className="flex items-center gap-1 text-muted-foreground">
                            <MapPin className="w-4 h-4" />
                            <span className="text-sm">{restaurant.deliveryTime}</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {filteredMeals.length > 0 && (
              <div>
                <h2 className="text-lg font-bold text-foreground mb-4">Meals ({filteredMeals.length})</h2>
                <div className="grid grid-cols-1 gap-4">
                  {filteredMeals.map((meal) => (
                    <Card
                      key={meal.id}
                      className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow border-border"
                      onClick={() => router.push(`/restaurants/${meal.restaurantId}`)}
                    >
                      <div className="flex gap-4 p-4">
                        <img
                          src={meal.image || "/placeholder.svg"}
                          alt={meal.name}
                          className="w-24 h-24 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <h3 className="font-bold text-base text-foreground mb-1">{meal.name}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{meal.restaurantName}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-lg font-bold text-[#FF6600]">${meal.price.toFixed(2)}</span>
                            <Badge
                              variant="secondary"
                              className={
                                meal.availabilityStatus === "Available"
                                  ? "bg-green-100 text-green-700"
                                  : "bg-gray-100 text-gray-600"
                              }
                            >
                              {meal.availabilityStatus}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {filteredRestaurants.length === 0 && filteredMeals.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No results found for &quot;{searchQuery}&quot;</p>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
