"use client"

import { useState } from "react"
import { ChevronLeft, Globe, Moon, Bell, Shield, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { PrivacyDialog } from "@/components/privacy-dialog"

export default function SettingsPage() {
  const router = useRouter()
  const { settings, updateSettings } = useAuth()

  const [language, setLanguage] = useState(settings.language)
  const [theme, setTheme] = useState(settings.theme)
  const [notifications, setNotifications] = useState(settings.notifications)
  const [showPrivacyDialog, setShowPrivacyDialog] = useState(false)
  const [showSaveSuccess, setShowSaveSuccess] = useState(false)

  const handleSaveSettings = () => {
    updateSettings({
      language,
      theme,
      notifications,
    })
    setShowSaveSuccess(true)
    setTimeout(() => setShowSaveSuccess(false), 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="flex items-center gap-4 p-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="h-10 w-10">
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </Button>
          <h1 className="text-xl font-bold text-gray-800">Settings</h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Language Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
              <Globe className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-800">Language</h2>
              <p className="text-sm text-gray-500">Choose your preferred language</p>
            </div>
          </div>
          <div className="space-y-2">
            <button
              onClick={() => setLanguage("en")}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                language === "en" ? "border-orange-500 bg-orange-50" : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <span className="font-medium text-gray-800">English</span>
              {language === "en" && <Check className="w-5 h-5 text-orange-600" />}
            </button>
            <button
              onClick={() => setLanguage("ar")}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                language === "ar" ? "border-orange-500 bg-orange-50" : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <span className="font-medium text-gray-800">العربية (Arabic)</span>
              {language === "ar" && <Check className="w-5 h-5 text-orange-600" />}
            </button>
          </div>
        </div>

        {/* Theme Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
              <Moon className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-800">Theme</h2>
              <p className="text-sm text-gray-500">Choose your display theme</p>
            </div>
          </div>
          <div className="space-y-2">
            <button
              onClick={() => setTheme("light")}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                theme === "light" ? "border-orange-500 bg-orange-50" : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <span className="font-medium text-gray-800">Light Mode</span>
              {theme === "light" && <Check className="w-5 h-5 text-orange-600" />}
            </button>
            <button
              onClick={() => setTheme("dark")}
              className={`w-full flex items-center justify-between p-4 rounded-xl border-2 transition-all ${
                theme === "dark" ? "border-orange-500 bg-orange-50" : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <span className="font-medium text-gray-800">Dark Mode</span>
              {theme === "dark" && <Check className="w-5 h-5 text-orange-600" />}
            </button>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                <Bell className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h2 className="font-semibold text-gray-800">Push Notifications</h2>
                <p className="text-sm text-gray-500">Receive order updates and offers</p>
              </div>
            </div>
            <Switch checked={notifications} onCheckedChange={setNotifications} />
          </div>
        </div>

        {/* Privacy Section */}
        <div className="bg-white rounded-2xl shadow-sm p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
              <Shield className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-800">Privacy</h2>
              <p className="text-sm text-gray-500">View our privacy policy</p>
            </div>
          </div>
          <Button
            onClick={() => setShowPrivacyDialog(true)}
            variant="outline"
            className="w-full border-gray-300 hover:bg-gray-50"
          >
            View Privacy Policy
          </Button>
        </div>

        {/* Save Button */}
        <div className="sticky bottom-4">
          <Button
            onClick={handleSaveSettings}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white h-12 text-base font-semibold shadow-lg"
          >
            {showSaveSuccess ? "Settings Saved!" : "Save Settings"}
          </Button>
        </div>
      </div>

      <PrivacyDialog isOpen={showPrivacyDialog} onClose={() => setShowPrivacyDialog(false)} />
    </div>
  )
}
