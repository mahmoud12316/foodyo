"use client"

import { Header } from "@/components/header"
import { SearchBar } from "@/components/search-bar"
import { CategoryGrid } from "@/components/category-grid"
import { FeaturedRestaurants } from "@/components/featured-restaurants"
import { PopularNearYou } from "@/components/popular-near-you"
import { RecommendedForYou } from "@/components/recommended-for-you"
import { TopMeals } from "@/components/top-meals"

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Header />

      <main className="container mx-auto px-4 py-6 max-w-7xl">
        <SearchBar />
        <CategoryGrid />
        <FeaturedRestaurants />
        <PopularNearYou />
        <RecommendedForYou />
        <TopMeals />
      </main>
    </div>
  )
}
