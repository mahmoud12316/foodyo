import { type NextRequest, NextResponse } from "next/server"

// Mock data storage (in production, this would use the database)
let pricingTiers = [
  { id: 1, distance_max: 3.0, delivery_fee: 5.0 },
  { id: 2, distance_max: 7.0, delivery_fee: 8.0 },
  { id: 3, distance_max: 15.0, delivery_fee: 12.0 },
  { id: 4, distance_max: 999.0, delivery_fee: 20.0 },
]

export async function GET() {
  try {
    return NextResponse.json({ tiers: pricingTiers })
  } catch (error) {
    console.error("Error fetching delivery pricing:", error)
    return NextResponse.json({ error: "Failed to fetch pricing" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { distance_max, delivery_fee } = body

    if (!distance_max || !delivery_fee) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const newTier = {
      id: Math.max(...pricingTiers.map((t) => t.id), 0) + 1,
      distance_max: Number.parseFloat(distance_max),
      delivery_fee: Number.parseFloat(delivery_fee),
    }

    pricingTiers.push(newTier)
    pricingTiers.sort((a, b) => a.distance_max - b.distance_max)

    return NextResponse.json({ tier: newTier })
  } catch (error) {
    console.error("Error creating pricing tier:", error)
    return NextResponse.json({ error: "Failed to create pricing tier" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, distance_max, delivery_fee } = body

    const tierIndex = pricingTiers.findIndex((t) => t.id === id)
    if (tierIndex === -1) {
      return NextResponse.json({ error: "Tier not found" }, { status: 404 })
    }

    pricingTiers[tierIndex] = {
      ...pricingTiers[tierIndex],
      distance_max: Number.parseFloat(distance_max),
      delivery_fee: Number.parseFloat(delivery_fee),
    }

    pricingTiers.sort((a, b) => a.distance_max - b.distance_max)

    return NextResponse.json({ tier: pricingTiers[tierIndex] })
  } catch (error) {
    console.error("Error updating pricing tier:", error)
    return NextResponse.json({ error: "Failed to update pricing tier" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const id = Number.parseInt(searchParams.get("id") || "0")

    pricingTiers = pricingTiers.filter((t) => t.id !== id)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting pricing tier:", error)
    return NextResponse.json({ error: "Failed to delete pricing tier" }, { status: 500 })
  }
}
