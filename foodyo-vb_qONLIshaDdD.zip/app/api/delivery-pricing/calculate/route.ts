import { type NextRequest, NextResponse } from "next/server"

// Haversine formula to calculate distance between two coordinates
function calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371 // Earth's radius in kilometers
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2)

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  const distance = R * c

  return distance
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { restaurantLat, restaurantLng, deliveryLat, deliveryLng } = body

    if (!restaurantLat || !restaurantLng || !deliveryLat || !deliveryLng) {
      return NextResponse.json({ error: "Missing coordinates" }, { status: 400 })
    }

    // Calculate distance
    const distance = calculateDistance(restaurantLat, restaurantLng, deliveryLat, deliveryLng)

    // Fetch pricing tiers (in production, from database)
    const pricingTiers = [
      { distance_max: 3.0, delivery_fee: 5.0 },
      { distance_max: 7.0, delivery_fee: 8.0 },
      { distance_max: 15.0, delivery_fee: 12.0 },
      { distance_max: 999.0, delivery_fee: 20.0 },
    ]

    // Find applicable fee
    let deliveryFee = 5.0 // default
    for (const tier of pricingTiers) {
      if (distance <= tier.distance_max) {
        deliveryFee = tier.delivery_fee
        break
      }
    }

    return NextResponse.json({
      distance: Number.parseFloat(distance.toFixed(2)),
      deliveryFee: deliveryFee,
    })
  } catch (error) {
    console.error("Error calculating delivery fee:", error)
    return NextResponse.json({ error: "Failed to calculate delivery fee" }, { status: 500 })
  }
}
