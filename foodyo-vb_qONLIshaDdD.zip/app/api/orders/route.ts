import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const orderData = await request.json()

    // In production, this would insert into the database
    // For now, simulate order creation
    const orderId = Math.floor(100000 + Math.random() * 900000)

    const itemsWithAddons = orderData.items.map((item: any) => {
      const basePrice = item.price
      const addonsPrice = item.addons?.reduce((sum: number, addon: any) => sum + addon.price, 0) || 0
      return {
        ...item,
        totalPrice: basePrice + addonsPrice,
      }
    })

    console.log("Creating order with calculated delivery fee:", {
      ...orderData,
      items: itemsWithAddons,
      deliveryFee: orderData.deliveryFee,
      total: orderData.total,
    })

    // Return success with order ID
    return NextResponse.json({
      success: true,
      orderId: orderId,
      message: "Order placed successfully",
    })
  } catch (error) {
    console.error("Order creation error:", error)
    return NextResponse.json({ success: false, error: "Failed to create order" }, { status: 500 })
  }
}
