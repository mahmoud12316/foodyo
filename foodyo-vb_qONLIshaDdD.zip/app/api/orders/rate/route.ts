import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { orderId, restaurantRating, driverRating } = await request.json()

    // Validate ratings
    if (!orderId || !restaurantRating || !driverRating) {
      return NextResponse.json({ error: "Order ID and ratings are required" }, { status: 400 })
    }

    if (restaurantRating < 1 || restaurantRating > 5 || driverRating < 1 || driverRating > 5) {
      return NextResponse.json({ error: "Ratings must be between 1 and 5" }, { status: 400 })
    }

    // In a real app, update the database
    // await db.query(
    //   'UPDATE orders SET restaurant_rating = $1, driver_rating = $2, rated_at = NOW() WHERE id = $3',
    //   [restaurantRating, driverRating, orderId]
    // )

    return NextResponse.json({
      success: true,
      message: "Rating submitted successfully",
    })
  } catch (error) {
    console.error("Rating submission error:", error)
    return NextResponse.json({ error: "Failed to submit rating" }, { status: 500 })
  }
}
