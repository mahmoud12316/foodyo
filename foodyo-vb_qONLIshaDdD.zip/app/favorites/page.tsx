"use client"

import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { ArrowLeft, Heart, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

export default function FavoritesPage() {
  const { favorites, removeFromFavorites, addToCart } = useCart()
  const { isAuthenticated, isGuest } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (isGuest) {
      router.push("/login")
    }
  }, [isGuest, router])

  const handleAddToCart = (favorite: any) => {
    addToCart({
      id: favorite.id,
      name: favorite.name,
      restaurant: favorite.restaurant,
      price: favorite.price,
      image: favorite.image,
    })
  }

  if (isGuest) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-[#E0E0E0]">
        <div className="flex items-center gap-4 px-4 py-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.push("/")}
            className="h-10 w-10 rounded-full hover:bg-orange-50"
          >
            <ArrowLeft className="w-5 h-5 text-[#555555]" />
          </Button>
          <h1 className="text-xl font-bold text-[#FF6600] flex items-center gap-2">
            My Favorites <Heart className="w-5 h-5 fill-[#FF6600]" />
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6">
        {favorites.length === 0 ? (
          // Empty state
          <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
            <div className="w-48 h-48 mb-6 relative">
              <Image
                src="/placeholder.svg?height=192&width=192"
                alt="No favorites"
                fill
                className="object-contain opacity-50"
              />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-3">No Favorites Yet</h2>
            <p className="text-gray-600 mb-6 max-w-md">
              You haven't added any favorites yet. Explore delicious meals and tap the heart to save them!
            </p>
            <Button
              onClick={() => router.push("/")}
              className="bg-[#FF6600] hover:bg-[#FF5500] text-white rounded-full px-8 py-6 text-base font-semibold shadow-lg"
            >
              Explore Menu
            </Button>
          </div>
        ) : (
          // Favorites list
          <div className="space-y-4">
            {favorites.map((favorite) => (
              <div
                key={favorite.id}
                className="bg-white rounded-2xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-200"
              >
                <div className="flex gap-4 p-4">
                  {/* Image */}
                  <div className="relative w-28 h-28 flex-shrink-0 rounded-xl overflow-hidden">
                    <Image
                      src={favorite.image || "/placeholder.svg"}
                      alt={favorite.name}
                      fill
                      className="object-cover"
                    />
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-gray-900 text-lg truncate">{favorite.name}</h3>
                        <p className="text-sm text-gray-600 truncate">{favorite.description}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFromFavorites(favorite.id)}
                        className="h-9 w-9 rounded-full hover:bg-red-50 flex-shrink-0"
                      >
                        <Heart className="w-5 h-5 fill-[#FF6600] text-[#FF6600]" />
                      </Button>
                    </div>

                    <div className="flex items-center justify-between gap-3 mt-3">
                      <span className="text-lg font-bold text-[#FF6600]">
                        {favorite.price != null ? `$${favorite.price.toFixed(2)}` : "Price not available"}
                      </span>
                      <Button
                        onClick={() => handleAddToCart(favorite)}
                        className="bg-[#FF6600] hover:bg-[#FF5500] text-white rounded-full px-6 py-2 text-sm font-semibold shadow-md flex items-center gap-2"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
