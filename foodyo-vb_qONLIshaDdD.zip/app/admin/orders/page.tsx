"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Package,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  Edit,
  Search,
  Filter,
  MapPin,
  Navigation,
  RefreshCw,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import Image from "next/image"

type OrderItem = {
  name: string
  image: string
  quantity: number
  price: number
}

type Order = {
  id: string
  customer: string
  email: string
  restaurant: string
  status: "Pending" | "Preparing" | "On the way" | "Delivered" | "Cancelled"
  total: number
  deliveryFee: number
  date: string
  time: string
  items: OrderItem[]
  address: string
  phone: string
  paymentMethod: string
  notes?: string
  restaurantLocation: { lat: number; lng: number; address: string }
  customerLocation: { lat: number; lng: number; address: string }
  driverLocation?: { lat: number; lng: number; name: string }
  estimatedDelivery?: string
}

export default function OrdersManagement() {
  const router = useRouter()
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [isStatusOpen, setIsStatusOpen] = useState(false)
  const [isMapOpen, setIsMapOpen] = useState(false)
  const [mapRefreshKey, setMapRefreshKey] = useState(0)

  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [emailFilter, setEmailFilter] = useState<string>("")
  const [dateFromFilter, setDateFromFilter] = useState<string>("")
  const [dateToFilter, setDateToFilter] = useState<string>("")

  const [orders, setOrders] = useState<Order[]>([
    {
      id: "#1234",
      customer: "John Doe",
      email: "john.doe@email.com",
      restaurant: "Pizza Palace",
      status: "Pending",
      total: 45.99,
      deliveryFee: 5.0,
      date: "2025-01-15",
      time: "10 mins ago",
      items: [
        { name: "Margherita Pizza", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 18.99 },
        { name: "Garlic Bread", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 6.0 },
        { name: "Coke", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 3.0 },
      ],
      address: "123 Main St, Apt 4B",
      phone: "+1 234-567-8900",
      paymentMethod: "Credit Card",
      notes: "Please ring the doorbell twice",
      restaurantLocation: { lat: 40.7589, lng: -73.9851, address: "Pizza Palace, 456 Restaurant Ave" },
      customerLocation: { lat: 40.7489, lng: -73.9681, address: "123 Main St, Apt 4B" },
      driverLocation: { lat: 40.7539, lng: -73.9751, name: "Mike Driver" },
      estimatedDelivery: "25 mins",
    },
    {
      id: "#1235",
      customer: "Sarah Smith",
      email: "sarah.smith@email.com",
      restaurant: "Burger House",
      status: "Delivered",
      total: 32.5,
      deliveryFee: 4.5,
      date: "2025-01-15",
      time: "25 mins ago",
      items: [
        { name: "Cheeseburger", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 12.99 },
        { name: "Fries", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 4.99 },
        { name: "Milkshake", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 6.0 },
      ],
      address: "456 Oak Ave, Suite 12",
      phone: "+1 234-567-8901",
      paymentMethod: "Cash on Delivery",
      restaurantLocation: { lat: 40.7489, lng: -73.9881, address: "Burger House, 789 Food St" },
      customerLocation: { lat: 40.7389, lng: -73.9781, address: "456 Oak Ave, Suite 12" },
      estimatedDelivery: "Delivered",
    },
    {
      id: "#1236",
      customer: "Mike Johnson",
      email: "mike.j@email.com",
      restaurant: "Sushi Bar",
      status: "On the way",
      total: 67.8,
      deliveryFee: 6.0,
      date: "2025-01-15",
      time: "5 mins ago",
      items: [
        { name: "California Roll", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 15.99 },
        { name: "Salmon Sashimi", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 22.99 },
        { name: "Miso Soup", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 4.0 },
      ],
      address: "789 Pine Rd",
      phone: "+1 234-567-8902",
      paymentMethod: "Debit Card",
      notes: "Leave at the door",
      restaurantLocation: { lat: 40.7689, lng: -73.9951, address: "Sushi Bar, 321 Sushi Lane" },
      customerLocation: { lat: 40.7589, lng: -73.9851, address: "789 Pine Rd" },
      driverLocation: { lat: 40.7639, lng: -73.9901, name: "Sarah Driver" },
      estimatedDelivery: "12 mins",
    },
    {
      id: "#1237",
      customer: "Emma Wilson",
      email: "emma.w@email.com",
      restaurant: "Taco Town",
      status: "Cancelled",
      total: 28.0,
      deliveryFee: 3.5,
      date: "2025-01-14",
      time: "1 hour ago",
      items: [
        { name: "Beef Tacos", image: "/placeholder.svg?height=80&width=80", quantity: 3, price: 8.99 },
        { name: "Nachos", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 7.99 },
      ],
      address: "321 Elm St",
      phone: "+1 234-567-8903",
      paymentMethod: "Credit Card",
      restaurantLocation: { lat: 40.7289, lng: -73.9651, address: "Taco Town, 654 Taco Blvd" },
      customerLocation: { lat: 40.7189, lng: -73.9551, address: "321 Elm St" },
      estimatedDelivery: "Cancelled",
    },
    {
      id: "#1238",
      customer: "David Brown",
      email: "david.brown@email.com",
      restaurant: "Pasta Paradise",
      status: "Preparing",
      total: 52.3,
      deliveryFee: 5.5,
      date: "2025-01-15",
      time: "15 mins ago",
      items: [
        { name: "Carbonara", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 16.99 },
        { name: "Caesar Salad", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 9.99 },
        { name: "Tiramisu", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 8.99 },
      ],
      address: "654 Maple Dr",
      phone: "+1 234-567-8904",
      paymentMethod: "PayPal",
      restaurantLocation: { lat: 40.7789, lng: -73.9751, address: "Pasta Paradise, 987 Pasta Way" },
      customerLocation: { lat: 40.7689, lng: -73.9651, address: "654 Maple Dr" },
      driverLocation: { lat: 40.7739, lng: -73.9701, name: "John Driver" },
      estimatedDelivery: "30 mins",
    },
    {
      id: "#1239",
      customer: "Lisa Anderson",
      email: "lisa.a@email.com",
      restaurant: "Coffee Corner",
      status: "Preparing",
      total: 18.5,
      deliveryFee: 3.0,
      date: "2025-01-15",
      time: "8 mins ago",
      items: [
        { name: "Cappuccino", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 5.99 },
        { name: "Croissant", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 3.99 },
        { name: "Muffin", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 3.5 },
      ],
      address: "987 Cedar Ln",
      phone: "+1 234-567-8905",
      paymentMethod: "Credit Card",
      notes: "Extra napkins please",
      restaurantLocation: { lat: 40.7389, lng: -73.9551, address: "Coffee Corner, 123 Coffee St" },
      customerLocation: { lat: 40.7289, lng: -73.9451, address: "987 Cedar Ln" },
      driverLocation: { lat: 40.7339, lng: -73.9501, name: "Emma Driver" },
      estimatedDelivery: "18 mins",
    },
  ])

  const filteredOrders = orders.filter((order) => {
    const matchesStatus = statusFilter === "all" || order.status === statusFilter
    const matchesEmail = emailFilter === "" || order.email.toLowerCase().includes(emailFilter.toLowerCase())
    const matchesDateFrom = dateFromFilter === "" || new Date(order.date) >= new Date(dateFromFilter)
    const matchesDateTo = dateToFilter === "" || new Date(order.date) <= new Date(dateToFilter)

    return matchesStatus && matchesEmail && matchesDateFrom && matchesDateTo
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "bg-yellow-100 text-yellow-800"
      case "Preparing":
        return "bg-blue-100 text-blue-800"
      case "On the way":
        return "bg-purple-100 text-purple-800"
      case "Delivered":
        return "bg-green-100 text-green-800"
      case "Cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Pending":
        return <Clock className="h-4 w-4" />
      case "Preparing":
        return <Package className="h-4 w-4" />
      case "On the way":
        return <Package className="h-4 w-4" />
      case "Delivered":
        return <CheckCircle className="h-4 w-4" />
      case "Cancelled":
        return <XCircle className="h-4 w-4" />
      default:
        return null
    }
  }

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order)
    setIsDetailsOpen(true)
  }

  const handleChangeStatus = (order: Order) => {
    setSelectedOrder(order)
    setIsStatusOpen(true)
  }

  const updateOrderStatus = (newStatus: "Pending" | "Preparing" | "On the way" | "Delivered" | "Cancelled") => {
    if (selectedOrder) {
      setOrders(orders.map((order) => (order.id === selectedOrder.id ? { ...order, status: newStatus } : order)))
      setIsStatusOpen(false)
      setSelectedOrder(null)
    }
  }

  const clearFilters = () => {
    setStatusFilter("all")
    setEmailFilter("")
    setDateFromFilter("")
    setDateToFilter("")
  }

  const handleTrackOrder = (order: Order) => {
    setSelectedOrder(order)
    setIsMapOpen(true)
  }

  const handleRefreshMap = () => {
    setMapRefreshKey((prev) => prev + 1)
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/admin")} variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-[#FF6600]">Orders Management</h1>
              <p className="text-gray-600 text-sm">View and manage all customer orders</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="h-5 w-5 text-[#FF6600]" />
            <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Preparing">Preparing</SelectItem>
                  <SelectItem value="On the way">On the way</SelectItem>
                  <SelectItem value="Delivered">Delivered</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">User Email</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search by email..."
                  value={emailFilter}
                  onChange={(e) => setEmailFilter(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date From</label>
              <Input type="date" value={dateFromFilter} onChange={(e) => setDateFromFilter(e.target.value)} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date To</label>
              <Input type="date" value={dateToFilter} onChange={(e) => setDateToFilter(e.target.value)} />
            </div>
          </div>
          <div className="mt-4 flex justify-end">
            <Button onClick={clearFilters} variant="outline" size="sm">
              Clear Filters
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Order ID</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Customer</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Restaurant</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Total</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Date & Time</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{order.id}</td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-medium text-gray-900">{order.customer}</div>
                      <div className="text-xs text-gray-500">{order.email}</div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-700">{order.restaurant}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-[#FF6600]">${order.total.toFixed(2)}</td>
                    <td className="px-6 py-4">
                      <div className="text-sm text-gray-900">{order.date}</div>
                      <div className="text-xs text-gray-500">{order.time}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}
                      >
                        {getStatusIcon(order.status)}
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Button
                          onClick={() => handleViewDetails(order)}
                          variant="outline"
                          size="sm"
                          className="text-[#FF6600] border-[#FF6600] hover:bg-[#FF6600] hover:text-white"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button
                          onClick={() => handleChangeStatus(order)}
                          variant="outline"
                          size="sm"
                          className="text-blue-600 border-blue-600 hover:bg-blue-600 hover:text-white"
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Status
                        </Button>
                        <Button
                          onClick={() => handleTrackOrder(order)}
                          variant="outline"
                          size="sm"
                          className="text-green-600 border-green-600 hover:bg-green-600 hover:text-white"
                        >
                          <MapPin className="h-4 w-4 mr-1" />
                          Track
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredOrders.length === 0 && (
              <div className="text-center py-12">
                <p className="text-gray-500">No orders found matching your filters.</p>
              </div>
            )}
          </div>
        </div>
      </main>

      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#FF6600]">Order Details</DialogTitle>
            <DialogDescription>Complete information about order {selectedOrder?.id}</DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-gray-700">Order ID</p>
                  <p className="text-sm text-gray-900">{selectedOrder.id}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">Status</p>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedOrder.status)}`}
                  >
                    {getStatusIcon(selectedOrder.status)}
                    {selectedOrder.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-gray-700">Customer Name</p>
                  <p className="text-sm text-gray-900">{selectedOrder.customer}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">Email</p>
                  <p className="text-sm text-gray-900">{selectedOrder.email}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-gray-700">Phone</p>
                  <p className="text-sm text-gray-900">{selectedOrder.phone}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">Payment Method</p>
                  <p className="text-sm text-gray-900">{selectedOrder.paymentMethod}</p>
                </div>
              </div>

              <div>
                <p className="text-sm font-semibold text-gray-700">Delivery Address</p>
                <p className="text-sm text-gray-900">{selectedOrder.address}</p>
              </div>

              <div>
                <p className="text-sm font-semibold text-gray-700">Restaurant</p>
                <p className="text-sm text-gray-900">{selectedOrder.restaurant}</p>
              </div>

              {selectedOrder.notes && (
                <div>
                  <p className="text-sm font-semibold text-gray-700">Notes</p>
                  <p className="text-sm text-gray-900 bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                    {selectedOrder.notes}
                  </p>
                </div>
              )}

              <div>
                <p className="text-sm font-semibold text-gray-700 mb-3">Ordered Items</p>
                <div className="space-y-3">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex items-center gap-4 bg-gray-50 p-3 rounded-lg">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        width={60}
                        height={60}
                        className="rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-500">Quantity: {item.quantity}</p>
                      </div>
                      <p className="text-sm font-semibold text-[#FF6600]">${item.price.toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Subtotal</span>
                    <span className="text-gray-900">
                      ${(selectedOrder.total - selectedOrder.deliveryFee).toFixed(2)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Delivery Fee</span>
                    <span className="text-gray-900">${selectedOrder.deliveryFee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-lg font-bold border-t pt-2">
                    <span className="text-gray-900">Total</span>
                    <span className="text-[#FF6600]">${selectedOrder.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="text-sm text-gray-500">
                <p>
                  Order placed: {selectedOrder.date} ({selectedOrder.time})
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isStatusOpen} onOpenChange={setIsStatusOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#FF6600]">Change Order Status</DialogTitle>
            <DialogDescription>Update the status of order {selectedOrder?.id}</DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">Current Status</p>
                <span
                  className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedOrder.status)}`}
                >
                  {getStatusIcon(selectedOrder.status)}
                  {selectedOrder.status}
                </span>
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-2">Select New Status</p>
                <Select
                  defaultValue={selectedOrder.status}
                  onValueChange={(value) =>
                    updateOrderStatus(value as "Pending" | "Preparing" | "On the way" | "Delivered" | "Cancelled")
                  }
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Preparing">Preparing</SelectItem>
                    <SelectItem value="On the way">On the way</SelectItem>
                    <SelectItem value="Delivered">Delivered</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isMapOpen} onOpenChange={setIsMapOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div>
                <DialogTitle className="text-[#FF6600] text-xl">Live Order Tracking</DialogTitle>
                <DialogDescription>Real-time delivery tracking for order {selectedOrder?.id}</DialogDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  onClick={handleRefreshMap}
                  variant="outline"
                  size="sm"
                  className="text-[#FF6600] bg-transparent"
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Refresh
                </Button>
              </div>
            </div>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-orange-50 to-white p-4 rounded-lg border border-orange-200">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <p className="text-xs font-semibold text-gray-600 mb-1">Order ID</p>
                    <p className="text-sm font-bold text-gray-900">{selectedOrder.id}</p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-gray-600 mb-1">Driver</p>
                    <p className="text-sm font-bold text-gray-900">
                      {selectedOrder.driverLocation?.name || "Not assigned"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-gray-600 mb-1">Estimated Delivery</p>
                    <p className="text-sm font-bold text-[#FF6600]">{selectedOrder.estimatedDelivery}</p>
                  </div>
                </div>
              </div>

              <div
                className="relative bg-gray-100 rounded-xl overflow-hidden border-2 border-gray-200"
                style={{ height: "500px" }}
              >
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-green-50 to-yellow-50 opacity-30"></div>

                <div
                  className="absolute inset-0"
                  style={{
                    backgroundImage:
                      "linear-gradient(rgba(0,0,0,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0,0,0,0.05) 1px, transparent 1px)",
                    backgroundSize: "50px 50px",
                  }}
                ></div>

                <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ zIndex: 1 }}>
                  <defs>
                    <marker id="arrowhead" markerWidth="10" markerHeight="10" refX="9" refY="3" orient="auto">
                      <polygon points="0 0, 10 3, 0 6" fill="#FF6600" />
                    </marker>
                  </defs>
                  {selectedOrder.driverLocation && (
                    <line
                      x1="20%"
                      y1="30%"
                      x2="50%"
                      y2="50%"
                      stroke="#FF6600"
                      strokeWidth="3"
                      strokeDasharray="10,5"
                      opacity="0.6"
                    />
                  )}
                  {selectedOrder.driverLocation && (
                    <line
                      x1="50%"
                      y1="50%"
                      x2="80%"
                      y2="70%"
                      stroke="#FF6600"
                      strokeWidth="3"
                      strokeDasharray="10,5"
                      opacity="0.6"
                      markerEnd="url(#arrowhead)"
                    />
                  )}
                  {!selectedOrder.driverLocation && (
                    <line
                      x1="20%"
                      y1="30%"
                      x2="80%"
                      y2="70%"
                      stroke="#FF6600"
                      strokeWidth="3"
                      strokeDasharray="10,5"
                      opacity="0.6"
                      markerEnd="url(#arrowhead)"
                    />
                  )}
                </svg>

                <div
                  className="absolute"
                  style={{ left: "20%", top: "30%", transform: "translate(-50%, -50%)", zIndex: 2 }}
                >
                  <div className="relative">
                    <div className="bg-red-500 rounded-full p-4 shadow-lg border-4 border-white animate-pulse">
                      <Package className="h-8 w-8 text-white" />
                    </div>
                    <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-white px-3 py-2 rounded-lg shadow-lg border border-gray-200 whitespace-nowrap">
                      <p className="text-xs font-bold text-gray-900">{selectedOrder.restaurant}</p>
                      <p className="text-xs text-gray-600">{selectedOrder.restaurantLocation.address}</p>
                    </div>
                  </div>
                </div>

                {selectedOrder.driverLocation && (
                  <div
                    className="absolute"
                    style={{ left: "50%", top: "50%", transform: "translate(-50%, -50%)", zIndex: 3 }}
                  >
                    <div className="relative">
                      <div className="bg-[#FF6600] rounded-full p-4 shadow-lg border-4 border-white">
                        <Navigation className="h-8 w-8 text-white" />
                      </div>
                      <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-white px-3 py-2 rounded-lg shadow-lg border border-orange-200 whitespace-nowrap">
                        <p className="text-xs font-bold text-[#FF6600]">{selectedOrder.driverLocation.name}</p>
                        <p className="text-xs text-gray-600">En route</p>
                      </div>
                      <div className="absolute inset-0 bg-[#FF6600] rounded-full animate-ping opacity-20"></div>
                    </div>
                  </div>
                )}

                <div
                  className="absolute"
                  style={{ left: "80%", top: "70%", transform: "translate(-50%, -50%)", zIndex: 2 }}
                >
                  <div className="relative">
                    <div className="bg-green-500 rounded-full p-4 shadow-lg border-4 border-white">
                      <MapPin className="h-8 w-8 text-white" />
                    </div>
                    <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-white px-3 py-2 rounded-lg shadow-lg border border-gray-200 whitespace-nowrap">
                      <p className="text-xs font-bold text-gray-900">{selectedOrder.customer}</p>
                      <p className="text-xs text-gray-600">{selectedOrder.customerLocation.address}</p>
                    </div>
                  </div>
                </div>

                <div
                  className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow-lg border border-gray-200"
                  style={{ zIndex: 4 }}
                >
                  <p className="text-xs font-bold text-gray-900 mb-2">Legend</p>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <p className="text-xs text-gray-700">Restaurant</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-[#FF6600] rounded-full"></div>
                      <p className="text-xs text-gray-700">Driver</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <p className="text-xs text-gray-700">Customer</p>
                    </div>
                  </div>
                </div>

                <div
                  className="absolute top-4 right-4 bg-white px-4 py-2 rounded-lg shadow-lg border border-gray-200"
                  style={{ zIndex: 4 }}
                >
                  <span
                    className={`inline-flex items-center gap-1 text-sm font-medium ${getStatusColor(selectedOrder.status)}`}
                  >
                    {getStatusIcon(selectedOrder.status)}
                    {selectedOrder.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Package className="h-5 w-5 text-red-600" />
                    <p className="text-sm font-bold text-gray-900">Restaurant Location</p>
                  </div>
                  <p className="text-sm text-gray-700">{selectedOrder.restaurantLocation.address}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Lat: {selectedOrder.restaurantLocation.lat}, Lng: {selectedOrder.restaurantLocation.lng}
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-5 w-5 text-green-600" />
                    <p className="text-sm font-bold text-gray-900">Delivery Location</p>
                  </div>
                  <p className="text-sm text-gray-700">{selectedOrder.customerLocation.address}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    Lat: {selectedOrder.customerLocation.lat}, Lng: {selectedOrder.customerLocation.lng}
                  </p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
