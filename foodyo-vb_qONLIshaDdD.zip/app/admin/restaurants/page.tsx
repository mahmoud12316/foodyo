"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import {
  ArrowLeft,
  Store,
  Plus,
  Edit,
  Trash2,
  X,
  Star,
  Check,
  Phone,
  Globe,
  MapPin,
  Utensils,
  UserIcon,
  Mail,
  RefreshCw,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import MapPicker from "@/components/map-picker"

type Restaurant = {
  id: number
  name: string
  category: string
  image: string
  description: string
  latitude: number | null
  longitude: number | null
  averageRating: number | null
  totalRatings: number
  meals: Meal[]
  status: "pending" | "approved" | "rejected"
  ownerName?: string
  email?: string
  phone?: string
  website?: string
  address?: string
  createdAt?: string
}

type PendingRestaurant = {
  id: number
  ownerName: string
  email: string
  restaurantName: string
  phone: string
  website: string
  address: string
  cuisineType: string
  createdAt: string
}

type Meal = {
  id: number
  name: string
  image: string
  price: number
  category: string
}

export default function ManageRestaurants() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"restaurants" | "meals" | "pending">("restaurants")
  const [statusFilter, setStatusFilter] = useState<"all" | "pending" | "approved" | "rejected">("all")
  const [showAddRestaurant, setShowAddRestaurant] = useState(false)
  const [showAddMeal, setShowAddMeal] = useState(false)
  const [showEditMeal, setShowEditMeal] = useState(false)
  const [selectedRestaurant, setSelectedRestaurant] = useState<number | null>(null)
  const [editingMeal, setEditingMeal] = useState<Meal | null>(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<{ type: "restaurant" | "meal"; id: number } | null>(null)
  const [pendingRequests, setPendingRequests] = useState<PendingRestaurant[]>([])
  const [selectedPendingRequest, setSelectedPendingRequest] = useState<PendingRestaurant | null>(null)
  const [restaurants, setRestaurants] = useState<Restaurant[]>([])

  const [newRestaurant, setNewRestaurant] = useState({
    name: "",
    category: "",
    image: "",
    description: "",
    latitude: null as number | null,
    longitude: null as number | null,
    averageRating: null as number | null,
    totalRatings: 0,
  })
  const [newMeal, setNewMeal] = useState({ name: "", image: "", price: "", category: "" })

  useEffect(() => {
    loadRestaurantsFromStorage()
    loadPendingRequests()
  }, [])

  const loadRestaurantsFromStorage = () => {
    console.log("[v0] Loading restaurants from localStorage")
    const restaurantsData: Restaurant[] = []
    const keys = Object.keys(localStorage)

    // Load all restaurants with status from localStorage
    keys.forEach((key) => {
      if (key.startsWith("restaurant_")) {
        try {
          const data = JSON.parse(localStorage.getItem(key) || "{}")
          restaurantsData.push(data)
        } catch (e) {
          console.error("[v0] Error parsing restaurant data:", e)
        }
      }
    })

    // If no restaurants in storage, add default ones
    if (restaurantsData.length === 0) {
      const defaultRestaurants: Restaurant[] = [
        {
          id: 1,
          name: "Pizza Palace",
          category: "Italian",
          image: "/placeholder.svg?height=200&width=300",
          description: "Authentic Italian pizzas with fresh ingredients",
          latitude: 40.7589,
          longitude: -73.9851,
          averageRating: 4.5,
          totalRatings: 128,
          status: "approved",
          meals: [
            {
              id: 1,
              name: "Margherita Pizza",
              image: "/placeholder.svg?height=150&width=150",
              price: 12.99,
              category: "Pizza",
            },
            {
              id: 2,
              name: "Pepperoni Pizza",
              image: "/placeholder.svg?height=150&width=150",
              price: 14.99,
              category: "Pizza",
            },
          ],
        },
        {
          id: 2,
          name: "Burger House",
          category: "American",
          image: "/placeholder.svg?height=200&width=300",
          description: "Juicy burgers made with premium beef",
          latitude: 40.7489,
          longitude: -73.968,
          averageRating: 4.2,
          totalRatings: 95,
          status: "approved",
          meals: [
            {
              id: 3,
              name: "Classic Burger",
              image: "/placeholder.svg?height=150&width=150",
              price: 9.99,
              category: "Burgers",
            },
            {
              id: 4,
              name: "Cheese Burger",
              image: "/placeholder.svg?height=150&width=150",
              price: 10.99,
              category: "Burgers",
            },
          ],
        },
      ]

      defaultRestaurants.forEach((restaurant) => {
        localStorage.setItem(`restaurant_${restaurant.id}`, JSON.stringify(restaurant))
      })
      setRestaurants(defaultRestaurants)
    } else {
      setRestaurants(restaurantsData.sort((a, b) => b.id - a.id))
    }

    console.log("[v0] Loaded restaurants:", restaurantsData.length)
  }

  const loadPendingRequests = () => {
    const requests: PendingRestaurant[] = []
    const keys = Object.keys(localStorage)

    keys.forEach((key) => {
      if (key.startsWith("pendingRestaurant_")) {
        try {
          const data = JSON.parse(localStorage.getItem(key) || "{}")
          requests.push(data)
        } catch (e) {
          console.error("[v0] Error parsing pending request:", e)
        }
      }
    })

    setPendingRequests(requests.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()))
    console.log("[v0] Loaded pending requests:", requests.length)
  }

  const handleRefresh = () => {
    console.log("[v0] Refreshing restaurant data")
    loadRestaurantsFromStorage()
    loadPendingRequests()
  }

  const handleApproveRestaurant = (pendingId: number) => {
    const request = pendingRequests.find((r) => r.id === pendingId)
    if (!request) return

    console.log("[v0] Approving restaurant:", request.restaurantName)

    // Update the partner data in localStorage to set isPartnerApproved to true
    const partnerData = JSON.parse(localStorage.getItem("partnerData") || "{}")
    if (partnerData.email === request.email) {
      const restaurantId = Date.now()
      partnerData.isPartnerApproved = true
      partnerData.restaurantId = restaurantId
      partnerData.phone = request.phone
      partnerData.website = request.website
      partnerData.address = request.address
      partnerData.cuisineType = request.cuisineType
      localStorage.setItem("partnerData", JSON.stringify(partnerData))
      console.log("[v0] Updated partner data with approved status")
    }

    // Create a new restaurant entry with approved status
    const newRestaurantEntry: Restaurant = {
      id: Date.now(),
      name: request.restaurantName,
      category: request.cuisineType,
      image: `/placeholder.svg?height=200&width=300&query=${request.restaurantName}`,
      description: `${request.cuisineType} cuisine - Contact: ${request.phone}`,
      latitude: 40.7589,
      longitude: -73.9851,
      averageRating: null,
      totalRatings: 0,
      status: "approved",
      ownerName: request.ownerName,
      email: request.email,
      phone: request.phone,
      website: request.website,
      address: request.address,
      createdAt: new Date().toISOString(),
      meals: [],
    }

    // Save restaurant to localStorage with status
    localStorage.setItem(`restaurant_${newRestaurantEntry.id}`, JSON.stringify(newRestaurantEntry))
    console.log("[v0] Saved approved restaurant to localStorage:", newRestaurantEntry.id)

    // Update state
    const updatedRestaurants = [...restaurants, newRestaurantEntry]
    setRestaurants(updatedRestaurants)

    // Remove from pending requests
    localStorage.removeItem(`pendingRestaurant_${pendingId}`)
    setPendingRequests(pendingRequests.filter((r) => r.id !== pendingId))
    setSelectedPendingRequest(null)

    console.log("[v0] Restaurant approved successfully")
  }

  const handleRejectRestaurant = (pendingId: number) => {
    const request = pendingRequests.find((r) => r.id === pendingId)
    if (!request) return

    console.log("[v0] Rejecting restaurant:", request.restaurantName)

    // Create a rejected restaurant entry
    const rejectedRestaurant: Restaurant = {
      id: Date.now(),
      name: request.restaurantName,
      category: request.cuisineType,
      image: `/placeholder.svg?height=200&width=300&query=${request.restaurantName}`,
      description: `${request.cuisineType} cuisine - Contact: ${request.phone}`,
      latitude: 40.7589,
      longitude: -73.9851,
      averageRating: null,
      totalRatings: 0,
      status: "rejected",
      ownerName: request.ownerName,
      email: request.email,
      phone: request.phone,
      website: request.website,
      address: request.address,
      createdAt: new Date().toISOString(),
      meals: [],
    }

    // Save rejected restaurant to localStorage
    localStorage.setItem(`restaurant_${rejectedRestaurant.id}`, JSON.stringify(rejectedRestaurant))
    console.log("[v0] Saved rejected restaurant to localStorage:", rejectedRestaurant.id)

    // Update state
    const updatedRestaurants = [...restaurants, rejectedRestaurant]
    setRestaurants(updatedRestaurants)

    // Remove from pending requests
    localStorage.removeItem(`pendingRestaurant_${pendingId}`)
    setPendingRequests(pendingRequests.filter((r) => r.id !== pendingId))
    setSelectedPendingRequest(null)

    console.log("[v0] Restaurant rejected successfully")
  }

  const handleAddRestaurant = () => {
    if (
      newRestaurant.name &&
      newRestaurant.category &&
      newRestaurant.latitude !== null &&
      newRestaurant.longitude !== null
    ) {
      const restaurant: Restaurant = {
        id: Date.now(),
        name: newRestaurant.name,
        category: newRestaurant.category,
        description: newRestaurant.description,
        image: newRestaurant.image || `/placeholder.svg?height=200&width=300&query=${newRestaurant.name}`,
        latitude: newRestaurant.latitude,
        longitude: newRestaurant.longitude,
        averageRating: newRestaurant.averageRating,
        totalRatings: newRestaurant.totalRatings,
        status: "approved",
        meals: [],
      }

      // Save to localStorage
      localStorage.setItem(`restaurant_${restaurant.id}`, JSON.stringify(restaurant))

      setRestaurants([...restaurants, restaurant])
      setNewRestaurant({
        name: "",
        category: "",
        image: "",
        description: "",
        latitude: null,
        longitude: null,
        averageRating: null,
        totalRatings: 0,
      })
      setShowAddRestaurant(false)
    }
  }

  const handleDeleteRestaurant = (id: number) => {
    // Remove from localStorage
    localStorage.removeItem(`restaurant_${id}`)
    setRestaurants(restaurants.filter((r) => r.id !== id))
    setShowDeleteConfirm(null)
  }

  const handleAddMeal = () => {
    if (selectedRestaurant && newMeal.name && newMeal.price && newMeal.category) {
      const meal: Meal = {
        id: Date.now(),
        name: newMeal.name,
        image: newMeal.image || `/placeholder.svg?height=150&width=150&query=${newMeal.name}`,
        price: Number.parseFloat(newMeal.price),
        category: newMeal.category,
      }

      const updatedRestaurants = restaurants.map((r) => {
        if (r.id === selectedRestaurant) {
          const updated = { ...r, meals: [...r.meals, meal] }
          // Save to localStorage
          localStorage.setItem(`restaurant_${r.id}`, JSON.stringify(updated))
          return updated
        }
        return r
      })

      setRestaurants(updatedRestaurants)
      setNewMeal({ name: "", image: "", price: "", category: "" })
      setShowAddMeal(false)
      setSelectedRestaurant(null)
    }
  }

  const handleEditMeal = () => {
    if (editingMeal && selectedRestaurant) {
      const updatedRestaurants = restaurants.map((r) => {
        if (r.id === selectedRestaurant) {
          const updated = {
            ...r,
            meals: r.meals.map((m) => (m.id === editingMeal.id ? editingMeal : m)),
          }
          // Save to localStorage
          localStorage.setItem(`restaurant_${r.id}`, JSON.JSON.stringify(updated))
          return updated
        }
        return r
      })

      setRestaurants(updatedRestaurants)
      setEditingMeal(null)
      setShowEditMeal(false)
      setSelectedRestaurant(null)
    }
  }

  const handleDeleteMeal = (restaurantId: number, mealId: number) => {
    const updatedRestaurants = restaurants.map((r) => {
      if (r.id === restaurantId) {
        const updated = { ...r, meals: r.meals.filter((m) => m.id !== mealId) }
        // Save to localStorage
        localStorage.setItem(`restaurant_${r.id}`, JSON.stringify(updated))
        return updated
      }
      return r
    })

    setRestaurants(updatedRestaurants)
    setShowDeleteConfirm(null)
  }

  const filteredRestaurants =
    statusFilter === "all" ? restaurants : restaurants.filter((r) => r.status === statusFilter)

  const allMeals = restaurants.flatMap((r) =>
    r.meals.map((m) => ({ ...m, restaurantName: r.name, restaurantId: r.id })),
  )

  const statusCounts = {
    all: restaurants.length,
    pending: restaurants.filter((r) => r.status === "pending").length,
    approved: restaurants.filter((r) => r.status === "approved").length,
    rejected: restaurants.filter((r) => r.status === "rejected").length,
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/admin")} variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-[#FF6600]">Manage Restaurants & Meals</h1>
              <p className="text-gray-600 text-sm">Add, edit, or remove restaurants and meals</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-4 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab("restaurants")}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === "restaurants"
                ? "text-[#FF6600] border-b-2 border-[#FF6600]"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Restaurants
          </button>
          <button
            onClick={() => setActiveTab("meals")}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === "meals" ? "text-[#FF6600] border-b-2 border-[#FF6600]" : "text-gray-600 hover:text-gray-900"
            }`}
          >
            All Meals
          </button>
          <button
            onClick={() => setActiveTab("pending")}
            className={`pb-3 px-4 font-medium transition-colors relative ${
              activeTab === "pending"
                ? "text-[#FF6600] border-b-2 border-[#FF6600]"
                : "text-gray-600 hover:text-gray-900"
            }`}
          >
            Pending Approvals
            {pendingRequests.length > 0 && (
              <span className="absolute -top-1 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {pendingRequests.length}
              </span>
            )}
          </button>
        </div>

        {activeTab === "pending" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Pending Restaurant Approvals</h2>
              <Button onClick={handleRefresh} variant="outline" size="sm" className="gap-2 bg-transparent">
                <RefreshCw className="h-4 w-4" />
                Refresh
              </Button>
            </div>

            {pendingRequests.length === 0 ? (
              <div className="bg-white rounded-xl shadow-md p-12 text-center">
                <Store className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Pending Requests</h3>
                <p className="text-gray-600">All restaurant applications have been processed</p>
              </div>
            ) : (
              <div className="grid gap-6">
                {pendingRequests.map((request) => (
                  <div key={request.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-[#FF6600] to-[#FF8533] rounded-xl flex items-center justify-center flex-shrink-0">
                            <Store className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">{request.restaurantName}</h3>
                            <p className="text-sm text-gray-600 mt-1">
                              Submitted on{" "}
                              {new Date(request.createdAt).toLocaleDateString("en-US", {
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleApproveRestaurant(request.id)}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            onClick={() => handleRejectRestaurant(request.id)}
                            size="sm"
                            variant="outline"
                            className="text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
                          >
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-6 mt-6 pt-6 border-t border-gray-200">
                        <div className="space-y-4">
                          <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">
                            Owner Information
                          </h4>
                          <div className="space-y-3">
                            <div className="flex items-start gap-3">
                              <UserIcon className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-xs text-gray-500 uppercase">Full Name</p>
                                <p className="text-sm font-medium text-gray-900">{request.ownerName}</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-3">
                              <Mail className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-xs text-gray-500 uppercase">Email</p>
                                <p className="text-sm font-medium text-gray-900">{request.email}</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <h4 className="font-semibold text-gray-900 text-sm uppercase tracking-wide">
                            Restaurant Details
                          </h4>
                          <div className="space-y-3">
                            <div className="flex items-start gap-3">
                              <Phone className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-xs text-gray-500 uppercase">Phone Number</p>
                                <p className="text-sm font-medium text-gray-900">{request.phone}</p>
                              </div>
                            </div>
                            {request.website && (
                              <div className="flex items-start gap-3">
                                <Globe className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                                <div>
                                  <p className="text-xs text-gray-500 uppercase">Website</p>
                                  <a
                                    href={request.website}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-sm font-medium text-[#FF6600] hover:text-[#FF5500] underline"
                                  >
                                    {request.website}
                                  </a>
                                </div>
                              </div>
                            )}
                            <div className="flex items-start gap-3">
                              <MapPin className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-xs text-gray-500 uppercase">Address</p>
                                <p className="text-sm font-medium text-gray-900">{request.address}</p>
                              </div>
                            </div>
                            <div className="flex items-start gap-3">
                              <Utensils className="w-5 h-5 text-gray-400 mt-0.5 flex-shrink-0" />
                              <div>
                                <p className="text-xs text-gray-500 uppercase">Cuisine Type</p>
                                <span className="inline-block mt-1 px-3 py-1 bg-[#FF6600] bg-opacity-10 text-[#FF6600] rounded-full text-sm font-medium">
                                  {request.cuisineType}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Restaurants Tab */}
        {activeTab === "restaurants" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">All Restaurants</h2>
              <div className="flex gap-2">
                <Button onClick={handleRefresh} variant="outline" size="sm" className="gap-2 bg-transparent">
                  <RefreshCw className="h-4 w-4" />
                  Refresh
                </Button>
                <Button onClick={() => setShowAddRestaurant(true)} className="bg-[#FF6600] hover:bg-[#E55A00]">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Restaurant
                </Button>
              </div>
            </div>

            <div className="flex gap-2 mb-6">
              <Button
                onClick={() => setStatusFilter("all")}
                variant={statusFilter === "all" ? "default" : "outline"}
                size="sm"
                className={statusFilter === "all" ? "bg-[#FF6600] hover:bg-[#E55A00]" : ""}
              >
                All ({statusCounts.all})
              </Button>
              <Button
                onClick={() => setStatusFilter("pending")}
                variant={statusFilter === "pending" ? "default" : "outline"}
                size="sm"
                className={statusFilter === "pending" ? "bg-yellow-600 hover:bg-yellow-700" : ""}
              >
                Pending ({statusCounts.pending})
              </Button>
              <Button
                onClick={() => setStatusFilter("approved")}
                variant={statusFilter === "approved" ? "default" : "outline"}
                size="sm"
                className={statusFilter === "approved" ? "bg-green-600 hover:bg-green-700" : ""}
              >
                Approved ({statusCounts.approved})
              </Button>
              <Button
                onClick={() => setStatusFilter("rejected")}
                variant={statusFilter === "rejected" ? "default" : "outline"}
                size="sm"
                className={statusFilter === "rejected" ? "bg-red-600 hover:bg-red-700" : ""}
              >
                Rejected ({statusCounts.rejected})
              </Button>
            </div>

            {filteredRestaurants.length === 0 ? (
              <div className="bg-white rounded-xl shadow-md p-12 text-center">
                <Store className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No Restaurants Found</h3>
                <p className="text-gray-600">
                  {statusFilter === "all" ? "No restaurants available" : `No ${statusFilter} restaurants found`}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredRestaurants.map((restaurant) => (
                  <div key={restaurant.id} className="bg-white rounded-xl shadow-md overflow-hidden">
                    <img
                      src={restaurant.image || "/placeholder.svg"}
                      alt={restaurant.name}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-6">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-lg font-semibold text-gray-900">{restaurant.name}</h3>
                            <span
                              className={`text-xs px-2 py-1 rounded-full font-medium ${
                                restaurant.status === "approved"
                                  ? "bg-green-100 text-green-700"
                                  : restaurant.status === "pending"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-red-100 text-red-700"
                              }`}
                            >
                              {restaurant.status.charAt(0).toUpperCase() + restaurant.status.slice(1)}
                            </span>
                          </div>
                          <p className="text-sm text-gray-600">{restaurant.category}</p>
                          {restaurant.averageRating && (
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              <span className="text-sm font-semibold text-gray-700">
                                {restaurant.averageRating.toFixed(1)}
                              </span>
                              <span className="text-xs text-gray-500">({restaurant.totalRatings} ratings)</span>
                            </div>
                          )}
                        </div>
                        <Store className="h-6 w-6 text-[#FF6600]" />
                      </div>
                      <p className="text-sm text-gray-700 mb-4">{restaurant.description}</p>
                      <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                        <span className="text-sm text-gray-600">
                          {restaurant.meals.length} meal{restaurant.meals.length !== 1 ? "s" : ""}
                        </span>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => {
                              setSelectedRestaurant(restaurant.id)
                              setShowAddMeal(true)
                            }}
                            size="sm"
                            variant="outline"
                            className="text-[#FF6600] border-[#FF6600] hover:bg-[#FF6600] hover:text-white"
                          >
                            <Plus className="h-4 w-4 mr-1" />
                            Add Meal
                          </Button>
                          <Button
                            onClick={() => setShowDeleteConfirm({ type: "restaurant", id: restaurant.id })}
                            size="sm"
                            variant="outline"
                            className="text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Meals Tab */}
        {activeTab === "meals" && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">All Meals</h2>
            </div>

            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Meal</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Restaurant</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {allMeals.map((meal) => (
                      <tr key={`${meal.restaurantId}-${meal.id}`} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={meal.image || "/placeholder.svg"}
                              alt={meal.name}
                              className="w-12 h-12 rounded-lg object-cover"
                            />
                            <span className="font-medium text-gray-900">{meal.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-700">{meal.restaurantName}</td>
                        <td className="px-6 py-4 text-gray-700">{meal.category}</td>
                        <td className="px-6 py-4 font-semibold text-[#FF6600]">${meal.price.toFixed(2)}</td>
                        <td className="px-6 py-4">
                          <div className="flex gap-2">
                            <Button
                              onClick={() => {
                                setEditingMeal(meal)
                                setSelectedRestaurant(meal.restaurantId)
                                setShowEditMeal(true)
                              }}
                              size="sm"
                              variant="outline"
                              className="text-[#FF6600] border-[#FF6600] hover:bg-[#FF6600] hover:text-white"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              onClick={() => setShowDeleteConfirm({ type: "meal", id: meal.id })}
                              size="sm"
                              variant="outline"
                              className="text-red-600 border-red-600 hover:bg-red-600 hover:text-white"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Add Restaurant Modal */}
      {showAddRestaurant && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Add New Restaurant</h2>
                <Button onClick={() => setShowAddRestaurant(false)} variant="ghost" size="icon">
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="restaurant-name">Restaurant Name</Label>
                  <Input
                    id="restaurant-name"
                    value={newRestaurant.name}
                    onChange={(e) => setNewRestaurant({ ...newRestaurant, name: e.target.value })}
                    placeholder="Enter restaurant name"
                  />
                </div>

                <div>
                  <Label htmlFor="restaurant-category">Category</Label>
                  <Input
                    id="restaurant-category"
                    value={newRestaurant.category}
                    onChange={(e) => setNewRestaurant({ ...newRestaurant, category: e.target.value })}
                    placeholder="e.g., Italian, Chinese, Fast Food"
                  />
                </div>

                <div>
                  <Label htmlFor="restaurant-description">Description</Label>
                  <Textarea
                    id="restaurant-description"
                    value={newRestaurant.description}
                    onChange={(e) => setNewRestaurant({ ...newRestaurant, description: e.target.value })}
                    placeholder="Enter restaurant description"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="restaurant-image">Image URL (optional)</Label>
                  <Input
                    id="restaurant-image"
                    value={newRestaurant.image}
                    onChange={(e) => setNewRestaurant({ ...newRestaurant, image: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div>
                  <Label>Location</Label>
                  <div className="mt-2 border rounded-lg overflow-hidden h-64">
                    <MapPicker
                      onLocationSelect={(lat, lng) => {
                        setNewRestaurant({ ...newRestaurant, latitude: lat, longitude: lng })
                      }}
                      initialLat={newRestaurant.latitude}
                      initialLng={newRestaurant.longitude}
                    />
                  </div>
                  {newRestaurant.latitude && newRestaurant.longitude && (
                    <p className="text-sm text-gray-600 mt-2">
                      Selected: {newRestaurant.latitude.toFixed(4)}, {newRestaurant.longitude.toFixed(4)}
                    </p>
                  )}
                </div>

                <div className="flex gap-3 pt-4">
                  <Button onClick={() => setShowAddRestaurant(false)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                  <Button
                    onClick={handleAddRestaurant}
                    className="flex-1 bg-[#FF6600] hover:bg-[#E55A00]"
                    disabled={
                      !newRestaurant.name ||
                      !newRestaurant.category ||
                      newRestaurant.latitude === null ||
                      newRestaurant.longitude === null
                    }
                  >
                    Add Restaurant
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Meal Modal */}
      {showAddMeal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Add New Meal</h2>
                <Button onClick={() => setShowAddMeal(false)} variant="ghost" size="icon">
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="meal-name">Meal Name</Label>
                  <Input
                    id="meal-name"
                    value={newMeal.name}
                    onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
                    placeholder="Enter meal name"
                  />
                </div>

                <div>
                  <Label htmlFor="meal-category">Category</Label>
                  <Input
                    id="meal-category"
                    value={newMeal.category}
                    onChange={(e) => setNewMeal({ ...newMeal, category: e.target.value })}
                    placeholder="e.g., Pizza, Burger, Pasta"
                  />
                </div>

                <div>
                  <Label htmlFor="meal-price">Price ($)</Label>
                  <Input
                    id="meal-price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={newMeal.price}
                    onChange={(e) => setNewMeal({ ...newMeal, price: e.target.value })}
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <Label htmlFor="meal-image">Image URL (optional)</Label>
                  <Input
                    id="meal-image"
                    value={newMeal.image}
                    onChange={(e) => setNewMeal({ ...newMeal, image: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button onClick={() => setShowAddMeal(false)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                  <Button
                    onClick={handleAddMeal}
                    className="flex-1 bg-[#FF6600] hover:bg-[#E55A00]"
                    disabled={!newMeal.name || !newMeal.price || !newMeal.category}
                  >
                    Add Meal
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Meal Modal */}
      {showEditMeal && editingMeal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Edit Meal</h2>
                <Button onClick={() => setShowEditMeal(false)} variant="ghost" size="icon">
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-meal-name">Meal Name</Label>
                  <Input
                    id="edit-meal-name"
                    value={editingMeal.name}
                    onChange={(e) => setEditingMeal({ ...editingMeal, name: e.target.value })}
                    placeholder="Enter meal name"
                  />
                </div>

                <div>
                  <Label htmlFor="edit-meal-category">Category</Label>
                  <Input
                    id="edit-meal-category"
                    value={editingMeal.category}
                    onChange={(e) => setEditingMeal({ ...editingMeal, category: e.target.value })}
                    placeholder="e.g., Pizza, Burger, Pasta"
                  />
                </div>

                <div>
                  <Label htmlFor="edit-meal-price">Price ($)</Label>
                  <Input
                    id="edit-meal-price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={editingMeal.price}
                    onChange={(e) => setEditingMeal({ ...editingMeal, price: Number.parseFloat(e.target.value) })}
                    placeholder="0.00"
                  />
                </div>

                <div>
                  <Label htmlFor="edit-meal-image">Image URL (optional)</Label>
                  <Input
                    id="edit-meal-image"
                    value={editingMeal.image}
                    onChange={(e) => setEditingMeal({ ...editingMeal, image: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button onClick={() => setShowEditMeal(false)} variant="outline" className="flex-1">
                    Cancel
                  </Button>
                  <Button
                    onClick={handleEditMeal}
                    className="flex-1 bg-[#FF6600] hover:bg-[#E55A00]"
                    disabled={!editingMeal.name || !editingMeal.price || !editingMeal.category}
                  >
                    Save Changes
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Confirm Deletion</h2>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this {showDeleteConfirm.type}? This action cannot be undone.
            </p>
            <div className="flex gap-3">
              <Button onClick={() => setShowDeleteConfirm(null)} variant="outline" className="flex-1">
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (showDeleteConfirm.type === "restaurant") {
                    handleDeleteRestaurant(showDeleteConfirm.id)
                  } else {
                    const meal = allMeals.find((m) => m.id === showDeleteConfirm.id)
                    if (meal) {
                      handleDeleteMeal(meal.restaurantId, meal.id)
                    }
                  }
                }}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white"
              >
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
