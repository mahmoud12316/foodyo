"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Bell, Send, Users, Bike, ArrowLeft, CheckCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function AdminNotificationsPage() {
  const router = useRouter()
  const [recipientType, setRecipientType] = useState<"all_customers" | "all_drivers">("all_customers")
  const [title, setTitle] = useState("")
  const [message, setMessage] = useState("")
  const [isSending, setIsSending] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  const handleBroadcast = async () => {
    if (!title || !message) {
      alert("Please fill in all fields")
      return
    }

    setIsSending(true)

    try {
      const response = await fetch("/api/notifications/broadcast", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientType,
          title,
          message,
          senderId: "admin-123", // In production, use actual admin ID
        }),
      })

      if (response.ok) {
        setShowSuccess(true)
        setTitle("")
        setMessage("")

        setTimeout(() => {
          setShowSuccess(false)
        }, 3000)
      } else {
        alert("Failed to send broadcast notification")
      }
    } catch (error) {
      console.error("Error sending broadcast:", error)
      alert("An error occurred while sending the broadcast")
    } finally {
      setIsSending(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Header */}
        <div className="mb-6">
          <Button
            onClick={() => router.push("/admin")}
            variant="ghost"
            className="mb-4 text-orange-600 hover:text-orange-700 hover:bg-orange-50"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>

          <div className="bg-white rounded-xl shadow-lg p-6 border-2 border-orange-100">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-orange-600 to-orange-500 rounded-xl flex items-center justify-center shadow-lg">
                <Bell className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Broadcast Notifications</h1>
                <p className="text-gray-600">Send announcements to all customers or drivers</p>
              </div>
            </div>
          </div>
        </div>

        {/* Success Message */}
        {showSuccess && (
          <div className="mb-6 bg-green-50 border-2 border-green-200 rounded-xl p-4 flex items-center gap-3 animate-in fade-in slide-in-from-top-4">
            <CheckCircle className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900">Broadcast sent successfully!</p>
              <p className="text-sm text-green-700">All {recipientType.replace("all_", "")} have been notified.</p>
            </div>
          </div>
        )}

        {/* Broadcast Form */}
        <Card className="border-2 border-orange-100 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-orange-50 to-transparent">
            <CardTitle className="text-xl text-gray-900">Create Broadcast Message</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            {/* Recipient Type */}
            <div className="space-y-2">
              <Label htmlFor="recipientType" className="text-base font-semibold text-gray-900">
                Send To
              </Label>
              <Select value={recipientType} onValueChange={(value: any) => setRecipientType(value)}>
                <SelectTrigger className="h-12 border-2 border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all_customers">
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-blue-600" />
                      <span>All Customers</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="all_drivers">
                    <div className="flex items-center gap-2">
                      <Bike className="w-4 h-4 text-green-600" />
                      <span>All Drivers</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Title */}
            <div className="space-y-2">
              <Label htmlFor="title" className="text-base font-semibold text-gray-900">
                Notification Title
              </Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Special Offer, System Update"
                className="h-12 border-2 border-gray-200"
                maxLength={100}
              />
              <p className="text-sm text-gray-500">{title.length}/100 characters</p>
            </div>

            {/* Message */}
            <div className="space-y-2">
              <Label htmlFor="message" className="text-base font-semibold text-gray-900">
                Message
              </Label>
              <Textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your message here..."
                className="min-h-[150px] border-2 border-gray-200"
                maxLength={500}
              />
              <p className="text-sm text-gray-500">{message.length}/500 characters</p>
            </div>

            {/* Preview */}
            {(title || message) && (
              <div className="space-y-2">
                <Label className="text-base font-semibold text-gray-900">Preview</Label>
                <div className="bg-gray-50 border-2 border-gray-200 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Bell className="w-5 h-5 text-orange-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-gray-900">{title || "Notification Title"}</p>
                      <p className="text-sm text-gray-700 mt-1">{message || "Your message will appear here..."}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Send Button */}
            <Button
              onClick={handleBroadcast}
              disabled={!title || !message || isSending}
              className="w-full h-12 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-700 hover:to-orange-600 text-white font-semibold text-base"
            >
              {isSending ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5 mr-2" />
                  Send Broadcast to {recipientType === "all_customers" ? "All Customers" : "All Drivers"}
                </>
              )}
            </Button>

            {/* Info Box */}
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
              <p className="text-sm text-blue-900">
                <strong>Note:</strong> This will send a push notification to all active{" "}
                {recipientType === "all_customers" ? "customers" : "drivers"}. Make sure your message is clear and
                relevant.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Setup Instructions */}
        <Card className="mt-6 border-2 border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="text-lg text-yellow-900">Push Notification Setup Required</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-yellow-800 space-y-2">
            <p className="font-semibold">To enable real push notifications, you need to:</p>
            <ol className="list-decimal list-inside space-y-1 ml-2">
              <li>Set up Firebase Cloud Messaging (FCM) in your Firebase Console</li>
              <li>Add the Firebase configuration to your environment variables</li>
              <li>Implement FCM token registration in mobile apps</li>
              <li>Configure service workers for web push notifications</li>
            </ol>
            <p className="mt-3 text-yellow-700">
              Currently, notifications are stored in the database and displayed in-app. Push notifications require
              additional setup.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
