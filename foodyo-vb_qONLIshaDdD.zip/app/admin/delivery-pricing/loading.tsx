export default function Loading() {
  return (
    <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center">
      <p className="text-gray-600">Loading delivery pricing...</p>
    </div>
  )
}
