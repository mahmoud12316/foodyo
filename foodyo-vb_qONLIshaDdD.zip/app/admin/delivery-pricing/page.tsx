"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { ArrowLeft, Plus, Pencil, Trash2, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { toast } from "sonner"

interface PricingTier {
  id: number
  distance_max: number
  delivery_fee: number
}

export default function DeliveryPricingPage() {
  const router = useRouter()
  const { isAdmin, isAuthenticated } = useAuth()
  const [tiers, setTiers] = useState<PricingTier[]>([])
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [selectedTier, setSelectedTier] = useState<PricingTier | null>(null)
  const [distanceMax, setDistanceMax] = useState("")
  const [deliveryFee, setDeliveryFee] = useState("")

  useEffect(() => {
    if (!isAuthenticated || !isAdmin) {
      router.push("/login")
      return
    }
    fetchTiers()
  }, [isAuthenticated, isAdmin, router])

  const fetchTiers = async () => {
    try {
      const response = await fetch("/api/delivery-pricing")
      const data = await response.json()
      setTiers(data.tiers || [])
    } catch (error) {
      console.error("Error fetching tiers:", error)
      toast.error("Failed to load pricing tiers")
    }
  }

  const handleAddTier = async () => {
    if (!distanceMax || !deliveryFee) {
      toast.error("Please fill in all fields")
      return
    }

    try {
      const response = await fetch("/api/delivery-pricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          distance_max: Number.parseFloat(distanceMax),
          delivery_fee: Number.parseFloat(deliveryFee),
        }),
      })

      if (!response.ok) throw new Error("Failed to add tier")

      toast.success("Pricing tier added successfully")
      setShowAddDialog(false)
      setDistanceMax("")
      setDeliveryFee("")
      fetchTiers()
    } catch (error) {
      toast.error("Failed to add pricing tier")
    }
  }

  const handleEditTier = async () => {
    if (!selectedTier || !distanceMax || !deliveryFee) {
      toast.error("Please fill in all fields")
      return
    }

    try {
      const response = await fetch("/api/delivery-pricing", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: selectedTier.id,
          distance_max: Number.parseFloat(distanceMax),
          delivery_fee: Number.parseFloat(deliveryFee),
        }),
      })

      if (!response.ok) throw new Error("Failed to update tier")

      toast.success("Pricing tier updated successfully")
      setShowEditDialog(false)
      setSelectedTier(null)
      setDistanceMax("")
      setDeliveryFee("")
      fetchTiers()
    } catch (error) {
      toast.error("Failed to update pricing tier")
    }
  }

  const handleDeleteTier = async () => {
    if (!selectedTier) return

    try {
      const response = await fetch(`/api/delivery-pricing?id=${selectedTier.id}`, {
        method: "DELETE",
      })

      if (!response.ok) throw new Error("Failed to delete tier")

      toast.success("Pricing tier deleted successfully")
      setShowDeleteDialog(false)
      setSelectedTier(null)
      fetchTiers()
    } catch (error) {
      toast.error("Failed to delete pricing tier")
    }
  }

  const openEditDialog = (tier: PricingTier) => {
    setSelectedTier(tier)
    setDistanceMax(tier.distance_max.toString())
    setDeliveryFee(tier.delivery_fee.toString())
    setShowEditDialog(true)
  }

  const openDeleteDialog = (tier: PricingTier) => {
    setSelectedTier(tier)
    setShowDeleteDialog(true)
  }

  if (!isAuthenticated || !isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5] p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Button variant="ghost" onClick={() => router.push("/admin")} className="mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Delivery Pricing</h1>
            <p className="text-gray-600 mt-1">Manage distance-based delivery fee tiers</p>
          </div>
          <Button onClick={() => setShowAddDialog(true)} className="bg-[#FF6600] hover:bg-[#FF5500]">
            <Plus className="w-4 h-4 mr-2" />
            Add Tier
          </Button>
        </div>

        <Card className="p-6">
          <div className="space-y-4">
            {tiers.length === 0 ? (
              <div className="text-center py-12">
                <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No pricing tiers configured yet</p>
                <Button onClick={() => setShowAddDialog(true)} variant="outline" className="mt-4 bg-transparent">
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Tier
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {tiers.map((tier, index) => (
                  <div
                    key={tier.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-orange-100 flex items-center justify-center text-orange-600 font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">
                          {index === 0
                            ? `Up to ${tier.distance_max} km`
                            : index === tiers.length - 1
                              ? `Over ${tiers[index - 1].distance_max} km`
                              : `${tiers[index - 1].distance_max} - ${tier.distance_max} km`}
                        </p>
                        <p className="text-sm text-gray-600">Delivery Fee: ${tier.delivery_fee.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" onClick={() => openEditDialog(tier)}>
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openDeleteDialog(tier)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h3 className="font-semibold text-blue-900 mb-2">How it works:</h3>
          <ul className="text-sm text-blue-800 space-y-1 list-disc list-inside">
            <li>Distance is calculated from restaurant to delivery address</li>
            <li>The system applies the fee for the first matching distance tier</li>
            <li>Configure tiers in ascending order (shortest to longest distance)</li>
            <li>Customers see the calculated fee at checkout</li>
          </ul>
        </div>
      </div>

      {/* Add Tier Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Pricing Tier</DialogTitle>
            <DialogDescription>Create a new distance-based delivery fee tier</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="add-distance">Maximum Distance (km)</Label>
              <Input
                id="add-distance"
                type="number"
                step="0.1"
                placeholder="e.g., 5.0"
                value={distanceMax}
                onChange={(e) => setDistanceMax(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="add-fee">Delivery Fee ($)</Label>
              <Input
                id="add-fee"
                type="number"
                step="0.01"
                placeholder="e.g., 8.00"
                value={deliveryFee}
                onChange={(e) => setDeliveryFee(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)} className="bg-transparent">
              Cancel
            </Button>
            <Button onClick={handleAddTier} className="bg-[#FF6600] hover:bg-[#FF5500]">
              Add Tier
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Tier Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Pricing Tier</DialogTitle>
            <DialogDescription>Update the distance and fee for this tier</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="edit-distance">Maximum Distance (km)</Label>
              <Input
                id="edit-distance"
                type="number"
                step="0.1"
                value={distanceMax}
                onChange={(e) => setDistanceMax(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label htmlFor="edit-fee">Delivery Fee ($)</Label>
              <Input
                id="edit-fee"
                type="number"
                step="0.01"
                value={deliveryFee}
                onChange={(e) => setDeliveryFee(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)} className="bg-transparent">
              Cancel
            </Button>
            <Button onClick={handleEditTier} className="bg-[#FF6600] hover:bg-[#FF5500]">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Pricing Tier</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this pricing tier? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)} className="bg-transparent">
              Cancel
            </Button>
            <Button onClick={handleDeleteTier} className="bg-red-600 hover:bg-red-700">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
