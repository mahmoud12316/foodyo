"use client"

import { useRouter } from "next/navigation"
import { ArrowLeft, TrendingUp, DollarSign, Users, Package } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Bar,
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Pie,
  PieChart,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

export default function ReportsAnalytics() {
  const router = useRouter()

  const metrics = [
    { title: "Total Sales This Week", value: "$12,450", change: "+18.2%", icon: DollarSign, color: "text-green-600" },
    { title: "Total Sales This Month", value: "$45,678", change: "+12.5%", icon: TrendingUp, color: "text-blue-600" },
    { title: "Active Users", value: "1,234", change: "+8.3%", icon: Users, color: "text-purple-600" },
    { title: "Delivery Performance", value: "94.5%", change: "+2.1%", icon: Package, color: "text-orange-600" },
  ]

  const mostOrderedMeals = [
    { name: "Margherita Pizza", orders: 245 },
    { name: "Chicken Burger", orders: 198 },
    { name: "Caesar Salad", orders: 167 },
    { name: "Pasta Carbonara", orders: 156 },
    { name: "Beef Tacos", orders: 134 },
    { name: "Sushi Roll", orders: 112 },
  ]

  const salesData = [
    { day: "Mon", sales: 4200 },
    { day: "Tue", sales: 5100 },
    { day: "Wed", sales: 4800 },
    { day: "Thu", sales: 6200 },
    { day: "Fri", sales: 7800 },
    { day: "Sat", sales: 9500 },
    { day: "Sun", sales: 8400 },
  ]

  const deliveryData = [
    { name: "On Time", value: 945, color: "#10B981" },
    { name: "Delayed", value: 45, color: "#F59E0B" },
    { name: "Cancelled", value: 10, color: "#EF4444" },
  ]

  const activeUsersData = [
    { month: "Jan", users: 850 },
    { month: "Feb", users: 920 },
    { month: "Mar", users: 1050 },
    { month: "Apr", users: 1150 },
    { month: "May", users: 1234 },
  ]

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/admin")} variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-[#FF6600]">Reports & Analytics</h1>
              <p className="text-gray-600 text-sm">View detailed reports and analytics</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {metrics.map((metric, index) => {
            const Icon = metric.icon
            return (
              <div key={index} className="bg-white rounded-xl p-6 shadow-md">
                <div className="flex items-center justify-between mb-4">
                  <Icon className={`h-8 w-8 ${metric.color}`} />
                  <span className="text-green-600 text-sm font-medium">{metric.change}</span>
                </div>
                <p className="text-gray-600 text-sm mb-1">{metric.title}</p>
                <p className="text-2xl font-bold text-gray-900">{metric.value}</p>
              </div>
            )
          })}
        </div>

        <div className="bg-white rounded-xl p-6 shadow-md mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Sales This Week</h2>
          <ChartContainer
            config={{
              sales: {
                label: "Sales",
                color: "#FF6600",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={salesData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="sales" stroke="#FF6600" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-xl p-6 shadow-md">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Most Ordered Meals</h2>
            <ChartContainer
              config={{
                orders: {
                  label: "Orders",
                  color: "#FF6600",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={mostOrderedMeals}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="orders" fill="#FF6600" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>

          <div className="bg-white rounded-xl p-6 shadow-md">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Delivery Performance</h2>
            <ChartContainer
              config={{
                onTime: {
                  label: "On Time",
                  color: "#10B981",
                },
                delayed: {
                  label: "Delayed",
                  color: "#F59E0B",
                },
                cancelled: {
                  label: "Cancelled",
                  color: "#EF4444",
                },
              }}
              className="h-[300px]"
            >
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={deliveryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {deliveryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <ChartTooltip content={<ChartTooltipContent />} />
                </PieChart>
              </ResponsiveContainer>
            </ChartContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-md">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Active Users Trend</h2>
          <ChartContainer
            config={{
              users: {
                label: "Active Users",
                color: "#8B5CF6",
              },
            }}
            className="h-[300px]"
          >
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activeUsersData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Bar dataKey="users" fill="#8B5CF6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </div>
      </main>
    </div>
  )
}
