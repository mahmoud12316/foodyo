"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import {
  Home,
  Menu,
  X,
  LogOut,
  ClipboardList,
  UserCog,
  UtensilsCrossed,
  BarChart3,
  Settings,
  Bike,
  Search,
  Phone,
  Mail,
  Car,
  CheckCircle,
  XCircle,
  Star,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface Driver {
  id: number
  name: string
  phone: string
  email: string
  vehicleType: string
  licensePlate: string
  isAvailable: boolean
  createdAt: string
  averageRating: number | null
  totalRatings: number
}

export default function ManageDrivers() {
  const router = useRouter()
  const { logout, isAdmin, isAuthenticated } = useAuth()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [drivers, setDrivers] = useState<Driver[]>([
    {
      id: 1,
      name: "Ahmed Hassan",
      phone: "+962 79 123 4567",
      email: "ahmed.hassan@example.com",
      vehicleType: "Bike / Motorcycle",
      licensePlate: "ABC-123",
      isAvailable: true,
      createdAt: "2025-01-15",
      averageRating: 4.8,
      totalRatings: 156,
    },
    {
      id: 2,
      name: "Sara Mohammed",
      phone: "+962 78 234 5678",
      email: "sara.mohammed@example.com",
      vehicleType: "Car",
      licensePlate: "XYZ-789",
      isAvailable: false,
      createdAt: "2025-01-14",
      averageRating: 4.5,
      totalRatings: 89,
    },
    {
      id: 3,
      name: "Omar Ali",
      phone: "+962 77 345 6789",
      email: "omar.ali@example.com",
      vehicleType: "Scooter",
      licensePlate: "LMN-456",
      isAvailable: true,
      createdAt: "2025-01-13",
      averageRating: 4.2,
      totalRatings: 62,
    },
  ])

  useEffect(() => {
    if (!isAuthenticated || !isAdmin) {
      router.push("/login")
    }
  }, [isAuthenticated, isAdmin, router])

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  const toggleAvailability = (driverId: number) => {
    setDrivers((prev) =>
      prev.map((driver) => (driver.id === driverId ? { ...driver, isAvailable: !driver.isAvailable } : driver)),
    )
  }

  const filteredDrivers = drivers.filter(
    (driver) =>
      driver.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      driver.phone.includes(searchQuery),
  )

  if (!isAuthenticated || !isAdmin) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    )
  }

  const menuItems = [
    { name: "Dashboard", icon: Home, route: "/admin", active: false },
    { name: "Orders", icon: ClipboardList, route: "/admin/orders", active: false },
    { name: "Users", icon: UserCog, route: "/admin/users", active: false },
    { name: "Restaurants / Meals", icon: UtensilsCrossed, route: "/admin/restaurants", active: false },
    { name: "Reports", icon: BarChart3, route: "/admin/reports", active: false },
    { name: "Manage Drivers", icon: Bike, route: "/admin/drivers", active: true },
    { name: "Settings", icon: Settings, route: "/admin/settings", active: false },
  ]

  return (
    <div className="min-h-screen bg-[#FFF9F5] flex">
      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="h-full flex flex-col">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-[#FF6600]">Foodyo</h2>
              <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-gray-600">
                <X className="h-6 w-6" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">Admin Panel</p>
          </div>

          <nav className="flex-1 p-4 space-y-2">
            {menuItems.map((item, index) => {
              const Icon = item.icon
              return (
                <button
                  key={index}
                  onClick={() => {
                    router.push(item.route)
                    setSidebarOpen(false)
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 shadow-sm ${
                    item.active
                      ? "bg-[#FF6600] text-white shadow-md"
                      : "text-gray-700 hover:bg-orange-50 hover:text-[#FF6600] hover:shadow-md"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="font-medium text-sm">{item.name}</span>
                </button>
              )
            })}
          </nav>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-30">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-gray-600">
                  <Menu className="h-6 w-6" />
                </button>
                <div>
                  <h1 className="text-2xl font-bold text-[#FF6600]">Manage Drivers</h1>
                  <p className="text-gray-600 text-sm mt-0.5">View and manage delivery driver accounts</p>
                </div>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="flex items-center gap-2 border-[#FF6600] text-[#FF6600] hover:bg-[#FF6600] hover:text-white bg-transparent rounded-xl shadow-sm hover:shadow-md transition-all duration-200"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-8">
          {/* Search and Stats */}
          <div className="mb-8 space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <div className="relative w-full sm:w-96">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search drivers by name, email, or phone..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                />
              </div>
              <div className="flex gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-900">{drivers.length}</p>
                  <p className="text-sm text-gray-600">Total Drivers</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-green-600">{drivers.filter((d) => d.isAvailable).length}</p>
                  <p className="text-sm text-gray-600">Available</p>
                </div>
              </div>
            </div>
          </div>

          {/* Drivers List */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredDrivers.map((driver) => (
              <Card key={driver.id} className="shadow-lg hover:shadow-xl transition-shadow duration-200">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center shadow-md">
                        <Bike className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{driver.name}</CardTitle>
                        {driver.averageRating && (
                          <div className="flex items-center gap-1 mt-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm font-semibold text-gray-700">
                              {driver.averageRating.toFixed(1)}
                            </span>
                            <span className="text-xs text-gray-500">({driver.totalRatings} ratings)</span>
                          </div>
                        )}
                        <CardDescription className="flex items-center gap-2 mt-1">
                          <Badge
                            variant={driver.isAvailable ? "default" : "secondary"}
                            className={driver.isAvailable ? "bg-green-500" : "bg-gray-400"}
                          >
                            {driver.isAvailable ? (
                              <>
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Available
                              </>
                            ) : (
                              <>
                                <XCircle className="h-3 w-3 mr-1" />
                                Unavailable
                              </>
                            )}
                          </Badge>
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 text-sm">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-700">{driver.phone}</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-700">{driver.email}</span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <Car className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-700">
                        {driver.vehicleType} - {driver.licensePlate}
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-700">Availability Status</p>
                        <p className="text-xs text-gray-500">Toggle to activate/deactivate driver</p>
                      </div>
                      <Switch
                        checked={driver.isAvailable}
                        onCheckedChange={() => toggleAvailability(driver.id)}
                        className="data-[state=checked]:bg-green-500"
                      />
                    </div>
                  </div>

                  <div className="text-xs text-gray-500 pt-2">
                    Registered: {new Date(driver.createdAt).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredDrivers.length === 0 && (
            <div className="text-center py-12">
              <Bike className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-700 mb-2">No drivers found</h3>
              <p className="text-gray-500">
                {searchQuery ? "Try adjusting your search query" : "No drivers have registered yet"}
              </p>
            </div>
          )}
        </main>

        <footer className="bg-white border-t border-gray-200 mt-auto">
          <div className="px-4 sm:px-6 lg:px-8 py-6">
            <p className="text-center text-gray-600 text-sm">Foodyo Admin Panel © 2025 – All Rights Reserved.</p>
          </div>
        </footer>
      </div>
    </div>
  )
}
