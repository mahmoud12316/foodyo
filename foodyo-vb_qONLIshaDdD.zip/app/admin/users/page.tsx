"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, User, Mail, Calendar, ShoppingBag, Ban, CheckCircle, Search, Phone, Eye } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface UserData {
  id: number
  name: string
  email: string
  phone?: string
  registration_date: string
  total_orders: number
  is_active: boolean
}

export default function ManageUsers() {
  const router = useRouter()

  const [users, setUsers] = useState<UserData[]>([])
  const [filteredUsers, setFilteredUsers] = useState<UserData[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "inactive">("all")
  const [loading, setLoading] = useState(true)

  const [showToggleDialog, setShowToggleDialog] = useState(false)
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)
  const [selectedUser, setSelectedUser] = useState<UserData | null>(null)

  useEffect(() => {
    fetchUsers()
  }, [])

  useEffect(() => {
    let result = users

    // Apply search filter
    if (searchQuery) {
      result = result.filter(
        (user) =>
          user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.phone?.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Apply status filter
    if (statusFilter !== "all") {
      result = result.filter((user) => (statusFilter === "active" ? user.is_active : !user.is_active))
    }

    setFilteredUsers(result)
  }, [searchQuery, statusFilter, users])

  const fetchUsers = async () => {
    try {
      setLoading(true)
      // Mock data for now - replace with actual API call
      const mockUsers: UserData[] = [
        {
          id: 1,
          name: "John Doe",
          email: "john@example.com",
          phone: "+962-777-123456",
          registration_date: "2024-01-15",
          total_orders: 45,
          is_active: true,
        },
        {
          id: 2,
          name: "Sarah Smith",
          email: "sarah@example.com",
          phone: "+962-777-234567",
          registration_date: "2024-02-20",
          total_orders: 32,
          is_active: true,
        },
        {
          id: 3,
          name: "Mike Johnson",
          email: "mike@example.com",
          phone: "+962-777-345678",
          registration_date: "2024-03-10",
          total_orders: 28,
          is_active: true,
        },
        {
          id: 4,
          name: "Emma Wilson",
          email: "emma@example.com",
          phone: "+962-777-456789",
          registration_date: "2024-01-05",
          total_orders: 51,
          is_active: true,
        },
        {
          id: 5,
          name: "David Brown",
          email: "david@example.com",
          phone: "+962-777-567890",
          registration_date: "2024-04-12",
          total_orders: 19,
          is_active: false,
        },
      ]
      setUsers(mockUsers)
      setFilteredUsers(mockUsers)
    } catch (error) {
      console.error("Error fetching users:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleToggleStatus = (user: UserData) => {
    setSelectedUser(user)
    setShowToggleDialog(true)
  }

  const confirmToggleStatus = async () => {
    if (!selectedUser) return

    try {
      // TODO: Replace with actual API call
      // await fetch(`/api/admin/users/${selectedUser.id}/toggle-status`, { method: 'POST' })

      setUsers(users.map((u) => (u.id === selectedUser.id ? { ...u, is_active: !u.is_active } : u)))
    } catch (error) {
      console.error("Error toggling user status:", error)
    } finally {
      setShowToggleDialog(false)
      setSelectedUser(null)
    }
  }

  const handleViewDetails = (user: UserData) => {
    setSelectedUser(user)
    setShowDetailsDialog(true)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center">
        <p className="text-gray-600">Loading customers...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <header className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <Button onClick={() => router.push("/admin")} variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-[#FF6600]">Manage Customers</h1>
              <p className="text-gray-600 text-sm">View and manage customer accounts</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-md p-6 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by name, email, or phone..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => setStatusFilter("all")}
                variant={statusFilter === "all" ? "default" : "outline"}
                className={statusFilter === "all" ? "bg-[#FF6600] hover:bg-[#FF6600]/90" : ""}
              >
                All ({users.length})
              </Button>
              <Button
                onClick={() => setStatusFilter("active")}
                variant={statusFilter === "active" ? "default" : "outline"}
                className={statusFilter === "active" ? "bg-green-600 hover:bg-green-700" : ""}
              >
                Active ({users.filter((u) => u.is_active).length})
              </Button>
              <Button
                onClick={() => setStatusFilter("inactive")}
                variant={statusFilter === "inactive" ? "default" : "outline"}
                className={statusFilter === "inactive" ? "bg-red-600 hover:bg-red-700" : ""}
              >
                Inactive ({users.filter((u) => !u.is_active).length})
              </Button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Name</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Email</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Phone</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Registration Date</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Orders</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Status</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-6 py-12 text-center text-gray-500">
                      No customers found matching your search criteria
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((user) => (
                    <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="bg-orange-100 p-2 rounded-full">
                            <User className="h-4 w-4 text-[#FF6600]" />
                          </div>
                          <span className="font-medium text-gray-900">{user.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-gray-600">
                          <Mail className="h-4 w-4" />
                          <span className="text-sm">{user.email}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-gray-600">
                          <Phone className="h-4 w-4" />
                          <span className="text-sm">{user.phone || "N/A"}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2 text-gray-600">
                          <Calendar className="h-4 w-4" />
                          <span className="text-sm">{user.registration_date}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <ShoppingBag className="h-4 w-4 text-[#FF6600]" />
                          <span className="font-semibold text-[#FF6600]">{user.total_orders}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span
                          className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
                            user.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                          }`}
                        >
                          {user.is_active ? (
                            <>
                              <CheckCircle className="h-3 w-3" />
                              Active
                            </>
                          ) : (
                            <>
                              <Ban className="h-3 w-3" />
                              Inactive
                            </>
                          )}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Button
                            onClick={() => handleViewDetails(user)}
                            variant="outline"
                            size="sm"
                            className="text-blue-600 border-blue-300 hover:bg-blue-50"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            Details
                          </Button>
                          <Button
                            onClick={() => handleToggleStatus(user)}
                            variant="outline"
                            size="sm"
                            className={
                              user.is_active
                                ? "text-red-600 border-red-300 hover:bg-red-50"
                                : "text-green-600 border-green-300 hover:bg-green-50"
                            }
                          >
                            {user.is_active ? (
                              <>
                                <Ban className="h-4 w-4 mr-1" />
                                Deactivate
                              </>
                            ) : (
                              <>
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Activate
                              </>
                            )}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {showToggleDialog && selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6 shadow-xl">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              {selectedUser.is_active ? "Deactivate Customer Account" : "Activate Customer Account"}
            </h3>
            <p className="text-gray-600 mb-6">
              {selectedUser.is_active
                ? `Are you sure you want to deactivate ${selectedUser.name}'s account? They will not be able to place orders or access their account until reactivated.`
                : `Are you sure you want to activate ${selectedUser.name}'s account? They will regain full access to place orders.`}
            </p>
            <div className="flex gap-3 justify-end">
              <Button
                onClick={() => {
                  setShowToggleDialog(false)
                  setSelectedUser(null)
                }}
                variant="outline"
              >
                Cancel
              </Button>
              <Button
                onClick={confirmToggleStatus}
                className={selectedUser.is_active ? "bg-red-600 hover:bg-red-700" : "bg-green-600 hover:bg-green-700"}
              >
                {selectedUser.is_active ? "Deactivate Account" : "Activate Account"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {showDetailsDialog && selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full p-6 shadow-xl">
            <h3 className="text-xl font-bold text-gray-900 mb-6">Customer Details</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-gray-500">Name</label>
                  <p className="text-gray-900 font-medium">{selectedUser.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Email</label>
                  <p className="text-gray-900">{selectedUser.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Phone</label>
                  <p className="text-gray-900">{selectedUser.phone || "Not provided"}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Registration Date</label>
                  <p className="text-gray-900">{selectedUser.registration_date}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Total Orders</label>
                  <p className="text-gray-900 font-semibold text-[#FF6600]">{selectedUser.total_orders}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-500">Account Status</label>
                  <p className={`font-semibold ${selectedUser.is_active ? "text-green-600" : "text-red-600"}`}>
                    {selectedUser.is_active ? "Active" : "Inactive"}
                  </p>
                </div>
              </div>
            </div>
            <div className="flex gap-3 justify-end mt-6">
              <Button
                onClick={() => {
                  setShowDetailsDialog(false)
                  setSelectedUser(null)
                }}
                variant="outline"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
