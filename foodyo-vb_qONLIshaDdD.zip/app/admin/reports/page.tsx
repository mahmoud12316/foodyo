"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { ArrowLeft, Download, FileSpreadsheet, FileText, Search, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useToast } from "@/hooks/use-toast"

interface ReportData {
  orderId: string
  customerName: string
  customerEmail: string
  restaurantName: string
  totalAmount: number
  orderDate: string
  deliveryAddress: string
  status: string
}

export default function ReportsPage() {
  const router = useRouter()
  const { isAdmin, isAuthenticated } = useAuth()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [restaurantFilter, setRestaurantFilter] = useState("all")
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")
  const [sortColumn, setSortColumn] = useState<keyof ReportData>("orderDate")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  useEffect(() => {
    if (!isAuthenticated || !isAdmin) {
      router.push("/login")
    }
  }, [isAuthenticated, isAdmin, router])

  // Sample data - in a real app, this would come from an API
  const allReportsData: ReportData[] = [
    {
      orderId: "ORD-001",
      customerName: "John Doe",
      customerEmail: "john@example.com",
      restaurantName: "Pizza Palace",
      totalAmount: 45.99,
      orderDate: "2025-01-15 14:30",
      deliveryAddress: "123 Main St, New York, NY 10001",
      status: "Delivered",
    },
    {
      orderId: "ORD-002",
      customerName: "Jane Smith",
      customerEmail: "jane@example.com",
      restaurantName: "Burger House",
      totalAmount: 32.5,
      orderDate: "2025-01-15 15:45",
      deliveryAddress: "456 Oak Ave, Brooklyn, NY 11201",
      status: "On the way",
    },
    {
      orderId: "ORD-003",
      customerName: "Mike Johnson",
      customerEmail: "mike@example.com",
      restaurantName: "Sushi Bar",
      totalAmount: 78.25,
      orderDate: "2025-01-14 18:20",
      deliveryAddress: "789 Pine Rd, Queens, NY 11354",
      status: "Preparing",
    },
    {
      orderId: "ORD-004",
      customerName: "Sarah Williams",
      customerEmail: "sarah@example.com",
      restaurantName: "Taco Fiesta",
      totalAmount: 28.75,
      orderDate: "2025-01-14 12:15",
      deliveryAddress: "321 Elm St, Manhattan, NY 10002",
      status: "Delivered",
    },
    {
      orderId: "ORD-005",
      customerName: "David Brown",
      customerEmail: "david@example.com",
      restaurantName: "Pizza Palace",
      totalAmount: 52.0,
      orderDate: "2025-01-13 19:30",
      deliveryAddress: "654 Maple Dr, Bronx, NY 10451",
      status: "Cancelled",
    },
  ]

  // Filter and sort data
  const filteredData = allReportsData
    .filter((item) => {
      const matchesSearch =
        item.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.orderId.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.customerEmail.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesStatus = statusFilter === "all" || item.status === statusFilter
      const matchesRestaurant = restaurantFilter === "all" || item.restaurantName === restaurantFilter

      let matchesDateRange = true
      if (startDate && endDate) {
        const orderDate = new Date(item.orderDate)
        const start = new Date(startDate)
        const end = new Date(endDate)
        matchesDateRange = orderDate >= start && orderDate <= end
      }

      return matchesSearch && matchesStatus && matchesRestaurant && matchesDateRange
    })
    .sort((a, b) => {
      const aValue = a[sortColumn]
      const bValue = b[sortColumn]

      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
      }

      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue
      }

      return 0
    })

  const handleSort = (column: keyof ReportData) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortColumn(column)
      setSortDirection("asc")
    }
  }

  const downloadExcel = () => {
    try {
      const headers = [
        "Order ID",
        "Customer Name",
        "Customer Email",
        "Restaurant",
        "Total Amount",
        "Order Date",
        "Delivery Address",
        "Status",
      ]
      const csvContent = [
        headers.join(","),
        ...filteredData.map((row) =>
          [
            row.orderId,
            `"${row.customerName}"`,
            row.customerEmail,
            `"${row.restaurantName}"`,
            row.totalAmount,
            row.orderDate,
            `"${row.deliveryAddress}"`,
            row.status,
          ].join(","),
        ),
      ].join("\n")

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
      const link = document.createElement("a")
      const url = URL.createObjectURL(blob)
      link.setAttribute("href", url)
      link.setAttribute("download", `foodyo-report-${new Date().toISOString().split("T")[0]}.csv`)
      link.style.visibility = "hidden"
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)

      toast({
        title: "Report Downloaded",
        description: "Excel report has been downloaded successfully.",
      })
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to download the report. Please try again.",
        variant: "destructive",
      })
    }
  }

  const downloadPDF = () => {
    try {
      const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Foodyo Orders Report</title>
          <style>
            @media print {
              @page { margin: 0.5in; }
              body { margin: 0; }
            }
            body { 
              font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
              padding: 40px;
              background: white;
            }
            .header { 
              text-align: center; 
              margin-bottom: 40px;
              border-bottom: 3px solid #FF6600;
              padding-bottom: 20px;
            }
            .logo { 
              color: #FF6600; 
              font-size: 48px; 
              font-weight: bold;
              margin-bottom: 10px;
              letter-spacing: 2px;
            }
            .report-title {
              font-size: 24px;
              color: #333;
              margin: 10px 0;
            }
            .report-meta {
              color: #666;
              font-size: 14px;
            }
            .summary {
              background: #FFF9F5;
              padding: 20px;
              border-radius: 8px;
              margin-bottom: 30px;
              border-left: 4px solid #FF6600;
            }
            .summary-title {
              font-size: 18px;
              font-weight: bold;
              color: #333;
              margin-bottom: 10px;
            }
            .summary-stats {
              display: flex;
              gap: 30px;
              flex-wrap: wrap;
            }
            .stat-item {
              flex: 1;
              min-width: 150px;
            }
            .stat-label {
              color: #666;
              font-size: 12px;
              text-transform: uppercase;
              letter-spacing: 1px;
            }
            .stat-value {
              color: #FF6600;
              font-size: 24px;
              font-weight: bold;
              margin-top: 5px;
            }
            table { 
              width: 100%; 
              border-collapse: collapse; 
              margin-top: 20px;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            th, td { 
              border: 1px solid #e0e0e0; 
              padding: 12px 8px; 
              text-align: left; 
              font-size: 11px;
            }
            th { 
              background-color: #FF6600; 
              color: white;
              font-weight: 600;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }
            tr:nth-child(even) { 
              background-color: #FFF9F5; 
            }
            tr:hover {
              background-color: #FFE5CC;
            }
            .status-badge {
              display: inline-block;
              padding: 4px 8px;
              border-radius: 12px;
              font-size: 10px;
              font-weight: 600;
              text-transform: uppercase;
            }
            .status-delivered { background: #D4EDDA; color: #155724; }
            .status-ontheway { background: #D1ECF1; color: #0C5460; }
            .status-preparing { background: #FFF3CD; color: #856404; }
            .status-cancelled { background: #F8D7DA; color: #721C24; }
            .status-pending { background: #E2E3E5; color: #383D41; }
            .amount {
              color: #FF6600;
              font-weight: bold;
            }
            .footer {
              margin-top: 40px;
              text-align: center;
              color: #999;
              font-size: 11px;
              border-top: 1px solid #e0e0e0;
              padding-top: 20px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="logo">FOODYO</div>
            <div class="report-title">Orders Report</div>
            <div class="report-meta">
              Generated on ${new Date().toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })} at ${new Date().toLocaleTimeString()}
            </div>
          </div>

          <div class="summary">
            <div class="summary-title">Report Summary</div>
            <div class="summary-stats">
              <div class="stat-item">
                <div class="stat-label">Total Orders</div>
                <div class="stat-value">${filteredData.length}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">Total Revenue</div>
                <div class="stat-value">$${filteredData.reduce((sum, item) => sum + item.totalAmount, 0).toFixed(2)}</div>
              </div>
              <div class="stat-item">
                <div class="stat-label">Average Order</div>
                <div class="stat-value">$${(filteredData.reduce((sum, item) => sum + item.totalAmount, 0) / filteredData.length || 0).toFixed(2)}</div>
              </div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Restaurant</th>
                <th>Amount</th>
                <th>Date</th>
                <th>Delivery Address</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              ${filteredData
                .map((row) => {
                  const statusClass = row.status.toLowerCase().replace(/\s+/g, "")
                  return `
                      <tr>
                        <td><strong>${row.orderId}</strong></td>
                        <td>${row.customerName}</td>
                        <td>${row.customerEmail}</td>
                        <td>${row.restaurantName}</td>
                        <td class="amount">$${row.totalAmount.toFixed(2)}</td>
                        <td>${row.orderDate}</td>
                        <td>${row.deliveryAddress}</td>
                        <td><span class="status-badge status-${statusClass}">${row.status}</span></td>
                      </tr>
                    `
                })
                .join("")}
            </tbody>
          </table>

          <div class="footer">
            <p><strong>Foodyo</strong> - Food Delivery Management System</p>
            <p>This is a confidential document. Please handle with care.</p>
          </div>

          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() {
                window.close();
              }, 100);
            }
          </script>
        </body>
        </html>
      `

      const printWindow = window.open("", "_blank")
      if (printWindow) {
        printWindow.document.write(htmlContent)
        printWindow.document.close()

        toast({
          title: "PDF Ready",
          description: "Print dialog opened. Save as PDF to download the report.",
        })
      } else {
        throw new Error("Popup blocked")
      }
    } catch (error) {
      toast({
        title: "Download Failed",
        description: "Failed to generate PDF. Please check your popup blocker settings.",
        variant: "destructive",
      })
    }
  }

  const clearFilters = () => {
    setSearchQuery("")
    setStatusFilter("all")
    setRestaurantFilter("all")
    setStartDate("")
    setEndDate("")
  }

  if (!isAuthenticated || !isAdmin) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    )
  }

  const uniqueRestaurants = Array.from(new Set(allReportsData.map((item) => item.restaurantName)))

  return (
    <div className="min-h-screen bg-[#FFF9F5] p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            onClick={() => router.push("/admin")}
            variant="ghost"
            className="mb-4 text-gray-600 hover:text-[#FF6600]"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-600 mt-1">View, filter, and export order reports</p>
        </div>

        {/* Filters Section */}
        <div className="bg-white rounded-2xl shadow-md p-6 mb-6">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="h-5 w-5 text-[#FF6600]" />
            <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Search */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Order ID, Customer..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Status Filter */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Status</label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Preparing">Preparing</SelectItem>
                  <SelectItem value="On the way">On the way</SelectItem>
                  <SelectItem value="Delivered">Delivered</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Restaurant Filter */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Restaurant</label>
              <Select value={restaurantFilter} onValueChange={setRestaurantFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Restaurants" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Restaurants</SelectItem>
                  {uniqueRestaurants.map((restaurant) => (
                    <SelectItem key={restaurant} value={restaurant}>
                      {restaurant}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Date Range */}
            <div>
              <label className="text-sm font-medium text-gray-700 mb-2 block">Date Range</label>
              <div className="flex gap-2">
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="text-sm"
                />
                <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="text-sm" />
              </div>
            </div>
          </div>

          <div className="flex gap-2 mt-4">
            <Button
              onClick={clearFilters}
              variant="outline"
              className="text-gray-600 hover:text-[#FF6600] hover:border-[#FF6600] bg-transparent"
            >
              Clear Filters
            </Button>
          </div>
        </div>

        {/* Actions Bar */}
        <div className="bg-white rounded-2xl shadow-md p-4 mb-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <p className="text-sm text-gray-600">
                Showing <span className="font-semibold text-gray-900">{filteredData.length}</span> of{" "}
                <span className="font-semibold text-gray-900">{allReportsData.length}</span> orders
              </p>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="bg-[#FF6600] hover:bg-[#FF8533] text-white rounded-xl shadow-md">
                  <Download className="h-4 w-4 mr-2" />
                  Download Report
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={downloadExcel} className="cursor-pointer">
                  <FileSpreadsheet className="h-4 w-4 mr-2 text-green-600" />
                  Export as Excel
                </DropdownMenuItem>
                <DropdownMenuItem onClick={downloadPDF} className="cursor-pointer">
                  <FileText className="h-4 w-4 mr-2 text-red-600" />
                  Export as PDF
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-2xl shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="cursor-pointer hover:bg-gray-100" onClick={() => handleSort("orderId")}>
                    Order ID {sortColumn === "orderId" && (sortDirection === "asc" ? "↑" : "↓")}
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-gray-100" onClick={() => handleSort("customerName")}>
                    Customer {sortColumn === "customerName" && (sortDirection === "asc" ? "↑" : "↓")}
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-gray-100" onClick={() => handleSort("restaurantName")}>
                    Restaurant {sortColumn === "restaurantName" && (sortDirection === "asc" ? "↑" : "↓")}
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-gray-100" onClick={() => handleSort("totalAmount")}>
                    Amount {sortColumn === "totalAmount" && (sortDirection === "asc" ? "↑" : "↓")}
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-gray-100" onClick={() => handleSort("orderDate")}>
                    Date {sortColumn === "orderDate" && (sortDirection === "asc" ? "↑" : "↓")}
                  </TableHead>
                  <TableHead>Delivery Address</TableHead>
                  <TableHead className="cursor-pointer hover:bg-gray-100" onClick={() => handleSort("status")}>
                    Status {sortColumn === "status" && (sortDirection === "asc" ? "↑" : "↓")}
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredData.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      No orders found matching your filters.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredData.map((row) => (
                    <TableRow key={row.orderId} className="hover:bg-gray-50">
                      <TableCell className="font-medium">{row.orderId}</TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{row.customerName}</p>
                          <p className="text-xs text-gray-500">{row.customerEmail}</p>
                        </div>
                      </TableCell>
                      <TableCell>{row.restaurantName}</TableCell>
                      <TableCell className="font-semibold text-[#FF6600]">${row.totalAmount.toFixed(2)}</TableCell>
                      <TableCell className="text-sm text-gray-600">{row.orderDate}</TableCell>
                      <TableCell className="text-sm text-gray-600 max-w-xs truncate">{row.deliveryAddress}</TableCell>
                      <TableCell>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            row.status === "Delivered"
                              ? "bg-green-100 text-green-800"
                              : row.status === "On the way"
                                ? "bg-blue-100 text-blue-800"
                                : row.status === "Preparing"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : row.status === "Cancelled"
                                    ? "bg-red-100 text-red-800"
                                    : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {row.status}
                        </span>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </div>
  )
}
