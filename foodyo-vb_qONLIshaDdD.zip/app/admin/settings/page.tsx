"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { Camera, Save, ArrowLeft, Eye, EyeOff, Upload, X, Shield, Send } from "lucide-react"
import { toast } from "sonner"

export default function AdminSettings() {
  const { user, updateUser, isAdmin } = useAuth()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"account" | "app" | "notifications" | "security" | "support">("account")
  const [formData, setFormData] = useState({
    name: user?.name || "Admin",
    email: user?.email || "admin@foodyo.com",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [profileImage, setProfileImage] = useState(user?.avatar || "/placeholder.svg?height=120&width=120")

  const [appSettings, setAppSettings] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("appSettings")
      return saved
        ? JSON.parse(saved)
        : {
            appName: "Foodyo",
            appLogo: "/placeholder.svg?height=80&width=80",
            mainColor: "#FF6600",
            defaultCurrency: "USD",
            defaultDeliveryFee: "5.00",
          }
    }
    return {
      appName: "Foodyo",
      appLogo: "/placeholder.svg?height=80&width=80",
      mainColor: "#FF6600",
      defaultCurrency: "USD",
      defaultDeliveryFee: "5.00",
    }
  })

  const [notificationSettings, setNotificationSettings] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("notificationSettings")
      return saved
        ? JSON.parse(saved)
        : {
            enablePushNotifications: true,
            newOrderAlert: true,
            orderConfirmationTemplate:
              "Your order #{{ORDER_ID}} has been confirmed! Estimated delivery: {{DELIVERY_TIME}}",
            orderDeliveredTemplate: "Your order #{{ORDER_ID}} has been delivered. Enjoy your meal!",
            newOrderAdminTemplate:
              "New order received! Order #{{ORDER_ID}} from {{CUSTOMER_NAME}}. Total: {{TOTAL_AMOUNT}}",
          }
    }
    return {
      enablePushNotifications: true,
      newOrderAlert: true,
      orderConfirmationTemplate: "Your order #{{ORDER_ID}} has been confirmed! Estimated delivery: {{DELIVERY_TIME}}",
      orderDeliveredTemplate: "Your order #{{ORDER_ID}} has been delivered. Enjoy your meal!",
      newOrderAdminTemplate: "New order received! Order #{{ORDER_ID}} from {{CUSTOMER_NAME}}. Total: {{TOTAL_AMOUNT}}",
    }
  })

  const [securitySettings, setSecuritySettings] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("securitySettings")
      return saved
        ? JSON.parse(saved)
        : {
            twoFactorAuth: false,
            sessionTimeout: "30",
          }
    }
    return {
      twoFactorAuth: false,
      sessionTimeout: "30",
    }
  })

  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [passwordModalData, setPasswordModalData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })
  const [showModalCurrentPassword, setShowModalCurrentPassword] = useState(false)
  const [showModalNewPassword, setShowModalNewPassword] = useState(false)
  const [showModalConfirmPassword, setShowModalConfirmPassword] = useState(false)

  const [supportContact, setSupportContact] = useState({
    email: "",
    message: "",
  })

  if (!isAdmin) {
    router.push("/login")
    return null
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleAppSettingsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setAppSettings({
      ...appSettings,
      [e.target.name]: e.target.value,
    })
  }

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setProfileImage(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = () => {
        setAppSettings({
          ...appSettings,
          appLogo: reader.result as string,
        })
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSaveChanges = () => {
    if (formData.newPassword || formData.confirmPassword) {
      if (!formData.currentPassword) {
        toast.error("Please enter your current password")
        return
      }
      if (formData.newPassword !== formData.confirmPassword) {
        toast.error("New passwords do not match")
        return
      }
      if (formData.newPassword.length < 6) {
        toast.error("New password must be at least 6 characters")
        return
      }
    }

    const updatedUser = {
      ...user!,
      name: formData.name,
      email: formData.email,
      avatar: profileImage,
    }

    updateUser(updatedUser)
    toast.success("Settings saved successfully!")

    setFormData({
      ...formData,
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })
  }

  const handleSaveAppSettings = () => {
    if (!appSettings.appName.trim()) {
      toast.error("App name is required")
      return
    }
    if (!appSettings.defaultDeliveryFee || Number.parseFloat(appSettings.defaultDeliveryFee) < 0) {
      toast.error("Please enter a valid delivery fee")
      return
    }

    localStorage.setItem("appSettings", JSON.stringify(appSettings))
    toast.success("App settings saved successfully!")
  }

  const handleNotificationToggle = (field: string) => {
    setNotificationSettings({
      ...notificationSettings,
      [field]: !notificationSettings[field],
    })
  }

  const handleNotificationTemplateChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNotificationSettings({
      ...notificationSettings,
      [e.target.name]: e.target.value,
    })
  }

  const handleSaveNotificationSettings = () => {
    if (!notificationSettings.orderConfirmationTemplate.trim()) {
      toast.error("Order confirmation template is required")
      return
    }
    if (!notificationSettings.orderDeliveredTemplate.trim()) {
      toast.error("Order delivered template is required")
      return
    }
    if (!notificationSettings.newOrderAdminTemplate.trim()) {
      toast.error("New order admin template is required")
      return
    }

    localStorage.setItem("notificationSettings", JSON.stringify(notificationSettings))
    toast.success("Notification settings saved successfully!")
  }

  const handleSecurityToggle = (field: string) => {
    setSecuritySettings({
      ...securitySettings,
      [field]: !securitySettings[field],
    })
  }

  const handleSessionTimeoutChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSecuritySettings({
      ...securitySettings,
      sessionTimeout: e.target.value,
    })
  }

  const handleSaveSecuritySettings = () => {
    localStorage.setItem("securitySettings", JSON.stringify(securitySettings))
    toast.success("Security settings saved successfully!")
  }

  const handlePasswordChange = () => {
    if (!passwordModalData.currentPassword) {
      toast.error("Please enter your current password")
      return
    }
    if (passwordModalData.newPassword !== passwordModalData.confirmPassword) {
      toast.error("New passwords do not match")
      return
    }
    if (passwordModalData.newPassword.length < 6) {
      toast.error("New password must be at least 6 characters")
      return
    }

    // In a real app, you would verify the current password and update it here
    toast.success("Password changed successfully!")
    setShowPasswordModal(false)
    setPasswordModalData({
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    })
  }

  const handleSupportContactChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setSupportContact({
      ...supportContact,
      [e.target.name]: e.target.value,
    })
  }

  const handleSendMessage = () => {
    if (!supportContact.email.trim()) {
      toast.error("Please enter your email address")
      return
    }
    if (!supportContact.message.trim()) {
      toast.error("Please enter a message")
      return
    }

    // In a real app, you would send this to a support system or email service
    toast.success("Message sent successfully! We'll get back to you soon.")
    setSupportContact({
      email: "",
      message: "",
    })
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <button
              onClick={() => router.push("/admin")}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-[#FF6600]">Settings</h1>
              <p className="text-sm text-gray-600">Manage your admin profile and app preferences</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-t-2xl shadow-lg">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab("account")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-all ${
                activeTab === "account"
                  ? "text-[#FF6600] border-b-2 border-[#FF6600]"
                  : "text-gray-600 hover:text-gray-800"
              }`}
            >
              Account Settings
            </button>
            <button
              onClick={() => setActiveTab("app")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-all ${
                activeTab === "app" ? "text-[#FF6600] border-b-2 border-[#FF6600]" : "text-gray-600 hover:text-gray-800"
              }`}
            >
              General App Settings
            </button>
            <button
              onClick={() => setActiveTab("notifications")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-all ${
                activeTab === "notifications"
                  ? "text-[#FF6600] border-b-2 border-[#FF6600]"
                  : "text-gray-600 hover:text-gray-800"
              }`}
            >
              Notification Settings
            </button>
            <button
              onClick={() => setActiveTab("security")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-all ${
                activeTab === "security"
                  ? "text-[#FF6600] border-b-2 border-[#FF6600]"
                  : "text-gray-600 hover:text-gray-800"
              }`}
            >
              Security Settings
            </button>
            <button
              onClick={() => setActiveTab("support")}
              className={`flex-1 px-6 py-4 text-sm font-semibold transition-all ${
                activeTab === "support"
                  ? "text-[#FF6600] border-b-2 border-[#FF6600]"
                  : "text-gray-600 hover:text-gray-800"
              }`}
            >
              Support & Contact
            </button>
          </div>
        </div>

        <div className="bg-white rounded-b-2xl shadow-lg p-8">
          {activeTab === "account" && (
            <div>
              {/* Profile Picture Section */}
              <div className="flex flex-col items-center mb-8 pb-8 border-b border-gray-200">
                <div className="relative">
                  <img
                    src={profileImage || "/placeholder.svg"}
                    alt="Profile"
                    className="w-32 h-32 rounded-full object-cover border-4 border-[#FF6600]"
                  />
                  <label
                    htmlFor="profile-upload"
                    className="absolute bottom-0 right-0 bg-[#FF6600] text-white p-2 rounded-full cursor-pointer hover:bg-[#E55A00] transition-all shadow-lg"
                  >
                    <Camera className="w-5 h-5" />
                    <input
                      id="profile-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                </div>
                <p className="text-sm text-gray-500 mt-3">Click the camera icon to upload a new profile picture</p>
              </div>

              {/* Form Fields */}
              <div className="space-y-6">
                {/* Name Field */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                    placeholder="Enter your name"
                  />
                </div>

                {/* Email Field */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                    placeholder="Enter your email"
                  />
                </div>

                {/* Password Change Section */}
                <div className="pt-6 border-t border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Change Password</h3>
                  <p className="text-sm text-gray-500 mb-4">Leave blank if you don't want to change your password</p>

                  {/* Current Password */}
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                    <div className="relative">
                      <input
                        type={showCurrentPassword ? "text" : "password"}
                        name="currentPassword"
                        value={formData.currentPassword}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all pr-12"
                        placeholder="Enter current password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  {/* New Password */}
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                    <div className="relative">
                      <input
                        type={showNewPassword ? "text" : "password"}
                        name="newPassword"
                        value={formData.newPassword}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all pr-12"
                        placeholder="Enter new password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Confirm New Password</label>
                    <div className="relative">
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleInputChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all pr-12"
                        placeholder="Confirm new password"
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                      >
                        {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Save Button */}
                <div className="pt-6">
                  <button
                    onClick={handleSaveChanges}
                    className="w-full bg-[#FF6600] text-white py-3 px-6 rounded-xl font-semibold hover:bg-[#E55A00] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "app" && (
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-6">General App Settings</h2>
              <p className="text-sm text-gray-600 mb-8">Configure your app's global settings and preferences</p>

              <div className="space-y-6">
                {/* App Name */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">App Name</label>
                  <input
                    type="text"
                    name="appName"
                    value={appSettings.appName}
                    onChange={handleAppSettingsChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                    placeholder="Enter app name"
                  />
                </div>

                {/* App Logo */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">App Logo</label>
                  <div className="flex items-center gap-4">
                    <img
                      src={appSettings.appLogo || "/placeholder.svg"}
                      alt="App Logo"
                      className="w-20 h-20 rounded-lg object-cover border-2 border-gray-300"
                    />
                    <label className="flex-1">
                      <div className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-[#FF6600] hover:bg-orange-50 transition-all">
                        <Upload className="w-5 h-5 text-gray-600" />
                        <span className="text-sm text-gray-600">Upload Logo</span>
                      </div>
                      <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                    </label>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">Recommended size: 200x200px</p>
                </div>

                {/* Main Color Theme */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Main Color Theme</label>
                  <div className="flex items-center gap-4">
                    <input
                      type="color"
                      name="mainColor"
                      value={appSettings.mainColor}
                      onChange={handleAppSettingsChange}
                      className="w-16 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
                    />
                    <input
                      type="text"
                      name="mainColor"
                      value={appSettings.mainColor}
                      onChange={handleAppSettingsChange}
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                      placeholder="#FF6600"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">This color will be used throughout the app</p>
                </div>

                {/* Default Currency */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Default Currency</label>
                  <select
                    name="defaultCurrency"
                    value={appSettings.defaultCurrency}
                    onChange={handleAppSettingsChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                  >
                    <option value="USD">USD - US Dollar</option>
                    <option value="EUR">EUR - Euro</option>
                    <option value="GBP">GBP - British Pound</option>
                    <option value="SAR">SAR - Saudi Riyal</option>
                    <option value="AED">AED - UAE Dirham</option>
                    <option value="KWD">KWD - Kuwaiti Dinar</option>
                  </select>
                </div>

                {/* Default Delivery Fee */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Default Delivery Fee</label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-600 font-medium">
                      {appSettings.defaultCurrency === "USD" && "$"}
                      {appSettings.defaultCurrency === "EUR" && "€"}
                      {appSettings.defaultCurrency === "GBP" && "£"}
                      {appSettings.defaultCurrency === "SAR" && "SAR"}
                      {appSettings.defaultCurrency === "AED" && "AED"}
                      {appSettings.defaultCurrency === "KWD" && "KWD"}
                    </span>
                    <input
                      type="number"
                      name="defaultDeliveryFee"
                      value={appSettings.defaultDeliveryFee}
                      onChange={handleAppSettingsChange}
                      step="0.01"
                      min="0"
                      className="w-full pl-16 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                      placeholder="5.00"
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">Standard delivery fee for all orders</p>
                </div>

                {/* Save Button */}
                <div className="pt-6">
                  <button
                    onClick={handleSaveAppSettings}
                    className="w-full bg-[#FF6600] text-white py-3 px-6 rounded-xl font-semibold hover:bg-[#E55A00] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "notifications" && (
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Notification Settings</h2>
              <p className="text-sm text-gray-600 mb-8">Configure push notifications and message templates</p>

              <div className="space-y-6">
                {/* Enable Push Notifications Toggle */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800">Enable Push Notifications</h3>
                    <p className="text-xs text-gray-600 mt-1">Allow the app to send push notifications to users</p>
                  </div>
                  <button
                    onClick={() => handleNotificationToggle("enablePushNotifications")}
                    className={`relative w-14 h-7 rounded-full transition-colors ${
                      notificationSettings.enablePushNotifications ? "bg-[#FF6600]" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        notificationSettings.enablePushNotifications ? "translate-x-7" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                {/* New Order Alert Toggle */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800">New Order Alert</h3>
                    <p className="text-xs text-gray-600 mt-1">Notify admin when a new order is placed</p>
                  </div>
                  <button
                    onClick={() => handleNotificationToggle("newOrderAlert")}
                    className={`relative w-14 h-7 rounded-full transition-colors ${
                      notificationSettings.newOrderAlert ? "bg-[#FF6600]" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        notificationSettings.newOrderAlert ? "translate-x-7" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                {/* Message Templates Section */}
                <div className="pt-6 border-t border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Default Message Templates</h3>
                  <p className="text-sm text-gray-600 mb-6">
                    Customize notification messages. Use placeholders like {"{"}
                    {"{"}ORDER_ID{"}"}, {"{"}CUSTOMER_NAME{"}"}, {"{"}TOTAL_AMOUNT{"}"}, {"{"}DELIVERY_TIME{"}"}
                  </p>

                  {/* Order Confirmation Template */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Order Confirmation Message (Customer)
                    </label>
                    <textarea
                      name="orderConfirmationTemplate"
                      value={notificationSettings.orderConfirmationTemplate}
                      onChange={handleNotificationTemplateChange}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all resize-none"
                      placeholder="Enter order confirmation message template"
                    />
                    <p className="text-xs text-gray-500 mt-2">Sent to customers when their order is confirmed</p>
                  </div>

                  {/* Order Delivered Template */}
                  <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Order Delivered Message (Customer)
                    </label>
                    <textarea
                      name="orderDeliveredTemplate"
                      value={notificationSettings.orderDeliveredTemplate}
                      onChange={handleNotificationTemplateChange}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all resize-none"
                      placeholder="Enter order delivered message template"
                    />
                    <p className="text-xs text-gray-500 mt-2">Sent to customers when their order is delivered</p>
                  </div>

                  {/* New Order Admin Template */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">New Order Alert (Admin)</label>
                    <textarea
                      name="newOrderAdminTemplate"
                      value={notificationSettings.newOrderAdminTemplate}
                      onChange={handleNotificationTemplateChange}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all resize-none"
                      placeholder="Enter new order admin alert template"
                    />
                    <p className="text-xs text-gray-500 mt-2">Sent to admin when a new order is placed</p>
                  </div>
                </div>

                {/* Save Button */}
                <div className="pt-6">
                  <button
                    onClick={handleSaveNotificationSettings}
                    className="w-full bg-[#FF6600] text-white py-3 px-6 rounded-xl font-semibold hover:bg-[#E55A00] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "security" && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <Shield className="w-6 h-6 text-[#FF6600]" />
                <h2 className="text-xl font-semibold text-gray-800">Security Settings</h2>
              </div>
              <p className="text-sm text-gray-600 mb-8">Manage your account security and authentication preferences</p>

              <div className="space-y-6">
                {/* Two-Factor Authentication Toggle */}
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-800">Two-Factor Authentication</h3>
                    <p className="text-xs text-gray-600 mt-1">Add an extra layer of security to your admin account</p>
                  </div>
                  <button
                    onClick={() => handleSecurityToggle("twoFactorAuth")}
                    className={`relative w-14 h-7 rounded-full transition-colors ${
                      securitySettings.twoFactorAuth ? "bg-[#FF6600]" : "bg-gray-300"
                    }`}
                  >
                    <span
                      className={`absolute top-1 left-1 w-5 h-5 bg-white rounded-full transition-transform ${
                        securitySettings.twoFactorAuth ? "translate-x-7" : "translate-x-0"
                      }`}
                    />
                  </button>
                </div>

                {/* Session Timeout */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Session Timeout Duration</label>
                  <select
                    value={securitySettings.sessionTimeout}
                    onChange={handleSessionTimeoutChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                  >
                    <option value="15">15 minutes</option>
                    <option value="30">30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="120">2 hours</option>
                    <option value="240">4 hours</option>
                    <option value="480">8 hours</option>
                  </select>
                  <p className="text-xs text-gray-500 mt-2">Automatically log out after this period of inactivity</p>
                </div>

                {/* Change Password Button */}
                <div className="pt-6 border-t border-gray-200">
                  <h3 className="text-sm font-semibold text-gray-800 mb-2">Password Management</h3>
                  <p className="text-xs text-gray-600 mb-4">Update your password to keep your account secure</p>
                  <button
                    onClick={() => setShowPasswordModal(true)}
                    className="w-full bg-white border-2 border-[#FF6600] text-[#FF6600] py-3 px-6 rounded-xl font-semibold hover:bg-orange-50 transition-all shadow-md hover:shadow-lg"
                  >
                    Change Password
                  </button>
                </div>

                {/* Save Button */}
                <div className="pt-6">
                  <button
                    onClick={handleSaveSecuritySettings}
                    className="w-full bg-[#FF6600] text-white py-3 px-6 rounded-xl font-semibold hover:bg-[#E55A00] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                  >
                    <Save className="w-5 h-5" />
                    Save Settings
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "support" && (
            <div>
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Support & Contact</h2>
              <p className="text-sm text-gray-600 mb-8">
                Need help? Send us a message and we'll get back to you as soon as possible.
              </p>

              <div className="space-y-6">
                {/* Support Email Field */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Your Email Address</label>
                  <input
                    type="email"
                    name="email"
                    value={supportContact.email}
                    onChange={handleSupportContactChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all"
                    placeholder="Enter your email address"
                  />
                  <p className="text-xs text-gray-500 mt-2">We'll use this email to respond to your inquiry</p>
                </div>

                {/* Message Box */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
                  <textarea
                    name="message"
                    value={supportContact.message}
                    onChange={handleSupportContactChange}
                    rows={8}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all resize-none"
                    placeholder="Describe your issue or question in detail..."
                  />
                  <p className="text-xs text-gray-500 mt-2">
                    Please provide as much detail as possible to help us assist you better
                  </p>
                </div>

                {/* Send Message Button */}
                <div className="pt-6">
                  <button
                    onClick={handleSendMessage}
                    className="w-full bg-[#FF6600] text-white py-3 px-6 rounded-xl font-semibold hover:bg-[#E55A00] transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                  >
                    <Send className="w-5 h-5" />
                    Send Message
                  </button>
                </div>

                {/* Additional Support Info */}
                <div className="mt-8 p-4 bg-orange-50 border border-orange-200 rounded-xl">
                  <h3 className="text-sm font-semibold text-gray-800 mb-2">Other Ways to Reach Us</h3>
                  <div className="space-y-2 text-sm text-gray-600">
                    <p>
                      <span className="font-medium">Email:</span> support@foodyo.com
                    </p>
                    <p>
                      <span className="font-medium">Response Time:</span> Within 24 hours
                    </p>
                    <p>
                      <span className="font-medium">Business Hours:</span> Monday - Friday, 9:00 AM - 6:00 PM
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Password Change Modal */}
      {showPasswordModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-800">Change Password</h3>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-600" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Current Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                <div className="relative">
                  <input
                    type={showModalCurrentPassword ? "text" : "password"}
                    value={passwordModalData.currentPassword}
                    onChange={(e) => setPasswordModalData({ ...passwordModalData, currentPassword: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all pr-12"
                    placeholder="Enter current password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowModalCurrentPassword(!showModalCurrentPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showModalCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* New Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                <div className="relative">
                  <input
                    type={showModalNewPassword ? "text" : "password"}
                    value={passwordModalData.newPassword}
                    onChange={(e) => setPasswordModalData({ ...passwordModalData, newPassword: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all pr-12"
                    placeholder="Enter new password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowModalNewPassword(!showModalNewPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showModalNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Confirm New Password</label>
                <div className="relative">
                  <input
                    type={showModalConfirmPassword ? "text" : "password"}
                    value={passwordModalData.confirmPassword}
                    onChange={(e) => setPasswordModalData({ ...passwordModalData, confirmPassword: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#FF6600] focus:border-transparent transition-all pr-12"
                    placeholder="Confirm new password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowModalConfirmPassword(!showModalConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                  >
                    {showModalConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-xl font-semibold hover:bg-gray-50 transition-all"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePasswordChange}
                  className="flex-1 px-4 py-3 bg-[#FF6600] text-white rounded-xl font-semibold hover:bg-[#E55A00] transition-all shadow-lg"
                >
                  Update Password
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
