"use client"

import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import {
  ShoppingBag,
  Users,
  Store,
  Truck,
  ClipboardList,
  UserCog,
  UtensilsCrossed,
  BarChart3,
  LogOut,
  Home,
  Settings,
  Menu,
  X,
  Bike,
  Bell,
} from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AdminDashboard() {
  const router = useRouter()
  const { logout, isAdmin, isAuthenticated } = useAuth()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    if (!isAuthenticated || !isAdmin) {
      router.push("/login")
    }
  }, [isAuthenticated, isAdmin, router])

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  if (!isAuthenticated || !isAdmin) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    )
  }

  const stats = [
    {
      title: "Total Orders",
      value: "1,234",
      icon: ShoppingBag,
      color: "bg-orange-50",
      iconColor: "text-orange-600",
    },
    {
      title: "Active Users",
      value: "5,678",
      icon: Users,
      color: "bg-blue-50",
      iconColor: "text-blue-600",
    },
    {
      title: "Total Restaurants",
      value: "89",
      icon: Store,
      color: "bg-green-50",
      iconColor: "text-green-600",
    },
    {
      title: "Pending Deliveries",
      value: "23",
      icon: Truck,
      color: "bg-purple-50",
      iconColor: "text-purple-600",
    },
  ]

  const managementCards = [
    {
      title: "Manage Orders",
      description: "View and manage all customer orders",
      icon: ClipboardList,
      route: "/admin/orders",
      color: "bg-orange-500",
    },
    {
      title: "Manage Users",
      description: "View and manage user accounts",
      icon: UserCog,
      route: "/admin/users",
      color: "bg-blue-500",
    },
    {
      title: "Manage Restaurants / Meals",
      description: "Add, edit, or remove restaurants and meals",
      icon: UtensilsCrossed,
      route: "/admin/restaurants",
      color: "bg-green-500",
    },
    {
      title: "Reports & Analytics",
      description: "Download and view detailed reports",
      icon: BarChart3,
      route: "/admin/reports",
      color: "bg-purple-500",
    },
  ]

  const menuItems = [
    { name: "Dashboard", icon: Home, route: "/admin", active: true },
    { name: "Orders", icon: ClipboardList, route: "/admin/orders", active: false },
    { name: "Users", icon: UserCog, route: "/admin/users", active: false },
    { name: "Restaurants / Meals", icon: UtensilsCrossed, route: "/admin/restaurants", active: false },
    { name: "Reports", icon: BarChart3, route: "/admin/reports", active: false },
    { name: "Manage Drivers", icon: Bike, route: "/admin/drivers", active: false },
    { name: "Delivery Pricing", icon: Truck, route: "/admin/delivery-pricing", active: false },
    { name: "Broadcast Notifications", icon: Bell, route: "/admin/notifications", active: false },
    { name: "Settings", icon: Settings, route: "/admin/settings", active: false },
  ]

  return (
    <div className="min-h-screen bg-[#FFF9F5] flex">
      {/* Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        }`}
      >
        <div className="h-full flex flex-col">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold text-[#FF6600]">Foodyo</h2>
              <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-gray-600">
                <X className="h-6 w-6" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">Admin Panel</p>
          </div>

          {/* Navigation Menu */}
          <nav className="flex-1 p-4 space-y-2">
            {menuItems.map((item, index) => {
              const Icon = item.icon
              return (
                <button
                  key={index}
                  onClick={() => {
                    router.push(item.route)
                    setSidebarOpen(false)
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 shadow-sm ${
                    item.active
                      ? "bg-[#FF6600] text-white shadow-md"
                      : "text-gray-700 hover:bg-orange-50 hover:text-[#FF6600] hover:shadow-md"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="font-medium text-sm">{item.name}</span>
                </button>
              )
            })}
          </nav>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen">
        <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-30">
          <div className="px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-gray-600">
                  <Menu className="h-6 w-6" />
                </button>
                <div>
                  <h1 className="text-2xl font-bold text-[#FF6600]">Admin Dashboard</h1>
                  <p className="text-gray-600 text-sm mt-0.5">Manage your app easily and efficiently.</p>
                </div>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="flex items-center gap-2 border-[#FF6600] text-[#FF6600] hover:bg-[#FF6600] hover:text-white bg-transparent rounded-xl shadow-sm hover:shadow-md transition-all duration-200"
              >
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </div>
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8 animate-in fade-in slide-in-from-top-4 duration-500">
            <h2 className="text-3xl font-bold text-gray-800">Welcome, Admin</h2>
            <p className="text-gray-600 mt-1">Here's what's happening with your app today.</p>
          </div>

          {/* Quick Statistics Section */}
          <section className="mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Quick Statistics</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon
                return (
                  <div
                    key={index}
                    className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-gray-600 text-sm mb-1">{stat.title}</p>
                        <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                      </div>
                      <div className={`${stat.color} p-3 rounded-xl shadow-sm`}>
                        <Icon className={`h-6 w-6 ${stat.iconColor}`} />
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </section>

          {/* Management Section */}
          <section className="mb-12 animate-in fade-in slide-in-from-bottom-4 duration-1000">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Management</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {managementCards.map((card, index) => {
                const Icon = card.icon
                return (
                  <button
                    key={index}
                    onClick={() => router.push(card.route)}
                    className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:scale-[1.02] text-left group"
                  >
                    <div className="flex items-start gap-4">
                      <div
                        className={`${card.color} p-3 rounded-xl shadow-sm group-hover:scale-110 transition-transform duration-300`}
                      >
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900 mb-1">{card.title}</h3>
                        <p className="text-gray-600 text-sm">{card.description}</p>
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          </section>
        </main>

        {/* Footer Section */}
        <footer className="bg-white border-t border-gray-200 mt-auto">
          <div className="px-4 sm:px-6 lg:px-8 py-6">
            <p className="text-center text-gray-600 text-sm">Foodyo Admin Panel © 2025 – All Rights Reserved.</p>
          </div>
        </footer>
      </div>
    </div>
  )
}
