import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import "./globals.css"
import { AuthProvider } from "@/lib/auth-context"
import { CartProvider } from "@/lib/cart-context"
import { LocationProvider } from "@/lib/location-context"
import { Toaster } from "sonner"

export const metadata: Metadata = {
  title: "Foodyo - Fast Food Delivery",
  description: "Order food from top restaurants with Foodyo on Pi Network",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@800;900&display=swap" rel="stylesheet" />
        <script src="https://sdk.minepi.com/pi-sdk.js"></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              console.log('[Foodyo Pi] Script tag executing...');
              
              // Detect if we're in sandbox/development mode
              var isDevelopment = (
                window.location.hostname === 'localhost' || 
                window.location.hostname.includes('v0.app') ||
                window.location.hostname.includes('127.0.0.1') ||
                window.location.hostname.includes('vercel.app')
              );
              
              console.log('[Foodyo Pi] Environment detected:', { isDevelopment, hostname: window.location.hostname });
              
              // Initialize immediately when script runs
              var initAttempts = 0;
              var maxAttempts = 100; // 10 seconds total
              
              function tryInitialize() {
                initAttempts++;
                console.log('[Foodyo Pi] Init attempt', initAttempts, 'of', maxAttempts);
                
                if (typeof Pi !== 'undefined') {
                  console.log('[Foodyo Pi] Pi object found, initializing...');
                  try {
                    Pi.init({ version: "2.0", sandbox: isDevelopment });
                    window.piSDKInitialized = true;
                    window.piSDKSandboxMode = isDevelopment;
                    console.log('[Foodyo Pi] ✓ SDK initialized successfully', { 
                      sandbox: isDevelopment,
                      attempt: initAttempts,
                      piSDKInitialized: window.piSDKInitialized
                    });
                    // Dispatch event for React components
                    var event = new Event('piSDKReady');
                    window.dispatchEvent(event);
                    console.log('[Foodyo Pi] ✓ piSDKReady event dispatched');
                  } catch (error) {
                    console.error('[Foodyo Pi] ✗ Failed to initialize Pi SDK:', error);
                    window.piSDKInitialized = false;
                  }
                } else {
                  console.log('[Foodyo Pi] Pi object not found yet, will retry...');
                  if (initAttempts < maxAttempts) {
                    setTimeout(tryInitialize, 100);
                  } else {
                    console.error('[Foodyo Pi] ✗ Pi SDK failed to load after', maxAttempts, 'attempts');
                    console.error('[Foodyo Pi] Make sure you are running in Pi Browser or have authorized sandbox mode');
                    window.piSDKInitialized = false;
                  }
                }
              }
              
              // Start initialization
              console.log('[Foodyo Pi] Starting initialization process...');
              tryInitialize();
            `,
          }}
        />
        <style>{`
html {
  font-family: ${GeistSans.style.fontFamily};
  --font-sans: ${GeistSans.variable};
  --font-mono: ${GeistMono.variable};
}
        `}</style>
      </head>
      <body>
        <AuthProvider>
          <CartProvider>
            <LocationProvider>
              {children}
              <Toaster position="top-center" richColors />
            </LocationProvider>
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
