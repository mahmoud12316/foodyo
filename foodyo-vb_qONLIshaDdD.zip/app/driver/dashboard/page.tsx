"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Bike,
  Package,
  MapPin,
  Phone,
  Navigation,
  Store,
  DollarSign,
  LogOut,
  RefreshCw,
  CheckCircle,
} from "lucide-react"

type OrderStatus =
  | "New Order"
  | "Preparing"
  | "Ready for Pickup/Delivery"
  | "Assigned to Driver"
  | "Out for Delivery"
  | "Delivered"
  | "Cancelled"

interface Order {
  id: string
  orderNumber: string
  restaurantName: string
  restaurantAddress: string
  restaurantPhone: string
  customerName: string
  customerAddress: string
  customerPhone: string
  items: Array<{
    name: string
    quantity: number
    price: number
  }>
  totalAmount: number
  status: OrderStatus
  orderTime: string
  driverId?: string
  customerId?: string
}

export default function DriverDashboardPage() {
  const router = useRouter()
  const [orders, setOrders] = useState<Order[]>([])
  const [driverName, setDriverName] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  const handleLogout = () => {
    localStorage.removeItem("driverAuthToken")
    localStorage.removeItem("driverId")
    localStorage.removeItem("driverData")
    router.push("/driver/login")
  }

  useEffect(() => {
    // Check authentication
    const authToken = localStorage.getItem("driverAuthToken")
    const driverId = localStorage.getItem("driverId")

    if (!authToken || !driverId) {
      router.push("/driver/login")
      return
    }

    // Load driver data
    const savedDriverData = localStorage.getItem("driverData")
    if (savedDriverData) {
      const driverData = JSON.parse(savedDriverData)
      setDriverName(driverData.name)
    }

    // Load orders assigned to this driver
    loadAssignedOrders(driverId)
  }, [router])

  const loadAssignedOrders = (driverId: string) => {
    setIsLoading(true)

    // Mock data - in production this would fetch from API
    const mockOrders: Order[] = [
      {
        id: "1",
        orderNumber: "ORD-2024-001",
        restaurantName: "Pizza Palace",
        restaurantAddress: "123 Main St, Downtown",
        restaurantPhone: "+962 777 123 456",
        customerName: "Ahmad Mansour",
        customerAddress: "456 Oak Avenue, Apt 5B, Zarqa",
        customerPhone: "+962 777 987 654",
        items: [
          { name: "Margherita Pizza", quantity: 2, price: 12.99 },
          { name: "Garlic Bread", quantity: 1, price: 4.99 },
        ],
        totalAmount: 30.97,
        status: "Assigned to Driver",
        orderTime: "2024-01-15 12:30 PM",
        driverId: driverId,
        customerId: "CUST-2024-001",
      },
      {
        id: "2",
        orderNumber: "ORD-2024-002",
        restaurantName: "Burger House",
        restaurantAddress: "789 Food Street, City Center",
        restaurantPhone: "+962 777 222 333",
        customerName: "Fatima Ali",
        customerAddress: "789 Maple Drive, Building 12, Zarqa",
        customerPhone: "+962 777 444 555",
        items: [
          { name: "Classic Burger", quantity: 3, price: 8.99 },
          { name: "French Fries", quantity: 2, price: 3.99 },
        ],
        totalAmount: 34.95,
        status: "Assigned to Driver",
        orderTime: "2024-01-15 12:45 PM",
        driverId: driverId,
        customerId: "CUST-2024-002",
      },
    ]

    setOrders(mockOrders)
    setIsLoading(false)
  }

  const handleStartDelivery = async (orderId: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: "Out for Delivery" } : order)))
    setSelectedOrder(null)

    try {
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientType: "customer",
          recipientId: orders.find((o) => o.id === orderId)?.customerId,
          title: "Out for Delivery!",
          message: "Your order is on the way! The driver has started delivery.",
          notificationType: "order_out_for_delivery",
          orderId: orderId,
        }),
      })
    } catch (error) {
      console.error("Failed to send notification:", error)
    }
  }

  const handleConfirmDelivery = (orderId: string) => {
    // Update order status to "Delivered"
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: "Delivered" } : order)))

    // Close modal if open
    if (selectedOrder?.id === orderId) {
      setSelectedOrder(null)
    }

    // Filter out delivered orders after a brief delay to show the status update
    setTimeout(() => {
      setOrders((prevOrders) => prevOrders.filter((order) => order.status !== "Delivered"))
    }, 1500)
  }

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case "Assigned to Driver":
        return "bg-blue-100 text-blue-700 border-blue-300"
      case "Out for Delivery":
        return "bg-purple-100 text-purple-700 border-purple-300"
      case "Delivered":
        return "bg-green-100 text-green-700 border-green-300"
      default:
        return "bg-gray-100 text-gray-700 border-gray-300"
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-blue-600 border-r-transparent" />
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6 border-2 border-blue-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-blue-500 rounded-xl flex items-center justify-center shadow-lg">
                <Bike className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Driver Dashboard</h1>
                <p className="text-gray-600">Welcome back, {driverName}!</p>
              </div>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-red-300 text-red-600 hover:bg-red-50 bg-transparent"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {/* Orders Section */}
        <div className="bg-white rounded-xl shadow-lg p-6 border-2 border-blue-100">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Package className="w-6 h-6 text-blue-600" />
              <h2 className="text-xl font-bold text-gray-900">My Assigned Orders</h2>
              <Badge className="bg-blue-100 text-blue-700 border-blue-300">
                {orders.filter((o) => o.status === "Assigned to Driver").length} New
              </Badge>
              {orders.filter((o) => o.status === "Out for Delivery").length > 0 && (
                <Badge className="bg-purple-100 text-purple-700 border-purple-300">
                  {orders.filter((o) => o.status === "Out for Delivery").length} In Transit
                </Badge>
              )}
            </div>
            <Button
              onClick={() => loadAssignedOrders(localStorage.getItem("driverId") || "")}
              variant="outline"
              size="sm"
              className="border-blue-300"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>

          {orders.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 text-lg font-medium">No orders assigned yet</p>
              <p className="text-gray-400 text-sm mt-2">Check back soon for new deliveries</p>
            </div>
          ) : (
            <div className="grid gap-4">
              {orders.map((order) => (
                <Card
                  key={order.id}
                  className={`border-2 transition-all cursor-pointer hover:shadow-lg ${
                    order.status === "Assigned to Driver"
                      ? "border-blue-300 bg-blue-50"
                      : order.status === "Out for Delivery"
                        ? "border-purple-300 bg-purple-50"
                        : "border-gray-200"
                  }`}
                  onClick={() => setSelectedOrder(order)}
                >
                  <CardContent className="p-5">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-bold text-lg text-gray-900 mb-1">{order.orderNumber}</h3>
                        <Badge className={`${getStatusColor(order.status)} border font-semibold`}>{order.status}</Badge>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-500">Order Time</p>
                        <p className="text-sm font-semibold text-gray-900">{order.orderTime}</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      {/* Pickup Details */}
                      <div className="bg-white rounded-lg p-3 border border-orange-200">
                        <div className="flex items-center gap-2 mb-2">
                          <Store className="w-4 h-4 text-orange-600" />
                          <p className="text-xs font-semibold text-gray-600 uppercase">Pickup From</p>
                        </div>
                        <p className="font-bold text-gray-900">{order.restaurantName}</p>
                        <p className="text-sm text-gray-600 mt-1">{order.restaurantAddress}</p>
                        <p className="text-sm text-gray-600 flex items-center gap-1 mt-1">
                          <Phone className="w-3 h-3" />
                          {order.restaurantPhone}
                        </p>
                      </div>

                      {/* Delivery Details */}
                      <div className="bg-white rounded-lg p-3 border border-green-200">
                        <div className="flex items-center gap-2 mb-2">
                          <MapPin className="w-4 h-4 text-green-600" />
                          <p className="text-xs font-semibold text-gray-600 uppercase">Deliver To</p>
                        </div>
                        <p className="font-bold text-gray-900">{order.customerName}</p>
                        <p className="text-sm text-gray-600 mt-1">{order.customerAddress}</p>
                        <p className="text-sm text-gray-600 flex items-center gap-1 mt-1">
                          <Phone className="w-3 h-3" />
                          {order.customerPhone}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t">
                      <div className="flex items-center gap-2 text-gray-600">
                        <DollarSign className="w-5 h-5 text-green-600" />
                        <span className="text-lg font-bold text-gray-900">JOD {order.totalAmount.toFixed(2)}</span>
                      </div>
                      {order.status === "Assigned to Driver" && (
                        <Button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleStartDelivery(order.id)
                          }}
                          className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600"
                        >
                          <Navigation className="w-4 h-4 mr-2" />
                          Start Delivery
                        </Button>
                      )}
                      {order.status === "Out for Delivery" && (
                        <Button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleConfirmDelivery(order.id)
                          }}
                          className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600"
                        >
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Confirm Delivery
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div
          className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50"
          onClick={() => setSelectedOrder(null)}
        >
          <div
            className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">Order Details</h2>
                <Badge className={`${getStatusColor(selectedOrder.status)} border-2 text-base px-3 py-1`}>
                  {selectedOrder.status}
                </Badge>
              </div>

              <div className="space-y-6">
                {/* Order Info */}
                <div>
                  <p className="text-sm text-gray-500 mb-1">Order Number</p>
                  <p className="text-lg font-bold text-gray-900">{selectedOrder.orderNumber}</p>
                </div>

                <Separator />

                {/* Pickup Information */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Store className="w-5 h-5 text-orange-600" />
                    <h3 className="font-bold text-lg text-gray-900">Pickup Location</h3>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-4 border-2 border-orange-200">
                    <p className="font-bold text-gray-900 text-lg">{selectedOrder.restaurantName}</p>
                    <p className="text-gray-700 mt-2">{selectedOrder.restaurantAddress}</p>
                    <p className="text-gray-700 flex items-center gap-2 mt-2">
                      <Phone className="w-4 h-4" />
                      {selectedOrder.restaurantPhone}
                    </p>
                  </div>
                </div>

                {/* Delivery Information */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <MapPin className="w-5 h-5 text-green-600" />
                    <h3 className="font-bold text-lg text-gray-900">Delivery Location</h3>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4 border-2 border-green-200">
                    <p className="font-bold text-gray-900 text-lg">{selectedOrder.customerName}</p>
                    <p className="text-gray-700 mt-2">{selectedOrder.customerAddress}</p>
                    <p className="text-gray-700 flex items-center gap-2 mt-2">
                      <Phone className="w-4 h-4" />
                      {selectedOrder.customerPhone}
                    </p>
                  </div>
                </div>

                {/* Order Items */}
                <div>
                  <h3 className="font-bold text-lg text-gray-900 mb-3">Order Items</h3>
                  <div className="bg-gray-50 rounded-lg p-4 border-2 border-gray-200">
                    {selectedOrder.items.map((item, index) => (
                      <div key={index} className="flex justify-between py-2">
                        <span className="text-gray-700">
                          {item.quantity}x {item.name}
                        </span>
                        <span className="font-semibold text-gray-900">
                          JOD {(item.price * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    ))}
                    <Separator className="my-3" />
                    <div className="flex justify-between">
                      <span className="font-bold text-lg text-gray-900">Total Amount</span>
                      <span className="font-bold text-lg text-green-600">
                        JOD {selectedOrder.totalAmount.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-3 pt-4">
                  {selectedOrder.status === "Assigned to Driver" && (
                    <Button
                      onClick={() => handleStartDelivery(selectedOrder.id)}
                      className="flex-1 h-12 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white font-semibold"
                    >
                      <Navigation className="w-5 h-5 mr-2" />
                      Start Delivery Now
                    </Button>
                  )}
                  {selectedOrder.status === "Out for Delivery" && (
                    <Button
                      onClick={() => handleConfirmDelivery(selectedOrder.id)}
                      className="flex-1 h-12 bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white font-semibold"
                    >
                      <CheckCircle className="w-5 h-5 mr-2" />
                      Confirm Delivery
                    </Button>
                  )}
                  <Button onClick={() => setSelectedOrder(null)} variant="outline" className="flex-1 h-12">
                    Close
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
