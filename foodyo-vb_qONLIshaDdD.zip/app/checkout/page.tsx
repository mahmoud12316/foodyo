"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Card } from "@/components/ui/card"
import { MapPin, CreditCard, Wallet, ArrowLeft, Home, Briefcase, Plus } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { useAuth } from "@/lib/auth-context"
import { toast } from "sonner"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import dynamic from "next/dynamic"

const MapPicker = dynamic(() => import("@/components/map-picker"), { ssr: false })

interface SavedLocation {
  id: number
  nickname: string
  address: string
  latitude: number
  longitude: number
  isDefault: boolean
}

export default function CheckoutPage() {
  const router = useRouter()
  const { items, clearCart } = useCart()
  const { isAuthenticated, userName, userEmail } = useAuth()

  const [name, setName] = useState(userName || "")
  const [email, setEmail] = useState(userEmail || "")
  const [phone, setPhone] = useState("")
  const [address, setAddress] = useState("")
  const [paymentMethod, setPaymentMethod] = useState("cash")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showLocationPicker, setShowLocationPicker] = useState(false)
  const [selectedLat, setSelectedLat] = useState<number | null>(null)
  const [selectedLng, setSelectedLng] = useState<number | null>(null)
  const [selectedLocationId, setSelectedLocationId] = useState<number | null>(null)

  const [deliveryFee, setDeliveryFee] = useState(5)
  const [calculatingFee, setCalculatingFee] = useState(false)
  const [restaurantLat, setRestaurantLat] = useState<number | null>(null)
  const [restaurantLng, setRestaurantLng] = useState<number | null>(null)

  const subtotal = items.reduce((total, item) => {
    const itemTotal = item.price * item.quantity
    const addonsTotal = (item.selectedAddons || []).reduce((sum, addon) => sum + addon.price, 0) * item.quantity
    return total + itemTotal + addonsTotal
  }, 0)
  const total = subtotal + deliveryFee

  useEffect(() => {
    if (isAuthenticated) {
      fetchSavedLocations()
    }
  }, [isAuthenticated])

  useEffect(() => {
    if (selectedLat && selectedLng && restaurantLat && restaurantLng) {
      calculateDeliveryFee()
    }
  }, [selectedLat, selectedLng, restaurantLat, restaurantLng])

  useEffect(() => {
    if (items.length > 0 && items[0].restaurantId) {
      // In production, fetch actual restaurant coordinates
      // For now, use mock coordinates (Zarqa, Jordan)
      setRestaurantLat(32.0667)
      setRestaurantLng(36.1)
    }
  }, [items])

  const fetchSavedLocations = async () => {
    try {
      const response = await fetch("/api/saved-locations?userId=1")
      const data = await response.json()
      setSavedLocations(data.locations || [])

      const defaultLocation = data.locations.find((loc: SavedLocation) => loc.isDefault)
      if (defaultLocation) {
        handleSelectSavedLocation(defaultLocation)
      }
    } catch (error) {
      console.error("Error fetching saved locations:", error)
    }
  }

  const calculateDeliveryFee = async () => {
    if (!restaurantLat || !restaurantLng || !selectedLat || !selectedLng) return

    setCalculatingFee(true)
    try {
      const response = await fetch("/api/delivery-pricing/calculate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          restaurantLat,
          restaurantLng,
          deliveryLat: selectedLat,
          deliveryLng: selectedLng,
        }),
      })

      const data = await response.json()
      if (data.deliveryFee) {
        setDeliveryFee(data.deliveryFee)
      }
    } catch (error) {
      console.error("Error calculating delivery fee:", error)
    } finally {
      setCalculatingFee(false)
    }
  }

  const handleSelectLocation = () => {
    setShowLocationPicker(true)
  }

  const handleLocationConfirm = (lat: number, lng: number, addressText: string) => {
    setSelectedLat(lat)
    setSelectedLng(lng)
    setAddress(addressText)
    setSelectedLocationId(null)
    setShowLocationPicker(false)
  }

  const handleSelectSavedLocation = (location: SavedLocation) => {
    setSelectedLocationId(location.id)
    setAddress(location.address)
    setSelectedLat(location.latitude)
    setSelectedLng(location.longitude)
    setShowSavedAddresses(false)
  }

  const getLocationIcon = (nickname: string) => {
    const lower = nickname.toLowerCase()
    if (lower.includes("home")) return <Home className="w-5 h-5" />
    if (lower.includes("work") || lower.includes("office")) return <Briefcase className="w-5 h-5" />
    return <MapPin className="w-5 h-5" />
  }

  const handlePlaceOrder = async () => {
    // Validation
    if (!name.trim()) {
      toast.error("Please enter your name")
      return
    }
    if (!email.trim()) {
      toast.error("Please enter your email")
      return
    }
    if (!phone.trim()) {
      toast.error("Please enter your phone number")
      return
    }
    if (!address.trim()) {
      toast.error("Please select a delivery location")
      return
    }

    setIsSubmitting(true)

    try {
      // Prepare order data
      const orderData = {
        customerName: name,
        customerEmail: email,
        customerPhone: phone,
        deliveryAddress: address,
        deliveryLat: selectedLat,
        deliveryLng: selectedLng,
        paymentMethod: paymentMethod,
        items: items.map((item) => ({
          mealId: item.id,
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          selectedAddons: item.selectedAddons || [],
        })),
        subtotal: subtotal,
        deliveryFee: deliveryFee,
        total: total,
        status: "New Order",
        createdAt: new Date().toISOString(),
      }

      // Submit to database
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      })

      if (!response.ok) {
        throw new Error("Failed to place order")
      }

      const result = await response.json()

      // Clear cart and show success
      clearCart()
      toast.success("Order placed successfully!")

      // Redirect to order tracking
      router.push(`/orders/track/${result.orderId}`)
    } catch (error) {
      console.error("Order submission error:", error)
      toast.error("Failed to place order. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>([])
  const [showSavedAddresses, setShowSavedAddresses] = useState(false)

  if (!isAuthenticated) {
    router.push("/login")
    return null
  }

  if (items.length === 0) {
    router.push("/cart")
    return null
  }

  return (
    <>
      <div className="min-h-screen bg-[#FFF9F5]">
        <Header />

        <div className="container mx-auto px-4 py-6 max-w-2xl">
          <Button variant="ghost" onClick={() => router.back()} className="mb-4 -ml-2">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Cart
          </Button>

          <h1 className="text-2xl font-bold text-gray-900 mb-6">Checkout</h1>

          <div className="space-y-6">
            {/* Contact Information */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h2>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    type="text"
                    placeholder="Enter your full name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            </Card>

            {/* Delivery Location */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Delivery Location *</h2>
              <div className="space-y-3">
                {/* Saved Addresses Button */}
                {savedLocations.length > 0 && (
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-4 bg-transparent"
                    onClick={() => setShowSavedAddresses(true)}
                  >
                    <MapPin className="w-5 h-5 mr-3 flex-shrink-0 text-[#FF6600]" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900">Select Saved Address</p>
                      <p className="text-sm text-gray-600">Choose from {savedLocations.length} saved location(s)</p>
                    </div>
                  </Button>
                )}

                {/* Current Selection */}
                {address && (
                  <div className="p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="flex items-start gap-3">
                      <div className="text-orange-600 mt-0.5">
                        {selectedLocationId ? (
                          getLocationIcon(savedLocations.find((loc) => loc.id === selectedLocationId)?.nickname || "")
                        ) : (
                          <MapPin className="w-5 h-5" />
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">
                          {selectedLocationId
                            ? savedLocations.find((loc) => loc.id === selectedLocationId)?.nickname
                            : "Custom Location"}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">{address}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleSelectLocation}
                        className="text-orange-600 hover:text-orange-700 hover:bg-orange-100"
                      >
                        Change
                      </Button>
                    </div>
                  </div>
                )}

                {/* Select on Map Button */}
                {!address && (
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-4 bg-transparent"
                    onClick={handleSelectLocation}
                  >
                    <Plus className="w-5 h-5 mr-3 flex-shrink-0 text-[#FF6600]" />
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Select on Map</p>
                      <p className="text-sm text-gray-600">Choose a new delivery location</p>
                    </div>
                  </Button>
                )}
              </div>
            </Card>

            {/* Payment Method */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Method *</h2>
              <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                  <RadioGroupItem value="cash" id="cash" />
                  <Label htmlFor="cash" className="flex items-center gap-3 cursor-pointer flex-1">
                    <Wallet className="w-5 h-5 text-[#FF6600]" />
                    <div>
                      <p className="font-medium">Cash on Delivery</p>
                      <p className="text-sm text-gray-500">Pay when your order arrives</p>
                    </div>
                  </Label>
                </div>
                <div className="flex items-center space-x-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50 opacity-60">
                  <RadioGroupItem value="card" id="card" disabled />
                  <Label htmlFor="card" className="flex items-center gap-3 cursor-not-allowed flex-1">
                    <CreditCard className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="font-medium text-gray-500">Card Payment</p>
                      <p className="text-sm text-gray-400">Coming soon</p>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </Card>

            {/* Order Summary */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Summary</h2>
              <div className="space-y-3">
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span className="text-gray-600">
                      {item.name} x{item.quantity}
                    </span>
                    <span className="font-medium text-gray-900">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
                <div className="border-t pt-3 space-y-2">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Delivery Fee</span>
                    <span>{calculatingFee ? "Calculating..." : `$${deliveryFee.toFixed(2)}`}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span className="text-[#FF6600]">${total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </Card>

            {/* Place Order Button */}
            <Button
              className="w-full bg-[#FF6600] hover:bg-[#FF5500] text-white py-6 text-lg font-semibold"
              onClick={handlePlaceOrder}
              disabled={isSubmitting}
            >
              {isSubmitting ? "Placing Order..." : `Place Order - $${total.toFixed(2)}`}
            </Button>
          </div>
        </div>
      </div>

      <Dialog open={showSavedAddresses} onOpenChange={setShowSavedAddresses}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Select Saved Address</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {savedLocations.map((location) => (
              <button
                key={location.id}
                onClick={() => handleSelectSavedLocation(location)}
                className="w-full flex items-start gap-3 p-4 border rounded-lg hover:bg-orange-50 hover:border-orange-300 transition-colors text-left"
              >
                <div className="text-orange-500 mt-1">{getLocationIcon(location.nickname)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-gray-900">{location.nickname}</p>
                    {location.isDefault && (
                      <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded-full">Default</span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{location.address}</p>
                </div>
              </button>
            ))}
          </div>
          <div className="pt-4 border-t">
            <Button
              variant="outline"
              className="w-full bg-transparent"
              onClick={() => {
                setShowSavedAddresses(false)
                setShowLocationPicker(true)
              }}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add New Address
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Location Picker Dialog */}
      <Dialog open={showLocationPicker} onOpenChange={setShowLocationPicker}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Select Delivery Location</DialogTitle>
          </DialogHeader>
          <div className="h-[500px]">
            <MapPicker onLocationSelect={handleLocationConfirm} initialLat={selectedLat} initialLng={selectedLng} />
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
