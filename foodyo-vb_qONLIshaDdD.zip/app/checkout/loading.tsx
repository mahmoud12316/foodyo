import { Header } from "@/components/header"

export default function CheckoutLoading() {
  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <Header />
      <div className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="space-y-6">
          <div className="h-8 bg-muted animate-pulse rounded" />
          <div className="h-64 bg-muted animate-pulse rounded-lg" />
          <div className="h-32 bg-muted animate-pulse rounded-lg" />
        </div>
      </div>
    </div>
  )
}
