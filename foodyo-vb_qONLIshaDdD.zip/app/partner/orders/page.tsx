"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import {
  ArrowLeft,
  Package,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  RefreshCw,
  Phone,
  MapPin,
  DollarSign,
  Check,
  X,
  AlertCircle,
  UserCheck,
  Bike,
  Car,
} from "lucide-react"
import Image from "next/image"

type OrderStatus = "New Order" | "Preparing" | "Ready for Pickup/Delivery" | "Assigned to Driver" | "Cancelled"

type OrderItem = {
  name: string
  image: string
  quantity: number
  price: number
}

type Order = {
  id: string
  customer: string
  email: string
  phone: string
  status: OrderStatus
  total: number
  deliveryFee: number
  date: string
  time: string
  items: OrderItem[]
  address: string
  paymentMethod: string
  notes?: string
  driverId?: string
  driverName?: string
  customerId?: string // Added customerId for notification purposes
}

type Driver = {
  id: string
  name: string
  phone: string
  vehicleType: string
  licensePlate: string
  isAvailable: boolean
}

export default function PartnerOrdersPage() {
  const router = useRouter()
  const [partnerData, setPartnerData] = useState<any>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isAssignDriverOpen, setIsAssignDriverOpen] = useState(false)
  const [orderToAssign, setOrderToAssign] = useState<Order | null>(null)
  const [availableDrivers, setAvailableDrivers] = useState<Driver[]>([])

  useEffect(() => {
    // Check partner authentication
    const authToken = localStorage.getItem("partnerAuthToken")
    const savedPartnerData = localStorage.getItem("partnerData")

    if (!authToken || !savedPartnerData) {
      router.push("/partner/login")
      return
    }

    const data = JSON.parse(savedPartnerData)
    if (!data.isPartnerApproved) {
      router.push("/partner/login")
      return
    }

    setPartnerData(data)
    loadOrders(data.restaurantName)
    loadAvailableDrivers()
  }, [router])

  const loadAvailableDrivers = () => {
    // Sample available drivers - in production this would come from database
    const sampleDrivers: Driver[] = [
      {
        id: "DRV-001",
        name: "Ahmed Hassan",
        phone: "+962 79 123 4567",
        vehicleType: "Bike",
        licensePlate: "AB-1234",
        isAvailable: true,
      },
      {
        id: "DRV-002",
        name: "Mohammed Ali",
        phone: "+962 79 234 5678",
        vehicleType: "Car",
        licensePlate: "CD-5678",
        isAvailable: true,
      },
      {
        id: "DRV-003",
        name: "Omar Khalil",
        phone: "+962 79 345 6789",
        vehicleType: "Bike",
        licensePlate: "EF-9012",
        isAvailable: true,
      },
    ]
    setAvailableDrivers(sampleDrivers)
  }

  const loadOrders = (restaurantName: string) => {
    // Sample orders for this restaurant
    const sampleOrders: Order[] = [
      {
        id: "#ORD-001",
        customer: "John Smith",
        email: "john@email.com",
        phone: "+1 234-567-8900",
        status: "New Order",
        total: 45.99,
        deliveryFee: 5.0,
        date: "2025-01-20",
        time: "5 mins ago",
        items: [
          { name: "Margherita Pizza", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 18.99 },
          { name: "Garlic Bread", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 6.0 },
        ],
        address: "123 Main St, Apt 4B",
        paymentMethod: "Credit Card",
        notes: "Please ring the doorbell twice",
        customerId: "CUS-001", // Added customerId for notification purposes
      },
      {
        id: "#ORD-002",
        customer: "Sarah Johnson",
        email: "sarah@email.com",
        phone: "+1 234-567-8901",
        status: "Preparing",
        total: 32.5,
        deliveryFee: 4.5,
        date: "2025-01-20",
        time: "15 mins ago",
        items: [
          { name: "Chicken Burger", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 12.5 },
          { name: "Fries", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 5.0 },
        ],
        address: "456 Oak Avenue",
        paymentMethod: "Cash",
        customerId: "CUS-002", // Added customerId for notification purposes
      },
      {
        id: "#ORD-003",
        customer: "Mike Wilson",
        email: "mike@email.com",
        phone: "+1 234-567-8902",
        status: "Ready for Pickup/Delivery",
        total: 28.0,
        deliveryFee: 3.5,
        date: "2025-01-20",
        time: "25 mins ago",
        items: [
          { name: "Caesar Salad", image: "/placeholder.svg?height=80&width=80", quantity: 1, price: 14.0 },
          { name: "Iced Tea", image: "/placeholder.svg?height=80&width=80", quantity: 2, price: 3.5 },
        ],
        address: "789 Elm Street",
        paymentMethod: "Credit Card",
        customerId: "CUS-003", // Added customerId for notification purposes
      },
    ]

    setOrders(sampleOrders)
  }

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case "New Order":
        return "bg-yellow-200 text-yellow-900 border-yellow-400"
      case "Preparing":
        return "bg-blue-100 text-blue-800 border-blue-300"
      case "Ready for Pickup/Delivery":
        return "bg-green-100 text-green-800 border-green-300"
      case "Assigned to Driver":
        return "bg-purple-100 text-purple-800 border-purple-300"
      case "Cancelled":
        return "bg-red-100 text-red-800 border-red-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  const getStatusIcon = (status: OrderStatus) => {
    switch (status) {
      case "New Order":
        return <Clock className="w-4 h-4" />
      case "Preparing":
        return <Package className="w-4 h-4" />
      case "Ready for Pickup/Delivery":
        return <CheckCircle className="w-4 h-4" />
      case "Assigned to Driver":
        return <UserCheck className="w-4 h-4" />
      case "Cancelled":
        return <XCircle className="w-4 h-4" />
      default:
        return null
    }
  }

  const filteredOrders = orders.filter((order) => {
    if (statusFilter === "all") return true
    return order.status === statusFilter
  })

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order)
    setIsDetailsOpen(true)
  }

  const handleAcceptOrder = async (orderId: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: "Preparing" } : order)))

    try {
      await fetch("/api/notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          recipientType: "customer",
          recipientId: orders.find((o) => o.id === orderId)?.customerId,
          title: "Order Accepted!",
          message: "Your order has been accepted and is now being prepared.",
          notificationType: "order_accepted",
          orderId: orderId,
        }),
      })
    } catch (error) {
      console.error("Failed to send notification:", error)
    }
  }

  const handleRejectOrder = (orderId: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: "Cancelled" } : order)))
  }

  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    const order = orders.find((o) => o.id === orderId)
    if (order?.status === "New Order") {
      return // Block manual status change for new orders
    }
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))
  }

  const handleAssignDriver = (order: Order) => {
    setOrderToAssign(order)
    setIsAssignDriverOpen(true)
  }

  const handleConfirmDriverAssignment = (driverId: string) => {
    if (!orderToAssign) return

    const driver = availableDrivers.find((d) => d.id === driverId)
    if (!driver) return

    // Update order with driver info and new status
    setOrders(
      orders.map((order) =>
        order.id === orderToAssign.id
          ? {
              ...order,
              status: "Assigned to Driver",
              driverId: driver.id,
              driverName: driver.name,
            }
          : order,
      ),
    )

    // Close dialog
    setIsAssignDriverOpen(false)
    setOrderToAssign(null)
  }

  const newOrders = filteredOrders.filter((order) => order.status === "New Order")
  const otherOrders = filteredOrders.filter((order) => order.status !== "New Order")

  if (!partnerData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4 max-w-6xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => router.push("/partner/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Manage Orders</h1>
                <p className="text-sm text-gray-600">{partnerData.restaurantName}</p>
              </div>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => loadOrders(partnerData.restaurantName)}
              className="border-[#FF6600] text-[#FF6600] hover:bg-orange-50 bg-transparent"
            >
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Filters */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Filter Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="All Orders" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Orders</SelectItem>
                  <SelectItem value="New Order">New Order</SelectItem>
                  <SelectItem value="Preparing">Preparing</SelectItem>
                  <SelectItem value="Ready for Pickup/Delivery">Ready for Pickup/Delivery</SelectItem>
                  <SelectItem value="Assigned to Driver">Assigned to Driver</SelectItem>
                  <SelectItem value="Cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* New Orders Section */}
        {newOrders.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <AlertCircle className="w-6 h-6 text-yellow-600" />
              <h2 className="text-2xl font-bold text-gray-900">New Orders - Action Required</h2>
              <Badge className="bg-red-500 text-white">{newOrders.length}</Badge>
            </div>
            <div className="space-y-4">
              {newOrders.map((order) => (
                <Card
                  key={order.id}
                  className="border-2 border-yellow-400 bg-yellow-50 hover:shadow-xl transition-shadow"
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      {/* Order Info */}
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-3">
                          <h3 className="text-lg font-bold text-gray-900">{order.id}</h3>
                          <Badge className={`${getStatusColor(order.status)} border-2`}>
                            {getStatusIcon(order.status)}
                            <span className="ml-1 font-bold">{order.status}</span>
                          </Badge>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                          <div className="flex items-center gap-2 text-gray-700 font-medium">
                            <Phone className="w-4 h-4" />
                            <span>{order.customer}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-700 font-medium">
                            <Clock className="w-4 h-4 text-red-500" />
                            <span className="text-red-600 font-bold">{order.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-700">
                            <MapPin className="w-4 h-4" />
                            <span className="truncate">{order.address}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-700">
                            <DollarSign className="w-4 h-4" />
                            <span className="font-bold text-[#FF6600] text-lg">${order.total.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 min-w-[220px]">
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleAcceptOrder(order.id)}
                            className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                          >
                            <Check className="w-4 h-4 mr-2" />
                            Accept
                          </Button>
                          <Button
                            onClick={() => handleRejectOrder(order.id)}
                            variant="destructive"
                            className="flex-1 bg-red-600 hover:bg-red-700"
                          >
                            <X className="w-4 h-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => handleViewDetails(order)}
                          className="w-full border-[#FF6600] text-[#FF6600] hover:bg-orange-50"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Active Orders Section */}
        {otherOrders.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-4">
              {newOrders.length > 0 ? "Active Orders" : "Orders"}
            </h2>
            <div className="space-y-4">
              {otherOrders.map((order) => (
                <Card key={order.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                      {/* Order Info */}
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-3">
                          <h3 className="text-lg font-bold text-gray-900">{order.id}</h3>
                          <Badge className={`${getStatusColor(order.status)} border`}>
                            {getStatusIcon(order.status)}
                            <span className="ml-1">{order.status}</span>
                          </Badge>
                          {order.driverName && (
                            <Badge className="bg-purple-200 text-purple-900 border-purple-400">
                              <UserCheck className="w-3 h-3 mr-1" />
                              {order.driverName}
                            </Badge>
                          )}
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Phone className="w-4 h-4" />
                            <span>{order.customer}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Clock className="w-4 h-4" />
                            <span>{order.time}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <MapPin className="w-4 h-4" />
                            <span className="truncate">{order.address}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <DollarSign className="w-4 h-4" />
                            <span className="font-semibold text-[#FF6600]">${order.total.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col gap-2 min-w-[200px]">
                        {order.status === "Ready for Pickup/Delivery" && (
                          <Button
                            onClick={() => handleAssignDriver(order)}
                            className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                          >
                            <UserCheck className="w-4 h-4 mr-2" />
                            Assign Driver
                          </Button>
                        )}
                        <Select
                          value={order.status}
                          onValueChange={(value) => handleStatusChange(order.id, value as OrderStatus)}
                          disabled={order.status === "Cancelled" || order.status === "Assigned to Driver"}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Preparing">Preparing</SelectItem>
                            <SelectItem value="Ready for Pickup/Delivery">Ready for Pickup/Delivery</SelectItem>
                            <SelectItem value="Cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button
                          variant="outline"
                          onClick={() => handleViewDetails(order)}
                          className="w-full border-[#FF6600] text-[#FF6600] hover:bg-orange-50"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {filteredOrders.length === 0 && (
          <Card>
            <CardContent className="py-12 text-center">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Orders Found</h3>
              <p className="text-gray-500">
                {statusFilter === "all"
                  ? "No orders yet. New orders will appear here."
                  : `No orders with status "${statusFilter}"`}
              </p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Order Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#FF6600]">Order Details</DialogTitle>
            <DialogDescription>Complete information for {selectedOrder?.id}</DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-6">
              {/* Customer Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-semibold text-gray-700">Customer</p>
                  <p className="text-sm text-gray-900">{selectedOrder.customer}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">Phone</p>
                  <p className="text-sm text-gray-900">{selectedOrder.phone}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">Email</p>
                  <p className="text-sm text-gray-900">{selectedOrder.email}</p>
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">Payment</p>
                  <p className="text-sm text-gray-900">{selectedOrder.paymentMethod}</p>
                </div>
              </div>

              {/* Delivery Address */}
              <div>
                <p className="text-sm font-semibold text-gray-700">Delivery Address</p>
                <p className="text-sm text-gray-900">{selectedOrder.address}</p>
              </div>

              {/* Driver Info */}
              {selectedOrder.driverName && (
                <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Assigned Driver</p>
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5 text-purple-600" />
                    <p className="text-sm text-gray-900 font-medium">{selectedOrder.driverName}</p>
                  </div>
                </div>
              )}

              {/* Special Notes */}
              {selectedOrder.notes && (
                <div>
                  <p className="text-sm font-semibold text-gray-700">Special Notes</p>
                  <p className="text-sm text-gray-900 bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                    {selectedOrder.notes}
                  </p>
                </div>
              )}

              {/* Order Items */}
              <div>
                <p className="text-sm font-semibold text-gray-700 mb-3">Order Items</p>
                <div className="space-y-3">
                  {selectedOrder.items.map((item, index) => (
                    <div key={index} className="flex items-center gap-4 bg-gray-50 p-3 rounded-lg">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        width={60}
                        height={60}
                        className="rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{item.name}</p>
                        <p className="text-xs text-gray-500">Quantity: {item.quantity}</p>
                      </div>
                      <p className="text-sm font-semibold text-[#FF6600]">${(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Price Summary */}
              <div className="border-t pt-4">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium text-gray-900">
                    ${(selectedOrder.total - selectedOrder.deliveryFee).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-gray-600">Delivery Fee</span>
                  <span className="font-medium text-gray-900">${selectedOrder.deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-base font-bold border-t pt-2">
                  <span className="text-gray-900">Total</span>
                  <span className="text-[#FF6600]">${selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isAssignDriverOpen} onOpenChange={setIsAssignDriverOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-600 flex items-center gap-2">
              <UserCheck className="w-6 h-6" />
              Assign Driver to Order
            </DialogTitle>
            <DialogDescription>Select an available driver to deliver {orderToAssign?.id}</DialogDescription>
          </DialogHeader>

          {availableDrivers.length === 0 ? (
            <div className="py-12 text-center">
              <UserCheck className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">No Available Drivers</h3>
              <p className="text-gray-500">All drivers are currently busy. Please try again later.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {availableDrivers.map((driver) => (
                <Card
                  key={driver.id}
                  className="hover:shadow-md transition-shadow cursor-pointer border-2 hover:border-purple-400"
                  onClick={() => handleConfirmDriverAssignment(driver.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <UserCheck className="w-5 h-5 text-purple-600" />
                          <h3 className="text-lg font-bold text-gray-900">{driver.name}</h3>
                          <Badge className="bg-green-100 text-green-800 border-green-300">Available</Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Phone className="w-4 h-4" />
                            <span>{driver.phone}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            {driver.vehicleType === "Bike" ? <Bike className="w-4 h-4" /> : <Car className="w-4 h-4" />}
                            <span>{driver.vehicleType}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600 col-span-2">
                            <Package className="w-4 h-4" />
                            <span>License Plate: {driver.licensePlate}</span>
                          </div>
                        </div>
                      </div>
                      <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                        <Check className="w-4 h-4 mr-2" />
                        Assign
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
