"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Store, ArrowLeft, Mail, Lock, UserIcon, Building, Phone, Globe, MapPin, Utensils } from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RestaurantLocationPicker } from "@/components/restaurant-location-picker"

export default function PartnerSignupPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    restaurantName: "",
    phone: "",
    website: "",
    address: "",
    latitude: 0,
    longitude: 0,
    cuisineType: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isLocationPickerOpen, setIsLocationPickerOpen] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    await new Promise((resolve) => setTimeout(resolve, 1000))

    const partnerData = {
      ...formData,
      isPartnerApproved: false,
      createdAt: new Date().toISOString(),
    }

    const requestId = Date.now()

    const pendingRequest = {
      id: requestId,
      ownerName: formData.name,
      email: formData.email,
      restaurantName: formData.restaurantName,
      phone: formData.phone,
      website: formData.website,
      address: formData.address,
      latitude: formData.latitude,
      longitude: formData.longitude,
      cuisineType: formData.cuisineType,
      createdAt: new Date().toISOString(),
    }

    localStorage.setItem(`pendingRestaurant_${requestId}`, JSON.stringify(pendingRequest))
    localStorage.setItem("partnerData", JSON.stringify(partnerData))

    console.log("[v0] Restaurant registration submitted:", pendingRequest)
    console.log("[v0] Request stored successfully with ID:", requestId)

    const verifyStorage = localStorage.getItem(`pendingRestaurant_${requestId}`)
    if (verifyStorage) {
      console.log("[v0] ✓ Verification successful: Request data stored correctly")
      router.push("/partner/login?registered=true")
    } else {
      console.error("[v0] ✗ Verification failed: Request data not stored")
      alert("Error: Failed to save registration. Please try again.")
      setIsSubmitting(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleCuisineChange = (value: string) => {
    setFormData({
      ...formData,
      cuisineType: value,
    })
  }

  const handleLocationConfirm = (address: string, lat: number, lng: number) => {
    setFormData({
      ...formData,
      address,
      latitude: lat,
      longitude: lng,
    })
  }

  const isFormValid =
    formData.name.trim() !== "" &&
    formData.email.trim() !== "" &&
    formData.password.length >= 6 &&
    formData.restaurantName.trim() !== "" &&
    formData.phone.trim() !== "" &&
    formData.address.trim() !== "" &&
    formData.cuisineType !== ""

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      <div className="container mx-auto px-4 py-8 max-w-md">
        <Link href="/" className="inline-flex items-center text-gray-600 hover:text-[#FF6600] mb-6">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <Card className="border-2 border-orange-100 shadow-xl">
          <CardHeader className="space-y-1 text-center pb-6">
            <div className="mx-auto w-16 h-16 bg-gradient-to-br from-[#FF6600] to-[#FF8533] rounded-2xl flex items-center justify-center mb-4 shadow-lg">
              <Store className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">Restaurant Partner Portal</CardTitle>
            <CardDescription className="text-base">
              Join Foodyo as a restaurant partner and grow your business
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-sm font-medium text-gray-700">
                  Full Name
                </Label>
                <div className="relative">
                  <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={handleChange}
                    className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium text-gray-700">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="partner@restaurant.com"
                    value={formData.email}
                    onChange={handleChange}
                    className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-sm font-medium text-gray-700">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="Minimum 6 characters"
                    value={formData.password}
                    onChange={handleChange}
                    className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                    required
                    minLength={6}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="restaurantName" className="text-sm font-medium text-gray-700">
                  Restaurant Name
                </Label>
                <div className="relative">
                  <Building className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="restaurantName"
                    name="restaurantName"
                    type="text"
                    placeholder="Your Restaurant Name"
                    value={formData.restaurantName}
                    onChange={handleChange}
                    className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone" className="text-sm font-medium text-gray-700">
                  Restaurant Phone Number
                </Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="phone"
                    name="phone"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={formData.phone}
                    onChange={handleChange}
                    className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="website" className="text-sm font-medium text-gray-700">
                  Restaurant Website <span className="text-gray-400 text-xs">(Optional)</span>
                </Label>
                <div className="relative">
                  <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    id="website"
                    name="website"
                    type="url"
                    placeholder="https://yourrestaurant.com"
                    value={formData.website}
                    onChange={handleChange}
                    className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address" className="text-sm font-medium text-gray-700">
                  Restaurant Location Address
                </Label>
                <button
                  type="button"
                  onClick={() => setIsLocationPickerOpen(true)}
                  className="w-full flex items-center gap-3 px-3 py-3 h-12 border-2 border-gray-300 rounded-lg hover:border-[#FF6600] hover:bg-orange-50 transition-colors text-left"
                >
                  <MapPin className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  <span className={formData.address ? "text-gray-900" : "text-gray-400"}>
                    {formData.address || "Tap to select location on map"}
                  </span>
                </button>
                {formData.latitude !== 0 && formData.longitude !== 0 && (
                  <p className="text-xs text-gray-500 mt-1">
                    Coordinates: {formData.latitude.toFixed(6)}, {formData.longitude.toFixed(6)}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="cuisineType" className="text-sm font-medium text-gray-700">
                  Cuisine Type
                </Label>
                <div className="relative">
                  <Utensils className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 z-10" />
                  <Select value={formData.cuisineType} onValueChange={handleCuisineChange}>
                    <SelectTrigger className="pl-10 h-12 border-gray-300 focus:border-[#FF6600] focus:ring-[#FF6600]">
                      <SelectValue placeholder="Select cuisine type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Fast Food">Fast Food</SelectItem>
                      <SelectItem value="Italian">Italian</SelectItem>
                      <SelectItem value="Arabic">Arabic</SelectItem>
                      <SelectItem value="Asian">Asian</SelectItem>
                      <SelectItem value="Desserts">Desserts</SelectItem>
                      <SelectItem value="Café">Café</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                type="submit"
                disabled={!isFormValid || isSubmitting}
                className="w-full h-12 bg-gradient-to-r from-[#FF6600] to-[#FF8533] hover:from-[#FF5500] hover:to-[#FF7722] text-white font-semibold shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "Creating Account..." : "Sign Up as Partner"}
              </Button>

              <div className="text-center pt-4">
                <p className="text-sm text-gray-600">
                  Already have an account?{" "}
                  <Link href="/partner/login" className="text-[#FF6600] hover:text-[#FF5500] font-medium">
                    Login here
                  </Link>
                </p>
              </div>
            </form>
          </CardContent>
        </Card>

        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800 text-center">
            <strong>Note:</strong> Your account will be reviewed by our team. You'll receive access to the Partner
            Dashboard once approved.
          </p>
        </div>
      </div>

      <RestaurantLocationPicker
        isOpen={isLocationPickerOpen}
        onClose={() => setIsLocationPickerOpen(false)}
        onConfirm={handleLocationConfirm}
      />
    </div>
  )
}
