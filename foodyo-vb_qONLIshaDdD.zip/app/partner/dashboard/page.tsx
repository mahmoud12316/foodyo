"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Store, UtensilsCrossed, LogOut, BarChart3, Settings, Package, Star } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export default function PartnerDashboardPage() {
  const router = useRouter()
  const [partnerData, setPartnerData] = useState<any>(null)
  const [restaurantRating, setRestaurantRating] = useState<number | null>(null)
  const [totalRatings, setTotalRatings] = useState<number>(0)
  const [isOpen, setIsOpen] = useState<boolean>(true)
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false)

  useEffect(() => {
    const authToken = localStorage.getItem("partnerAuthToken")
    const savedPartnerData = localStorage.getItem("partnerData")

    if (!authToken || !savedPartnerData) {
      router.push("/partner/login")
      return
    }

    const data = JSON.parse(savedPartnerData)
    if (!data.isPartnerApproved) {
      router.push("/partner/login")
      return
    }

    setPartnerData(data)

    setRestaurantRating(4.3)
    setTotalRatings(47)

    const savedIsOpen = localStorage.getItem(`restaurant_${data.restaurantId}_isOpen`)
    setIsOpen(savedIsOpen ? JSON.parse(savedIsOpen) : true)
  }, [router])

  const handleToggleStatus = async (checked: boolean) => {
    setIsUpdatingStatus(true)

    try {
      // await fetch(`/api/restaurants/${partnerData.restaurantId}/status`, {
      //   method: 'PATCH',
      //   headers: { 'Content-Type': 'application/json' },
      //   body: JSON.stringify({ isOpen: checked })
      // })

      localStorage.setItem(`restaurant_${partnerData.restaurantId}_isOpen`, JSON.stringify(checked))
      setIsOpen(checked)
    } catch (error) {
      console.error("Failed to update restaurant status:", error)
    } finally {
      setIsUpdatingStatus(false)
    }
  }

  const handleLogout = () => {
    localStorage.removeItem("partnerAuthToken")
    router.push("/partner/login")
  }

  if (!partnerData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4 max-w-6xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#FF6600] to-[#FF8533] rounded-xl flex items-center justify-center shadow-lg">
                <Store className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Partner Dashboard</h1>
                <p className="text-sm text-gray-600">{partnerData.restaurantName}</p>
              </div>
            </div>
            <Button variant="outline" onClick={handleLogout} className="gap-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome, {partnerData.name}!</h2>
          <p className="text-gray-600">Manage your restaurant and track your performance</p>
          {restaurantRating && (
            <div className="flex items-center gap-2 mt-3">
              <div className="flex items-center gap-1 bg-yellow-50 px-3 py-1.5 rounded-full border border-yellow-200">
                <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                <span className="text-lg font-bold text-gray-900">{restaurantRating.toFixed(1)}</span>
              </div>
              <span className="text-sm text-gray-600">Based on {totalRatings} customer ratings</span>
            </div>
          )}
        </div>

        {/* Restaurant Status Toggle */}
        <Card className="mb-8 border-2 border-[#FF6600] shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="text-xl flex items-center gap-2">
              <Store className="w-6 h-6 text-[#FF6600]" />
              Restaurant Status
            </CardTitle>
            <CardDescription>Control whether your restaurant is accepting new orders</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 bg-gradient-to-r from-orange-50 to-white rounded-lg">
              <div className="flex-1">
                <Label htmlFor="restaurant-status" className="text-lg font-semibold text-gray-900 cursor-pointer">
                  {isOpen ? "Currently Open" : "Currently Closed"}
                </Label>
                <p className="text-sm text-gray-600 mt-1">
                  {isOpen
                    ? "Your restaurant is visible and accepting orders from customers"
                    : "Your restaurant is marked as closed and not accepting new orders"}
                </p>
              </div>
              <Switch
                id="restaurant-status"
                checked={isOpen}
                onCheckedChange={handleToggleStatus}
                disabled={isUpdatingStatus}
                className="data-[state=checked]:bg-green-600 scale-125 ml-4"
              />
            </div>
            <div className="mt-4 flex items-center gap-2 text-sm">
              <div className={`w-3 h-3 rounded-full ${isOpen ? "bg-green-500 animate-pulse" : "bg-red-500"}`} />
              <span className={`font-medium ${isOpen ? "text-green-700" : "text-red-700"}`}>
                {isOpen ? "Accepting Orders" : "Not Accepting Orders"}
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-2 border-orange-100">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Orders</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-gray-900">0</p>
              <p className="text-sm text-gray-500 mt-1">No orders yet</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-orange-100">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-gray-900">$0</p>
              <p className="text-sm text-gray-500 mt-1">Start adding meals</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-orange-100">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-gray-600">Active Meals</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-gray-900">0</p>
              <p className="text-sm text-gray-500 mt-1">Add your first meal</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card
            className="border-2 border-orange-100 hover:border-[#FF6600] transition-colors cursor-pointer"
            onClick={() => router.push("/partner/orders")}
          >
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-3">
                <Package className="w-6 h-6 text-[#FF6600]" />
              </div>
              <CardTitle>Manage Orders</CardTitle>
              <CardDescription>View and update incoming order status in real-time</CardDescription>
            </CardHeader>
          </Card>

          <Card
            className="border-2 border-orange-100 hover:border-[#FF6600] transition-colors cursor-pointer"
            onClick={() => router.push("/partner/meals")}
          >
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-3">
                <UtensilsCrossed className="w-6 h-6 text-[#FF6600]" />
              </div>
              <CardTitle>Manage Meals</CardTitle>
              <CardDescription>Add, edit, or remove meals from your menu</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 border-gray-200 opacity-60 cursor-not-allowed">
            <CardHeader>
              <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
                <BarChart3 className="w-6 h-6 text-gray-400" />
              </div>
              <CardTitle className="text-gray-500">Analytics</CardTitle>
              <CardDescription>View detailed performance metrics (Coming Soon)</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-2 border-gray-200 opacity-60 cursor-not-allowed">
            <CardHeader>
              <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mb-3">
                <Settings className="w-6 h-6 text-gray-400" />
              </div>
              <CardTitle className="text-gray-500">Restaurant Settings</CardTitle>
              <CardDescription>Manage your restaurant information (Coming Soon)</CardDescription>
            </CardHeader>
          </Card>
        </div>
      </div>
    </div>
  )
}
