"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Store, Plus, ArrowLeft, UtensilsCrossed, Edit, Trash2, Circle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Meal {
  id: number
  mealName: string
  description: string
  price: number
  category: string
  imageUrl: string
  detailedIngredients: string
  availabilityStatus: "Available" | "Sold Out"
  addonIds?: number[]
}

interface Addon {
  id: number
  name: string
  price: number
}

export default function PartnerMealsPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [partnerData, setPartnerData] = useState<any>(null)
  const [meals, setMeals] = useState<Meal[]>([])
  const [addons, setAddons] = useState<Addon[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editingMeal, setEditingMeal] = useState<Meal | null>(null)
  const [isAddonsDialogOpen, setIsAddonsDialogOpen] = useState(false)
  const [addonFormData, setAddonFormData] = useState({ name: "", price: "" })
  const [editingAddon, setEditingAddon] = useState<Addon | null>(null)

  const [formData, setFormData] = useState({
    mealName: "",
    description: "",
    price: "",
    category: "",
    imageUrl: "",
    detailedIngredients: "",
    availabilityStatus: "Available" as "Available" | "Sold Out",
    addonIds: [] as number[],
  })

  useEffect(() => {
    const authToken = localStorage.getItem("partnerAuthToken")
    const savedPartnerData = localStorage.getItem("partnerData")

    if (!authToken || !savedPartnerData) {
      router.push("/partner/login")
      return
    }

    const data = JSON.parse(savedPartnerData)
    if (!data.isPartnerApproved) {
      router.push("/partner/login")
      return
    }

    setPartnerData(data)
    loadMeals(data.id)
    loadAddons(data.id)
  }, [router])

  const loadMeals = (partnerId: number) => {
    const savedMeals = localStorage.getItem(`partner_meals_${partnerId}`)
    if (savedMeals) {
      setMeals(JSON.parse(savedMeals))
    }
  }

  const loadAddons = (partnerId: number) => {
    const savedAddons = localStorage.getItem(`partner_addons_${partnerId}`)
    if (savedAddons) {
      setAddons(JSON.parse(savedAddons))
    }
  }

  const saveMeals = (updatedMeals: Meal[]) => {
    if (partnerData) {
      localStorage.setItem(`partner_meals_${partnerData.id}`, JSON.stringify(updatedMeals))
      setMeals(updatedMeals)
    }
  }

  const saveAddons = (updatedAddons: Addon[]) => {
    if (partnerData) {
      localStorage.setItem(`partner_addons_${partnerData.id}`, JSON.stringify(updatedAddons))
      setAddons(updatedAddons)
    }
  }

  const handleAddMeal = () => {
    if (!formData.mealName || !formData.price) {
      toast({
        title: "Missing Information",
        description: "Please fill in meal name and price",
        variant: "destructive",
      })
      return
    }

    const newMeal: Meal = {
      id: Date.now(),
      mealName: formData.mealName,
      description: formData.description,
      price: Number.parseFloat(formData.price),
      category: formData.category,
      imageUrl: formData.imageUrl,
      detailedIngredients: formData.detailedIngredients,
      availabilityStatus: formData.availabilityStatus,
      addonIds: formData.addonIds,
    }

    saveMeals([...meals, newMeal])
    resetForm()
    setIsAddDialogOpen(false)

    toast({
      title: "Meal Added",
      description: "Your meal has been added successfully",
    })
  }

  const handleEditMeal = () => {
    if (!editingMeal || !formData.mealName || !formData.price) {
      toast({
        title: "Missing Information",
        description: "Please fill in meal name and price",
        variant: "destructive",
      })
      return
    }

    const updatedMeals = meals.map((meal) =>
      meal.id === editingMeal.id
        ? {
            ...meal,
            mealName: formData.mealName,
            description: formData.description,
            price: Number.parseFloat(formData.price),
            category: formData.category,
            imageUrl: formData.imageUrl,
            detailedIngredients: formData.detailedIngredients,
            availabilityStatus: formData.availabilityStatus,
            addonIds: formData.addonIds,
          }
        : meal,
    )

    saveMeals(updatedMeals)
    resetForm()
    setIsEditDialogOpen(false)
    setEditingMeal(null)

    toast({
      title: "Meal Updated",
      description: "Your meal has been updated successfully",
    })
  }

  const handleAddAddon = () => {
    if (!addonFormData.name || !addonFormData.price) {
      toast({
        title: "Missing Information",
        description: "Please fill in add-on name and price",
        variant: "destructive",
      })
      return
    }

    if (editingAddon) {
      const updatedAddons = addons.map((addon) =>
        addon.id === editingAddon.id
          ? { ...addon, name: addonFormData.name, price: Number.parseFloat(addonFormData.price) }
          : addon,
      )
      saveAddons(updatedAddons)
      toast({ title: "Add-on Updated", description: "The add-on has been updated successfully" })
    } else {
      const newAddon: Addon = {
        id: Date.now(),
        name: addonFormData.name,
        price: Number.parseFloat(addonFormData.price),
      }
      saveAddons([...addons, newAddon])
      toast({ title: "Add-on Created", description: "The add-on has been created successfully" })
    }

    setAddonFormData({ name: "", price: "" })
    setEditingAddon(null)
  }

  const handleDeleteAddon = (addonId: number) => {
    const updatedAddons = addons.filter((addon) => addon.id !== addonId)
    saveAddons(updatedAddons)

    const updatedMeals = meals.map((meal) => ({
      ...meal,
      addonIds: meal.addonIds?.filter((id) => id !== addonId) || [],
    }))
    saveMeals(updatedMeals)

    toast({ title: "Add-on Deleted", description: "The add-on has been removed" })
  }

  const openEditAddonDialog = (addon: Addon) => {
    setEditingAddon(addon)
    setAddonFormData({ name: addon.name, price: addon.price.toString() })
  }

  const openEditDialog = (meal: Meal) => {
    setEditingMeal(meal)
    setFormData({
      mealName: meal.mealName,
      description: meal.description,
      price: meal.price.toString(),
      category: meal.category,
      imageUrl: meal.imageUrl,
      detailedIngredients: meal.detailedIngredients,
      availabilityStatus: meal.availabilityStatus,
      addonIds: meal.addonIds || [],
    })
    setIsEditDialogOpen(true)
  }

  const resetForm = () => {
    setFormData({
      mealName: "",
      description: "",
      price: "",
      category: "",
      imageUrl: "",
      detailedIngredients: "",
      availabilityStatus: "Available",
      addonIds: [],
    })
  }

  const handleDeleteMeal = (mealId: number) => {
    const updatedMeals = meals.filter((meal) => meal.id !== mealId)
    saveMeals(updatedMeals)
    toast({ title: "Meal Deleted", description: "The meal has been removed" })
  }

  if (!partnerData) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading...</p>
      </div>
    )
  }

  const toggleAddon = (addonId: number) => {
    setFormData((prev) => ({
      ...prev,
      addonIds: prev.addonIds.includes(addonId)
        ? prev.addonIds.filter((id) => id !== addonId)
        : [...prev.addonIds, addonId],
    }))
  }

  const MealForm = ({ isEdit = false }: { isEdit?: boolean }) => (
    <div className="space-y-4">
      <div>
        <Label htmlFor="mealName">Meal Name *</Label>
        <Input
          id="mealName"
          value={formData.mealName}
          onChange={(e) => setFormData({ ...formData, mealName: e.target.value })}
          placeholder="e.g., Margherita Pizza"
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Describe your meal..."
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="price">Price (JOD) *</Label>
        <Input
          id="price"
          type="number"
          step="0.01"
          value={formData.price}
          onChange={(e) => setFormData({ ...formData, price: e.target.value })}
          placeholder="0.00"
        />
      </div>

      <div>
        <Label htmlFor="category">Category</Label>
        <Input
          id="category"
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
          placeholder="e.g., Pizza, Burger, Salad"
        />
      </div>

      <div>
        <Label htmlFor="imageUrl">Image URL</Label>
        <Input
          id="imageUrl"
          value={formData.imageUrl}
          onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
          placeholder="https://example.com/image.jpg"
        />
      </div>

      <div>
        <Label htmlFor="detailedIngredients">Detailed Ingredients/Allergens</Label>
        <Textarea
          id="detailedIngredients"
          value={formData.detailedIngredients}
          onChange={(e) => setFormData({ ...formData, detailedIngredients: e.target.value })}
          placeholder="List all ingredients and potential allergens (e.g., Contains: Wheat, Milk, Eggs, Soy. May contain traces of nuts...)"
          rows={5}
          className="resize-y"
        />
        <p className="text-xs text-gray-500 mt-1">
          Include all ingredients and allergen information for customer safety and transparency
        </p>
      </div>

      <div>
        <Label htmlFor="availabilityStatus">Availability Status</Label>
        <Select
          value={formData.availabilityStatus}
          onValueChange={(value: "Available" | "Sold Out") => setFormData({ ...formData, availabilityStatus: value })}
        >
          <SelectTrigger id="availabilityStatus">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Available">
              <div className="flex items-center gap-2">
                <Circle className="w-3 h-3 fill-green-500 text-green-500" />
                Available
              </div>
            </SelectItem>
            <SelectItem value="Sold Out">
              <div className="flex items-center gap-2">
                <Circle className="w-3 h-3 fill-red-500 text-red-500" />
                Sold Out
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
        <p className="text-xs text-gray-500 mt-1">
          Real-time inventory status - update anytime to reflect current availability
        </p>
      </div>

      <div>
        <Label>Available Add-ons (Optional)</Label>
        <div className="border rounded-lg p-3 space-y-2 max-h-48 overflow-y-auto">
          {addons.length === 0 ? (
            <p className="text-sm text-gray-500">No add-ons created yet. Create add-ons to assign them to meals.</p>
          ) : (
            addons.map((addon) => (
              <label key={addon.id} className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded">
                <input
                  type="checkbox"
                  checked={formData.addonIds.includes(addon.id)}
                  onChange={() => toggleAddon(addon.id)}
                  className="w-4 h-4 text-[#FF6600] rounded"
                />
                <span className="flex-1 text-sm">{addon.name}</span>
                <span className="text-sm font-semibold text-[#FF6600]">+{addon.price.toFixed(2)} JOD</span>
              </label>
            ))
          )}
        </div>
        <p className="text-xs text-gray-500 mt-1">Select add-ons that customers can choose for this meal</p>
      </div>

      <div className="flex gap-2 pt-4">
        <Button
          onClick={isEdit ? handleEditMeal : handleAddMeal}
          className="flex-1 bg-gradient-to-r from-[#FF6600] to-[#FF8533] hover:from-[#FF5500] hover:to-[#FF7722]"
        >
          {isEdit ? "Update Meal" : "Add Meal"}
        </Button>
        <Button
          variant="outline"
          onClick={() => {
            resetForm()
            isEdit ? setIsEditDialogOpen(false) : setIsAddDialogOpen(false)
          }}
        >
          Cancel
        </Button>
      </div>
    </div>
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="container mx-auto px-4 py-4 max-w-6xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => router.push("/partner/dashboard")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="w-12 h-12 bg-gradient-to-br from-[#FF6600] to-[#FF8533] rounded-xl flex items-center justify-center shadow-lg">
                <Store className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Manage Meals</h1>
                <p className="text-sm text-gray-600">{partnerData.restaurantName}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setIsAddonsDialogOpen(true)}
                className="gap-2 border-[#FF6600] text-[#FF6600] hover:bg-orange-50"
              >
                <Plus className="w-4 h-4" />
                Manage Add-ons
              </Button>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-gradient-to-r from-[#FF6600] to-[#FF8533] hover:from-[#FF5500] hover:to-[#FF7722] gap-2">
                    <Plus className="w-4 h-4" />
                    Add Meal
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Meal</DialogTitle>
                    <DialogDescription>
                      Add a new meal to your menu. Fields marked with * are required.
                    </DialogDescription>
                  </DialogHeader>
                  <MealForm />
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {meals.length === 0 ? (
          <Card className="border-2 border-dashed border-gray-300">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                <UtensilsCrossed className="w-16 h-16 text-gray-400" />
              </div>
              <CardTitle className="text-xl text-gray-900 mb-2">No Meals Yet</CardTitle>
              <CardDescription className="text-center mb-6 max-w-md">
                Start building your menu by adding your first meal. Customers will be able to discover and order from
                your restaurant.
              </CardDescription>
              <Button
                onClick={() => setIsAddDialogOpen(true)}
                className="bg-gradient-to-r from-[#FF6600] to-[#FF8533] hover:from-[#FF5500] hover:to-[#FF7722] gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Your First Meal
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {meals.map((meal) => (
              <Card key={meal.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative h-48 bg-gray-200">
                  {meal.imageUrl ? (
                    <img
                      src={meal.imageUrl || "/placeholder.svg"}
                      alt={meal.mealName}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <UtensilsCrossed className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                  <div
                    className={`absolute top-2 right-2 px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 ${
                      meal.availabilityStatus === "Available" ? "bg-green-500 text-white" : "bg-red-500 text-white"
                    }`}
                  >
                    <Circle className="w-2 h-2 fill-current" />
                    {meal.availabilityStatus}
                  </div>
                </div>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{meal.mealName}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">{meal.category}</p>
                    </div>
                    <p className="text-lg font-bold text-[#FF6600]">{meal.price.toFixed(2)} JOD</p>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2">{meal.description}</p>
                  {meal.detailedIngredients && (
                    <div className="mb-4 p-2 bg-amber-50 border border-amber-200 rounded text-xs">
                      <p className="font-semibold text-amber-900 mb-1">Ingredients/Allergens:</p>
                      <p className="text-amber-800 line-clamp-2">{meal.detailedIngredients}</p>
                    </div>
                  )}
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => openEditDialog(meal)} className="flex-1">
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDeleteMeal(meal.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Add-ons Management Dialog */}
      <Dialog open={isAddonsDialogOpen} onOpenChange={setIsAddonsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Manage Add-ons</DialogTitle>
            <DialogDescription>Create and manage meal customization options with pricing</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="border rounded-lg p-4 bg-gray-50">
              <h3 className="font-semibold mb-3">{editingAddon ? "Edit Add-on" : "Create New Add-on"}</h3>
              <div className="space-y-3">
                <div>
                  <Label htmlFor="addonName">Add-on Name *</Label>
                  <Input
                    id="addonName"
                    value={addonFormData.name}
                    onChange={(e) => setAddonFormData({ ...addonFormData, name: e.target.value })}
                    placeholder="e.g., Extra Cheese, Avocado, Extra Sauce"
                  />
                </div>
                <div>
                  <Label htmlFor="addonPrice">Price (JOD) *</Label>
                  <Input
                    id="addonPrice"
                    type="number"
                    step="0.01"
                    value={addonFormData.price}
                    onChange={(e) => setAddonFormData({ ...addonFormData, price: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleAddAddon}
                    className="flex-1 bg-gradient-to-r from-[#FF6600] to-[#FF8533] hover:from-[#FF5500] hover:to-[#FF7722]"
                  >
                    {editingAddon ? "Update" : "Create"} Add-on
                  </Button>
                  {editingAddon && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setEditingAddon(null)
                        setAddonFormData({ name: "", price: "" })
                      }}
                    >
                      Cancel
                    </Button>
                  )}
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-semibold mb-3">Your Add-ons</h3>
              {addons.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-8">
                  No add-ons created yet. Create your first add-on above.
                </p>
              ) : (
                <div className="space-y-2">
                  {addons.map((addon) => (
                    <div key={addon.id} className="flex items-center justify-between border rounded-lg p-3">
                      <div>
                        <p className="font-medium">{addon.name}</p>
                        <p className="text-sm text-[#FF6600] font-semibold">+{addon.price.toFixed(2)} JOD</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" onClick={() => openEditAddonDialog(addon)}>
                          <Edit className="w-4 h-4 mr-1" />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteAddon(addon.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Meal</DialogTitle>
            <DialogDescription>Update your meal details. Fields marked with * are required.</DialogDescription>
          </DialogHeader>
          <MealForm isEdit />
        </DialogContent>
      </Dialog>
    </div>
  )
}
