"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Camera, ArrowLeft, MapPin, Plus, Edit, Trash2, Home, Briefcase } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { toast } from "sonner"
import dynamic from "next/dynamic"

const MapPicker = dynamic(() => import("@/components/map-picker"), { ssr: false })

interface SavedLocation {
  id: number
  nickname: string
  address: string
  latitude: number
  longitude: number
  isDefault: boolean
}

export default function ProfilePage() {
  const { isAuthenticated, isGuest, user, updateUser } = useAuth()
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
  })
  const [isSaving, setIsSaving] = useState(false)

  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>([])
  const [showAddressDialog, setShowAddressDialog] = useState(false)
  const [showMapPicker, setShowMapPicker] = useState(false)
  const [editingLocation, setEditingLocation] = useState<SavedLocation | null>(null)
  const [locationForm, setLocationForm] = useState({
    nickname: "",
    address: "",
    latitude: null as number | null,
    longitude: null as number | null,
    isDefault: false,
  })

  useEffect(() => {
    if (isGuest) {
      router.push("/login")
    } else if (user) {
      setFormData({
        name: user.name,
        email: user.email,
        phone: user.phone,
      })
      fetchSavedLocations()
    }
  }, [isGuest, user, router])

  const fetchSavedLocations = async () => {
    try {
      const response = await fetch("/api/saved-locations?userId=1")
      const data = await response.json()
      setSavedLocations(data.locations || [])
    } catch (error) {
      console.error("Error fetching saved locations:", error)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSaveChanges = async () => {
    setIsSaving(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    updateUser({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
    })

    setIsSaving(false)
    setIsEditing(false)
  }

  const handleCancel = () => {
    if (user) {
      setFormData({
        name: user.name,
        email: user.email,
        phone: user.phone,
      })
    }
    setIsEditing(false)
  }

  const handleAddAddress = () => {
    setEditingLocation(null)
    setLocationForm({
      nickname: "",
      address: "",
      latitude: null,
      longitude: null,
      isDefault: savedLocations.length === 0,
    })
    setShowAddressDialog(true)
  }

  const handleEditAddress = (location: SavedLocation) => {
    setEditingLocation(location)
    setLocationForm({
      nickname: location.nickname,
      address: location.address,
      latitude: location.latitude,
      longitude: location.longitude,
      isDefault: location.isDefault,
    })
    setShowAddressDialog(true)
  }

  const handleDeleteAddress = async (id: number) => {
    try {
      await fetch(`/api/saved-locations?id=${id}`, { method: "DELETE" })
      toast.success("Address deleted successfully")
      fetchSavedLocations()
    } catch (error) {
      toast.error("Failed to delete address")
    }
  }

  const handleSaveAddress = async () => {
    if (!locationForm.nickname || !locationForm.address) {
      toast.error("Please fill in all required fields")
      return
    }

    try {
      const method = editingLocation ? "PUT" : "POST"
      const body = editingLocation ? { id: editingLocation.id, ...locationForm } : { userId: 1, ...locationForm }

      await fetch("/api/saved-locations", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      })

      toast.success(editingLocation ? "Address updated successfully" : "Address added successfully")
      setShowAddressDialog(false)
      fetchSavedLocations()
    } catch (error) {
      toast.error("Failed to save address")
    }
  }

  const handleLocationSelected = (lat: number, lng: number, address: string) => {
    setLocationForm((prev) => ({
      ...prev,
      latitude: lat,
      longitude: lng,
      address: address,
    }))
    setShowMapPicker(false)
  }

  const getLocationIcon = (nickname: string) => {
    const lower = nickname.toLowerCase()
    if (lower.includes("home")) return <Home className="w-4 h-4" />
    if (lower.includes("work") || lower.includes("office")) return <Briefcase className="w-4 h-4" />
    return <MapPin className="w-4 h-4" />
  }

  if (!isAuthenticated || !user) {
    return null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="h-10 w-10">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-semibold text-gray-800">Profile</h1>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-6 pb-24">
        {/* Profile Picture Section */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center">
              <div className="relative">
                <Avatar className="h-24 w-24">
                  <AvatarImage src="/placeholder.svg?height=96&width=96" />
                  <AvatarFallback className="bg-orange-100 text-orange-600 text-3xl font-semibold">
                    {user.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <button className="absolute bottom-0 right-0 bg-orange-500 text-white rounded-full p-2 shadow-lg hover:bg-orange-600 transition-colors">
                  <Camera className="w-4 h-4" />
                </button>
              </div>
              <p className="mt-4 text-lg font-semibold text-gray-800">{user.name}</p>
              <p className="text-sm text-gray-500">{user.email}</p>
            </div>
          </CardContent>
        </Card>

        {/* Profile Information */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>Update your profile details</CardDescription>
              </div>
              {!isEditing && (
                <Button variant="outline" onClick={() => setIsEditing(true)}>
                  Edit
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleInputChange}
                disabled={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>

            {isEditing && (
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleSaveChanges}
                  disabled={isSaving}
                  className="flex-1 bg-orange-500 hover:bg-orange-600"
                >
                  {isSaving ? "Saving..." : "Save Changes"}
                </Button>
                <Button variant="outline" onClick={handleCancel} disabled={isSaving} className="flex-1 bg-transparent">
                  Cancel
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="mt-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Saved Addresses</CardTitle>
                <CardDescription>Manage your delivery locations</CardDescription>
              </div>
              <Button onClick={handleAddAddress} size="sm" className="bg-orange-500 hover:bg-orange-600">
                <Plus className="w-4 h-4 mr-2" />
                Add
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {savedLocations.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p>No saved addresses yet</p>
                <p className="text-sm mt-1">Add your first address to make checkout faster</p>
              </div>
            ) : (
              <div className="space-y-3">
                {savedLocations.map((location) => (
                  <div
                    key={location.id}
                    className="flex items-start gap-3 p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <div className="text-orange-500 mt-1">{getLocationIcon(location.nickname)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-gray-900">{location.nickname}</p>
                        {location.isDefault && (
                          <span className="px-2 py-0.5 bg-orange-100 text-orange-700 text-xs rounded-full">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{location.address}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditAddress(location)}
                        className="h-8 w-8"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteAddress(location.id)}
                        className="h-8 w-8 text-red-500 hover:text-red-600 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={showAddressDialog} onOpenChange={setShowAddressDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingLocation ? "Edit Address" : "Add New Address"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="nickname">Address Nickname *</Label>
              <Input
                id="nickname"
                placeholder="e.g., Home, Work, Office"
                value={locationForm.nickname}
                onChange={(e) => setLocationForm((prev) => ({ ...prev, nickname: e.target.value }))}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Location *</Label>
              <Button
                type="button"
                variant="outline"
                className="w-full justify-start text-left h-auto py-3 mt-1 bg-transparent"
                onClick={() => setShowMapPicker(true)}
              >
                <MapPin className="w-4 h-4 mr-2 flex-shrink-0 text-orange-500" />
                <span className="flex-1 truncate text-sm">
                  {locationForm.address || "Tap to select location on map"}
                </span>
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="isDefault"
                checked={locationForm.isDefault}
                onChange={(e) => setLocationForm((prev) => ({ ...prev, isDefault: e.target.checked }))}
                className="rounded border-gray-300"
              />
              <Label htmlFor="isDefault" className="cursor-pointer">
                Set as default address
              </Label>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setShowAddressDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveAddress} className="bg-orange-500 hover:bg-orange-600">
              {editingLocation ? "Update" : "Save"} Address
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={showMapPicker} onOpenChange={setShowMapPicker}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Select Location on Map</DialogTitle>
          </DialogHeader>
          <div className="h-[500px]">
            <MapPicker
              onLocationSelect={handleLocationSelected}
              initialLat={locationForm.latitude}
              initialLng={locationForm.longitude}
            />
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
