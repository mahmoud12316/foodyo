"use client"

import { ArrowLeft, MapPin, Star, Package, Clock, Truck, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { toast } from "sonner"

interface OrderItem {
  id: string
  name: string
  quantity: number
  price: number
  image: string
}

interface Order {
  id: string
  restaurantName: string
  mealName: string
  orderDate: string
  orderTime: string
  status: "Pending" | "Preparing" | "On the way" | "Delivered" | "Cancelled"
  totalAmount: number
  deliveryAddress: string
  items: OrderItem[]
}

export default function OrderDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const { isGuest } = useAuth()
  const [order, setOrder] = useState<Order | null>(null)
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [showTrackingMap, setShowTrackingMap] = useState(false)
  const [driverLocation, setDriverLocation] = useState({ lat: 40.758, lng: -73.9855 }) // Starting position (midway)

  useEffect(() => {
    if (isGuest) {
      router.push("/login")
      return
    }

    // Load order from localStorage
    const savedOrders = localStorage.getItem("userOrders")
    if (savedOrders) {
      const orders: Order[] = JSON.parse(savedOrders)
      const foundOrder = orders.find((o) => o.id === params.id)
      if (foundOrder) {
        setOrder(foundOrder)
      } else {
        router.push("/orders")
      }
    } else {
      router.push("/orders")
    }
  }, [isGuest, params.id, router])

  useEffect(() => {
    if (!showTrackingMap || order?.status !== "On the way") return

    const interval = setInterval(() => {
      setDriverLocation((prev) => {
        // Simulate movement towards destination (customer location)
        const restaurantLat = 40.7489
        const restaurantLng = -73.968
        const customerLat = 40.7614
        const customerLng = -73.9776

        // Move driver gradually from restaurant to customer
        const progress = Math.random() * 0.02 // Small random movement
        const newLat = prev.lat + (customerLat - prev.lat) * progress
        const newLng = prev.lng + (customerLng - prev.lng) * progress

        return { lat: newLat, lng: newLng }
      })
    }, 3000) // Update every 3 seconds

    return () => clearInterval(interval)
  }, [showTrackingMap, order?.status])

  const getStatusStep = (status: Order["status"]) => {
    switch (status) {
      case "Pending":
        return 1
      case "Preparing":
        return 2
      case "On the way":
        return 3
      case "Delivered":
        return 4
      default:
        return 0
    }
  }

  const handleRateOrder = () => {
    if (rating === 0) {
      toast.error("Please select a rating")
      return
    }
    toast.success(`Thank you for rating ${rating} stars!`)
    setShowRatingDialog(false)
    setRating(0)
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center">
        <div className="text-center">
          <Package className="w-16 h-16 text-[#FF6600] mx-auto mb-4" />
          <p className="text-gray-600">Loading order details...</p>
        </div>
      </div>
    )
  }

  const currentStep = getStatusStep(order.status)

  const restaurantLocation = { lat: 40.7489, lng: -73.968, name: order.restaurantName }
  const customerLocation = { lat: 40.7614, lng: -73.9776, name: "Your Location" }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-[#E0E0E0]">
        <div className="flex items-center gap-4 px-4 py-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/orders")} className="h-10 w-10">
            <ArrowLeft className="w-5 h-5 text-[#555555]" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800">Order Details</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Order Info Card */}
        <div className="bg-white rounded-2xl shadow-md p-6">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-gray-800 mb-1">{order.restaurantName}</h2>
              <p className="text-sm text-gray-600 mb-2">Order ID: {order.id}</p>
              <p className="text-sm text-gray-500">
                {order.orderDate} at {order.orderTime}
              </p>
            </div>
            <div className="text-right">
              <p className="text-3xl font-bold text-[#FF6600]">${order.totalAmount.toFixed(2)}</p>
            </div>
          </div>
        </div>

        {/* Order Status Tracking */}
        <div className="bg-white rounded-2xl shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-6">Order Status</h3>
          <div className="relative">
            {/* Progress Line */}
            <div className="absolute top-6 left-6 right-6 h-1 bg-gray-200">
              <div
                className="h-full bg-[#FF6600] transition-all duration-500"
                style={{ width: `${((currentStep - 1) / 3) * 100}%` }}
              />
            </div>

            {/* Status Steps */}
            <div className="relative flex justify-between">
              {/* Pending */}
              <div className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    currentStep >= 1 ? "bg-[#FF6600]" : "bg-gray-200"
                  }`}
                >
                  <Clock className={`w-6 h-6 ${currentStep >= 1 ? "text-white" : "text-gray-400"}`} />
                </div>
                <p className="text-xs mt-2 text-center font-medium">Pending</p>
              </div>

              {/* Preparing */}
              <div className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    currentStep >= 2 ? "bg-[#FF6600]" : "bg-gray-200"
                  }`}
                >
                  <Package className={`w-6 h-6 ${currentStep >= 2 ? "text-white" : "text-gray-400"}`} />
                </div>
                <p className="text-xs mt-2 text-center font-medium">Preparing</p>
              </div>

              {/* On the way */}
              <div className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    currentStep >= 3 ? "bg-[#FF6600]" : "bg-gray-200"
                  }`}
                >
                  <Truck className={`w-6 h-6 ${currentStep >= 3 ? "text-white" : "text-gray-400"}`} />
                </div>
                <p className="text-xs mt-2 text-center font-medium">On the way</p>
              </div>

              {/* Delivered */}
              <div className="flex flex-col items-center">
                <div
                  className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    currentStep >= 4 ? "bg-[#FF6600]" : "bg-gray-200"
                  }`}
                >
                  <CheckCircle className={`w-6 h-6 ${currentStep >= 4 ? "text-white" : "text-gray-400"}`} />
                </div>
                <p className="text-xs mt-2 text-center font-medium">Delivered</p>
              </div>
            </div>
          </div>

          {/* Track Order button when status is "On the way" */}
          {order.status === "On the way" && (
            <div className="mt-6">
              <Button
                onClick={() => setShowTrackingMap(!showTrackingMap)}
                className="w-full bg-[#FF6600] hover:bg-[#FF8533] text-white py-3 rounded-full shadow-md transition-all"
              >
                <Truck className="w-5 h-5 mr-2" />
                {showTrackingMap ? "Hide Map" : "Track Order"}
              </Button>
            </div>
          )}

          {showTrackingMap && order.status === "On the way" && (
            <div className="mt-6 bg-gray-50 rounded-xl p-4 border-2 border-[#FF6600]">
              <h4 className="text-md font-bold text-gray-800 mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-[#FF6600]" />
                Live Tracking
              </h4>

              {/* Map Container */}
              <div className="relative bg-white rounded-lg overflow-hidden" style={{ height: "400px" }}>
                {/* Map Background */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50">
                  {/* Grid lines to simulate map */}
                  <div className="absolute inset-0 opacity-10">
                    {[...Array(20)].map((_, i) => (
                      <div
                        key={`h-${i}`}
                        className="absolute w-full border-t border-gray-400"
                        style={{ top: `${i * 5}%` }}
                      />
                    ))}
                    {[...Array(20)].map((_, i) => (
                      <div
                        key={`v-${i}`}
                        className="absolute h-full border-l border-gray-400"
                        style={{ left: `${i * 5}%` }}
                      />
                    ))}
                  </div>

                  {/* Route Line */}
                  <svg className="absolute inset-0 w-full h-full">
                    <line
                      x1="20%"
                      y1="70%"
                      x2="80%"
                      y2="30%"
                      stroke="#FF6600"
                      strokeWidth="3"
                      strokeDasharray="10,5"
                      opacity="0.6"
                    />
                  </svg>

                  {/* Restaurant Marker */}
                  <div className="absolute" style={{ left: "20%", top: "70%", transform: "translate(-50%, -50%)" }}>
                    <div className="relative">
                      <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center shadow-lg border-4 border-white">
                        <span className="text-2xl">🍴</span>
                      </div>
                      <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                        <div className="bg-white px-3 py-1 rounded-full shadow-md text-xs font-semibold text-gray-700">
                          {restaurantLocation.name}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Driver Marker (Animated) */}
                  <div
                    className="absolute transition-all duration-3000 ease-linear"
                    style={{
                      left: `${20 + ((driverLocation.lat - restaurantLocation.lat) / (customerLocation.lat - restaurantLocation.lat)) * 60}%`,
                      top: `${70 - ((driverLocation.lat - restaurantLocation.lat) / (customerLocation.lat - restaurantLocation.lat)) * 40}%`,
                      transform: "translate(-50%, -50%)",
                    }}
                  >
                    <div className="relative">
                      {/* Pulse animation */}
                      <div className="absolute inset-0 w-12 h-12 bg-[#FF6600] rounded-full animate-ping opacity-30" />
                      <div className="relative w-12 h-12 bg-[#FF6600] rounded-full flex items-center justify-center shadow-lg border-4 border-white">
                        <span className="text-2xl">🛵</span>
                      </div>
                      <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                        <div className="bg-[#FF6600] text-white px-3 py-1 rounded-full shadow-md text-xs font-semibold">
                          Driver
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Customer Marker */}
                  <div className="absolute" style={{ left: "80%", top: "30%", transform: "translate(-50%, -50%)" }}>
                    <div className="relative">
                      <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center shadow-lg border-4 border-white">
                        <span className="text-2xl">🏠</span>
                      </div>
                      <div className="absolute top-full mt-2 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
                        <div className="bg-white px-3 py-1 rounded-full shadow-md text-xs font-semibold text-gray-700">
                          {customerLocation.name}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Map Info */}
              <div className="mt-4 grid grid-cols-3 gap-3 text-center">
                <div className="bg-white rounded-lg p-3 shadow-sm">
                  <div className="text-2xl mb-1">🍴</div>
                  <p className="text-xs font-semibold text-gray-700">Restaurant</p>
                </div>
                <div className="bg-white rounded-lg p-3 shadow-sm">
                  <div className="text-2xl mb-1">🛵</div>
                  <p className="text-xs font-semibold text-gray-700">Driver</p>
                </div>
                <div className="bg-white rounded-lg p-3 shadow-sm">
                  <div className="text-2xl mb-1">🏠</div>
                  <p className="text-xs font-semibold text-gray-700">Your Location</p>
                </div>
              </div>

              <p className="text-xs text-gray-500 text-center mt-3">
                Driver location updates automatically every few seconds
              </p>
            </div>
          )}

          {order.status === "Delivered" && (
            <div className="mt-6 bg-green-50 rounded-xl p-6 border-2 border-green-500 text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-3" />
              <h4 className="text-xl font-bold text-green-700 mb-2">Delivered Successfully ✅</h4>
              <p className="text-gray-600">Your order has been delivered. Enjoy your meal!</p>
            </div>
          )}
        </div>

        {/* Delivery Address */}
        <div className="bg-white rounded-2xl shadow-md p-6">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-[#FF6600] mt-1 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-bold text-gray-800 mb-2">Delivery Address</h3>
              <p className="text-gray-600">{order.deliveryAddress}</p>
            </div>
          </div>
        </div>

        {/* Order Items */}
        <div className="bg-white rounded-2xl shadow-md p-6">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Order Items</h3>
          <div className="space-y-4">
            {order.items.map((item) => (
              <div key={item.id} className="flex items-center gap-4 pb-4 border-b border-gray-100 last:border-0">
                <img
                  src={item.image || "/placeholder.svg"}
                  alt={item.name}
                  className="w-20 h-20 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-800">{item.name}</h4>
                  <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                </div>
                <p className="font-bold text-[#FF6600]">${(item.price * item.quantity).toFixed(2)}</p>
              </div>
            ))}
          </div>

          {/* Total */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <span className="text-lg font-bold text-gray-800">Total</span>
              <span className="text-2xl font-bold text-[#FF6600]">${order.totalAmount.toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Rate Order Button */}
        {order.status === "Delivered" && (
          <Button
            onClick={() => setShowRatingDialog(true)}
            className="w-full bg-[#FF6600] hover:bg-[#FF8533] text-white py-6 text-lg rounded-full shadow-lg"
          >
            <Star className="w-5 h-5 mr-2" />
            Rate Order
          </Button>
        )}
      </div>

      {/* Rating Dialog */}
      <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">Rate Your Order</DialogTitle>
          </DialogHeader>
          <div className="py-6">
            <p className="text-center text-gray-600 mb-6">How was your experience with {order.restaurantName}?</p>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-12 h-12 ${
                      star <= (hoverRating || rating) ? "fill-[#FF6600] text-[#FF6600]" : "text-gray-300"
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>
          <DialogFooter className="flex gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setShowRatingDialog(false)} className="flex-1 rounded-full">
              Cancel
            </Button>
            <Button onClick={handleRateOrder} className="flex-1 rounded-full bg-[#FF6600] hover:bg-[#FF8533]">
              Submit Rating
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
