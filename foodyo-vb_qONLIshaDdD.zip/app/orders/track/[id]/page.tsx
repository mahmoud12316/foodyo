"use client"

import { ArrowLeft, Phone, Clock, User, Navigation, CheckCircle, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter, useParams } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface OrderTracking {
  id: string
  restaurantName: string
  restaurantAddress: string
  restaurantCoords: { lat: number; lng: number }
  deliveryAddress: string
  deliveryCoords: { lat: number; lng: number }
  driverName: string | null
  driverPhone: string | null
  driverCoords: { lat: number; lng: number } | null
  status:
    | "New Order"
    | "Preparing"
    | "Ready for Pickup/Delivery"
    | "Assigned to Driver"
    | "Out for Delivery"
    | "Delivered"
  estimatedTime: string
}

// Sample tracking data
const sampleTrackingData: Record<string, OrderTracking> = {
  "ORD-2025-002": {
    id: "ORD-2025-002",
    restaurantName: "Pizza Heaven",
    restaurantAddress: "123 Restaurant St, New York, NY",
    restaurantCoords: { lat: 40.7589, lng: -73.9851 },
    deliveryAddress: "456 Oak Avenue, Brooklyn, NY 11201",
    deliveryCoords: { lat: 40.6892, lng: -73.9789 },
    driverName: "John Smith",
    driverPhone: "+1 (555) 123-4567",
    driverCoords: { lat: 40.7289, lng: -73.9789 },
    status: "Out for Delivery",
    estimatedTime: "15-20 minutes",
  },
  "ORD-2025-003": {
    id: "ORD-2025-003",
    restaurantName: "Sushi Master",
    restaurantAddress: "789 Sushi Lane, Manhattan, NY",
    restaurantCoords: { lat: 40.7614, lng: -73.9776 },
    deliveryAddress: "789 Park Place, Manhattan, NY 10022",
    deliveryCoords: { lat: 40.7614, lng: -73.9676 },
    driverName: null,
    driverPhone: null,
    driverCoords: null,
    status: "New Order",
    estimatedTime: "25-30 minutes",
  },
}

export default function TrackOrderPage() {
  const router = useRouter()
  const params = useParams()
  const { isGuest } = useAuth()
  const [tracking, setTracking] = useState<OrderTracking | null>(null)
  const [driverPosition, setDriverPosition] = useState({ lat: 0, lng: 0 })
  const [showRatingDialog, setShowRatingDialog] = useState(false)
  const [restaurantRating, setRestaurantRating] = useState(0)
  const [driverRating, setDriverRating] = useState(0)
  const [hasRated, setHasRated] = useState(false)
  const [ratingSubmitted, setRatingSubmitted] = useState(false)

  useEffect(() => {
    if (isGuest) {
      router.push("/login")
      return
    }

    const orderId = params.id as string
    const trackingData = sampleTrackingData[orderId]
    if (trackingData) {
      setTracking(trackingData)
      setDriverPosition(trackingData.driverCoords || { lat: 0, lng: 0 })

      if (trackingData.status === "Delivered" && !hasRated) {
        setShowRatingDialog(true)
      }

      if (trackingData.status === "Out for Delivery") {
        const interval = setInterval(() => {
          setDriverPosition((prev) => ({
            lat: prev.lat + (Math.random() - 0.5) * 0.001,
            lng: prev.lng + (Math.random() - 0.5) * 0.001,
          }))
        }, 3000)

        return () => clearInterval(interval)
      }
    }
  }, [isGuest, router, params.id, hasRated])

  const handleRefresh = () => {
    if (tracking) {
      setDriverPosition({
        lat: tracking.driverCoords?.lat + (Math.random() - 0.5) * 0.002 || 0,
        lng: tracking.driverCoords?.lng + (Math.random() - 0.5) * 0.002 || 0,
      })
    }
  }

  const handleSubmitRating = async () => {
    if (restaurantRating === 0 || driverRating === 0) {
      alert("Please provide both restaurant and driver ratings")
      return
    }

    try {
      const response = await fetch("/api/orders/rate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          orderId: params.id,
          restaurantRating,
          driverRating,
        }),
      })

      if (response.ok) {
        setHasRated(true)
        setRatingSubmitted(true)
        setShowRatingDialog(false)
      }
    } catch (error) {
      console.error("Failed to submit rating:", error)
      alert("Failed to submit rating. Please try again.")
    }
  }

  if (isGuest || !tracking) {
    return null
  }

  const restaurantPos = { x: 20, y: 30 }
  const customerPos = { x: 80, y: 70 }
  const driverPos = tracking.driverCoords
    ? {
        x:
          20 +
          ((tracking.driverCoords.lng - tracking.restaurantCoords.lng) /
            (tracking.deliveryCoords.lng - tracking.restaurantCoords.lng)) *
            60,
        y:
          30 +
          ((tracking.driverCoords.lat - tracking.restaurantCoords.lat) /
            (tracking.deliveryCoords.lat - tracking.restaurantCoords.lat)) *
            40,
      }
    : { x: 0, y: 0 }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      <div className="sticky top-0 z-10 bg-white border-b border-[#E0E0E0]">
        <div className="flex items-center gap-4 px-4 py-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="h-10 w-10">
            <ArrowLeft className="w-5 h-5 text-[#555555]" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800">Track My Order</h1>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="bg-white rounded-2xl shadow-md p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-500 mb-1">Order ID</p>
              <p className="text-lg font-bold text-gray-800">{tracking.id}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Driver</p>
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-[#FF6600]" />
                <p className="text-lg font-bold text-gray-800">{tracking.driverName || "Not Assigned"}</p>
              </div>
              {tracking.driverPhone && (
                <a href={`tel:${tracking.driverPhone}`} className="text-sm text-[#FF6600] flex items-center gap-1 mt-1">
                  <Phone className="w-3 h-3" />
                  {tracking.driverPhone}
                </a>
              )}
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Status</p>
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full ${
                    tracking.status === "Out for Delivery" || tracking.status === "Delivered"
                      ? "bg-orange-500"
                      : "bg-blue-500"
                  }`}
                />
                <p className="text-lg font-bold text-gray-800">{tracking.status}</p>
              </div>
            </div>
            <div>
              <p className="text-sm text-gray-500 mb-1">Estimated Time</p>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#FF6600]" />
                <p className="text-lg font-bold text-gray-800">{tracking.estimatedTime}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-md overflow-hidden mb-6">
          <div className="relative w-full h-[400px] bg-gradient-to-br from-gray-50 to-gray-100">
            <svg className="absolute inset-0 w-full h-full" style={{ zIndex: 1 }}>
              <line
                x1={`${restaurantPos.x}%`}
                y1={`${restaurantPos.y}%`}
                x2={`${customerPos.x}%`}
                y2={`${customerPos.y}%`}
                stroke="#FF6600"
                strokeWidth="3"
                strokeDasharray="10,5"
                opacity="0.5"
              />
            </svg>

            <div
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${restaurantPos.x}%`, top: `${restaurantPos.y}%`, zIndex: 2 }}
            >
              <div className="bg-red-500 text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg text-2xl">
                🍴
              </div>
              <div className="absolute top-14 left-1/2 transform -translate-x-1/2 bg-white px-3 py-1 rounded-lg shadow-md whitespace-nowrap">
                <p className="text-xs font-semibold text-gray-800">{tracking.restaurantName}</p>
                <p className="text-xs text-gray-500">{tracking.restaurantAddress}</p>
              </div>
            </div>

            <div
              className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-1000"
              style={{ left: `${driverPos.x}%`, top: `${driverPos.y}%`, zIndex: 3 }}
            >
              <div className="relative">
                <div className="absolute inset-0 bg-[#FF6600] rounded-full w-12 h-12 animate-ping opacity-75" />
                <div className="relative bg-[#FF6600] text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg text-2xl">
                  🛵
                </div>
              </div>
              <div className="absolute top-14 left-1/2 transform -translate-x-1/2 bg-white px-3 py-1 rounded-lg shadow-md whitespace-nowrap">
                <p className="text-xs font-semibold text-gray-800">{tracking.driverName || "Not Assigned"}</p>
                <p className="text-xs text-[#FF6600]">{tracking.status}</p>
              </div>
            </div>

            <div
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{ left: `${customerPos.x}%`, top: `${customerPos.y}%`, zIndex: 2 }}
            >
              <div className="bg-green-500 text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg text-2xl">
                🏠
              </div>
              <div className="absolute top-14 left-1/2 transform -translate-x-1/2 bg-white px-3 py-1 rounded-lg shadow-md whitespace-nowrap">
                <p className="text-xs font-semibold text-gray-800">Your Location</p>
                <p className="text-xs text-gray-500">{tracking.deliveryAddress}</p>
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-gray-200">
            <Button
              onClick={handleRefresh}
              variant="outline"
              className="w-full rounded-full border-[#FF6600] text-[#FF6600] hover:bg-orange-50 bg-transparent"
            >
              <Navigation className="w-4 h-4 mr-2" />
              Refresh Location
            </Button>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-md p-6">
          <h2 className="text-lg font-bold text-gray-800 mb-4">Order Status</h2>
          <div className="relative">
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200" />

            <div className="space-y-6">
              <div className="relative flex items-start gap-4">
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                    tracking.status === "New Order" ||
                    tracking.status === "Preparing" ||
                    tracking.status === "Ready for Pickup/Delivery" ||
                    tracking.status === "Assigned to Driver" ||
                    tracking.status === "Out for Delivery" ||
                    tracking.status === "Delivered"
                      ? "bg-[#FF6600] text-white"
                      : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <span className="text-xl">📝</span>
                </div>
                <div className="flex-1 pt-2">
                  <p className="font-semibold text-gray-800">New Order</p>
                  <p className="text-sm text-gray-500">Your order has been received</p>
                </div>
              </div>

              <div className="relative flex items-start gap-4">
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                    tracking.status === "Preparing" ||
                    tracking.status === "Ready for Pickup/Delivery" ||
                    tracking.status === "Assigned to Driver" ||
                    tracking.status === "Out for Delivery" ||
                    tracking.status === "Delivered"
                      ? "bg-[#FF6600] text-white"
                      : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <span className="text-xl">👨‍🍳</span>
                </div>
                <div className="flex-1 pt-2">
                  <p className="font-semibold text-gray-800">Preparing</p>
                  <p className="text-sm text-gray-500">Restaurant is preparing your order</p>
                </div>
              </div>

              <div className="relative flex items-start gap-4">
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                    tracking.status === "Ready for Pickup/Delivery" ||
                    tracking.status === "Assigned to Driver" ||
                    tracking.status === "Out for Delivery" ||
                    tracking.status === "Delivered"
                      ? "bg-[#FF6600] text-white"
                      : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <span className="text-xl">📦</span>
                </div>
                <div className="flex-1 pt-2">
                  <p className="font-semibold text-gray-800">Ready for Pickup</p>
                  <p className="text-sm text-gray-500">Order is ready and waiting for driver</p>
                </div>
              </div>

              <div className="relative flex items-start gap-4">
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                    tracking.status === "Assigned to Driver" ||
                    tracking.status === "Out for Delivery" ||
                    tracking.status === "Delivered"
                      ? "bg-[#FF6600] text-white"
                      : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <span className="text-xl">👤</span>
                </div>
                <div className="flex-1 pt-2">
                  <p className="font-semibold text-gray-800">Assigned to Driver</p>
                  <p className="text-sm text-gray-500">
                    {tracking.driverName ? `Driver ${tracking.driverName} assigned` : "Waiting for driver assignment"}
                  </p>
                </div>
              </div>

              <div className="relative flex items-start gap-4">
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                    tracking.status === "Out for Delivery" || tracking.status === "Delivered"
                      ? "bg-[#FF6600] text-white"
                      : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <span className="text-xl">🛵</span>
                </div>
                <div className="flex-1 pt-2">
                  <p className="font-semibold text-gray-800">Out for Delivery</p>
                  <p className="text-sm text-gray-500">Driver is heading to your location</p>
                </div>
              </div>

              <div className="relative flex items-start gap-4">
                <div
                  className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center ${
                    tracking.status === "Delivered" ? "bg-[#FF6600] text-white" : "bg-gray-200 text-gray-400"
                  }`}
                >
                  <span className="text-xl">✅</span>
                </div>
                <div className="flex-1 pt-2">
                  <p className="font-semibold text-gray-800">Delivered</p>
                  <p className="text-sm text-gray-500">
                    {tracking.status === "Delivered"
                      ? "Your order has been successfully delivered!"
                      : "Order will be delivered soon"}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {tracking.status === "Delivered" && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <div>
                  <p className="font-bold text-green-800">Order Delivered Successfully!</p>
                  <p className="text-sm text-green-600">Thank you for your order. Enjoy your meal!</p>
                </div>
              </div>
            </div>
          )}
        </div>

        <Dialog open={showRatingDialog} onOpenChange={setShowRatingDialog}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-gray-900">Rate Your Experience</DialogTitle>
              <DialogDescription>Help us improve by rating your delivery experience</DialogDescription>
            </DialogHeader>

            <div className="space-y-6 py-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Rate the Restaurant</label>
                <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRestaurantRating(star)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star
                        className={`w-10 h-10 ${
                          star <= restaurantRating ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"
                        }`}
                      />
                    </button>
                  ))}
                </div>
                {restaurantRating > 0 && (
                  <p className="text-center text-sm text-gray-600 mt-2">
                    {restaurantRating} {restaurantRating === 1 ? "star" : "stars"}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">Rate the Driver</label>
                <div className="flex justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setDriverRating(star)}
                      className="transition-transform hover:scale-110"
                    >
                      <Star
                        className={`w-10 h-10 ${
                          star <= driverRating ? "fill-yellow-400 text-yellow-400" : "fill-gray-200 text-gray-200"
                        }`}
                      />
                    </button>
                  ))}
                </div>
                {driverRating > 0 && (
                  <p className="text-center text-sm text-gray-600 mt-2">
                    {driverRating} {driverRating === 1 ? "star" : "stars"}
                  </p>
                )}
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setShowRatingDialog(false)} className="flex-1">
                Skip for Now
              </Button>
              <Button
                onClick={handleSubmitRating}
                disabled={restaurantRating === 0 || driverRating === 0}
                className="flex-1 bg-[#FF6600] hover:bg-[#E55A00]"
              >
                Submit Rating
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {ratingSubmitted && (
          <div className="fixed bottom-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg">
            <p className="font-semibold">Thank you for your feedback!</p>
          </div>
        )}
      </div>
    </div>
  )
}
