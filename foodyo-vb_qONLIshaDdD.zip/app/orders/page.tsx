"use client"

import { ArrowLeft, Package, Clock, CheckCircle, Truck, XCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { useEffect, useState } from "react"
import { useCart } from "@/lib/cart-context"
import { toast } from "react-toastify"

interface Order {
  id: string
  restaurantName: string
  mealName: string
  orderDate: string
  orderTime: string
  status:
    | "New Order"
    | "Preparing"
    | "Ready for Pickup/Delivery"
    | "Assigned to Driver"
    | "Out for Delivery"
    | "Delivered"
    | "Cancelled"
  totalAmount: number
  deliveryAddress: string
  items: Array<{
    id: string
    name: string
    quantity: number
    price: number
    image: string
  }>
}

// Sample orders data
const sampleOrders: Order[] = [
  {
    id: "ORD-2025-001",
    restaurantName: "Burger Palace",
    mealName: "Classic Cheeseburger Combo",
    orderDate: "2025-01-15",
    orderTime: "14:30",
    status: "Delivered",
    totalAmount: 24.99,
    deliveryAddress: "123 Main Street, Apt 4B, New York, NY 10001",
    items: [
      {
        id: "burger-1",
        name: "Classic Cheeseburger",
        quantity: 1,
        price: 12.99,
        image: "/placeholder.svg?height=80&width=80",
      },
      {
        id: "fries-1",
        name: "French Fries",
        quantity: 1,
        price: 4.99,
        image: "/placeholder.svg?height=80&width=80",
      },
      {
        id: "cola-1",
        name: "Coca Cola",
        quantity: 1,
        price: 2.99,
        image: "/placeholder.svg?height=80&width=80",
      },
    ],
  },
  {
    id: "ORD-2025-002",
    restaurantName: "Pizza Heaven",
    mealName: "Margherita Pizza",
    orderDate: "2025-01-16",
    orderTime: "19:15",
    status: "Out for Delivery",
    totalAmount: 18.5,
    deliveryAddress: "456 Oak Avenue, Brooklyn, NY 11201",
    items: [
      {
        id: "pizza-1",
        name: "Margherita Pizza (Large)",
        quantity: 1,
        price: 15.99,
        image: "/placeholder.svg?height=80&width=80",
      },
      {
        id: "garlic-1",
        name: "Garlic Bread",
        quantity: 1,
        price: 2.5,
        image: "/placeholder.svg?height=80&width=80",
      },
    ],
  },
  {
    id: "ORD-2025-003",
    restaurantName: "Sushi Master",
    mealName: "California Roll Set",
    orderDate: "2025-01-17",
    orderTime: "12:45",
    status: "Preparing",
    totalAmount: 32.0,
    deliveryAddress: "789 Park Place, Manhattan, NY 10022",
    items: [
      {
        id: "sushi-1",
        name: "California Roll",
        quantity: 2,
        price: 12.0,
        image: "/placeholder.svg?height=80&width=80",
      },
      {
        id: "miso-1",
        name: "Miso Soup",
        quantity: 1,
        price: 4.0,
        image: "/placeholder.svg?height=80&width=80",
      },
      {
        id: "tea-1",
        name: "Green Tea",
        quantity: 1,
        price: 4.0,
        image: "/placeholder.svg?height=80&width=80",
      },
    ],
  },
]

export default function OrdersPage() {
  const router = useRouter()
  const { isAuthenticated, isGuest } = useAuth()
  const { addToCart } = useCart()
  const [orders, setOrders] = useState<Order[]>([])

  useEffect(() => {
    if (isGuest) {
      router.push("/login")
      return
    }
    // Load orders from localStorage or use sample data
    const savedOrders = localStorage.getItem("userOrders")
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders))
    } else {
      setOrders(sampleOrders)
      localStorage.setItem("userOrders", JSON.stringify(sampleOrders))
    }
  }, [isGuest, router])

  const getStatusIcon = (status: Order["status"]) => {
    switch (status) {
      case "New Order":
        return <Clock className="w-5 h-5 text-yellow-500" />
      case "Preparing":
        return <Package className="w-5 h-5 text-blue-500" />
      case "Ready for Pickup/Delivery":
        return <CheckCircle className="w-5 h-5 text-purple-500" />
      case "Assigned to Driver":
        return <Truck className="w-5 h-5 text-indigo-500" />
      case "Out for Delivery":
        return <Truck className="w-5 h-5 text-orange-500" />
      case "Delivered":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "Cancelled":
        return <XCircle className="w-5 h-5 text-red-500" />
    }
  }

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "New Order":
        return "bg-yellow-50 text-yellow-700 border-yellow-200"
      case "Preparing":
        return "bg-blue-50 text-blue-700 border-blue-200"
      case "Ready for Pickup/Delivery":
        return "bg-purple-50 text-purple-700 border-purple-200"
      case "Assigned to Driver":
        return "bg-indigo-50 text-indigo-700 border-indigo-200"
      case "Out for Delivery":
        return "bg-orange-50 text-orange-700 border-orange-200"
      case "Delivered":
        return "bg-green-50 text-green-700 border-green-200"
      case "Cancelled":
        return "bg-red-50 text-red-700 border-red-200"
    }
  }

  const handleReorder = (order: Order) => {
    order.items.forEach((item) => {
      for (let i = 0; i < item.quantity; i++) {
        addToCart({
          id: item.id,
          name: item.name,
          restaurant: order.restaurantName,
          price: item.price,
          image: item.image,
        })
      }
    })
    toast.success(`${order.items.length} items added to cart!`)
    router.push("/cart")
  }

  const handleViewDetails = (order: Order) => {
    router.push(`/orders/${order.id}`)
  }

  if (isGuest) {
    return null
  }

  return (
    <div className="min-h-screen bg-[#FFF9F5]">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white border-b border-[#E0E0E0]">
        <div className="flex items-center gap-4 px-4 py-4">
          <Button variant="ghost" size="icon" onClick={() => router.push("/")} className="h-10 w-10">
            <ArrowLeft className="w-5 h-5 text-[#555555]" />
          </Button>
          <h1 className="text-2xl font-bold text-gray-800">My Orders</h1>
        </div>
      </div>

      {/* Orders List */}
      <div className="max-w-4xl mx-auto px-4 py-6">
        {orders.length === 0 ? (
          // Empty state
          <div className="flex flex-col items-center justify-center py-20 px-4">
            <div className="w-32 h-32 mb-6 rounded-full bg-orange-50 flex items-center justify-center">
              <Package className="w-16 h-16 text-[#FF6600]" />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2 text-center">No Orders Yet</h2>
            <p className="text-gray-600 mb-8 text-center max-w-md">
              You haven't placed any orders yet. Explore delicious meals and place your first order!
            </p>
            <Button
              onClick={() => router.push("/")}
              className="bg-[#FF6600] hover:bg-[#FF8533] text-white px-8 py-6 text-lg rounded-full shadow-lg"
            >
              Order Now
            </Button>
          </div>
        ) : (
          // Orders list
          <div className="space-y-4">
            {orders.map((order) => (
              <div
                key={order.id}
                className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-200 overflow-hidden"
              >
                <div className="p-5">
                  {/* Order header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-800 mb-1">{order.restaurantName}</h3>
                      <p className="text-sm text-gray-600 mb-2">{order.mealName}</p>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <span>Order ID: {order.id}</span>
                        <span>•</span>
                        <span>
                          {order.orderDate} at {order.orderTime}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-[#FF6600]">${order.totalAmount.toFixed(2)}</p>
                    </div>
                  </div>

                  {/* Order status */}
                  <div className="mb-4">
                    <div
                      className={`inline-flex items-center gap-2 px-4 py-2 rounded-full border ${getStatusColor(order.status)}`}
                    >
                      {getStatusIcon(order.status)}
                      <span className="text-sm font-semibold">{order.status}</span>
                    </div>
                  </div>

                  {/* Delivery Address */}
                  <div className="mb-4">
                    <p className="text-sm text-gray-600">Delivery Address: {order.deliveryAddress}</p>
                  </div>

                  {/* Order Items */}
                  <div className="mb-4">
                    <div className="grid grid-cols-1 gap-4">
                      {order.items.map((item) => (
                        <div key={item.id} className="flex items-center gap-4">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="w-16 h-16 object-cover"
                          />
                          <div>
                            <p className="text-sm font-bold text-gray-800">{item.name}</p>
                            <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                            <p className="text-sm text-gray-600">Price: ${item.price.toFixed(2)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex gap-3">
                    <Button
                      onClick={() => handleViewDetails(order)}
                      variant="outline"
                      className="flex-1 rounded-full border-[#FF6600] text-[#FF6600] hover:bg-orange-50"
                    >
                      View Details
                    </Button>
                    {(order.status === "Preparing" ||
                      order.status === "Ready for Pickup/Delivery" ||
                      order.status === "Assigned to Driver" ||
                      order.status === "Out for Delivery") && (
                      <Button
                        onClick={() => router.push(`/orders/track/${order.id}`)}
                        className="flex-1 rounded-full bg-[#FF6600] hover:bg-[#FF8533] text-white"
                      >
                        Track Order
                      </Button>
                    )}
                    {order.status === "Delivered" && (
                      <div className="flex-1 flex items-center justify-center gap-2 text-green-600">
                        <CheckCircle className="w-5 h-5" />
                        <span className="font-semibold">Delivered Successfully!</span>
                      </div>
                    )}
                    <Button
                      onClick={() => handleReorder(order)}
                      className="flex-1 rounded-full bg-[#FF6600] hover:bg-[#FF8533] text-white"
                    >
                      Reorder
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
