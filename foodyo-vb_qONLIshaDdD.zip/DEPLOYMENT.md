# Foodyo - Deployment Guide for Pi Network

This guide will help you deploy Foodyo to production and integrate it with Pi Network Testnet.

## Quick Start

### 1. Deploy to Vercel (5 minutes)

**Option A: Direct Upload**
1. Go to https://vercel.com
2. Sign up/login (free account, no credit card required)
3. Click "Add New..." → "Project"
4. Click "Import" tab
5. Drag and drop the Foodyo ZIP file (or browse to select it)
6. Configure:
   - Project Name: `foodyo` (or your choice)
   - Framework Preset: Next.js (auto-detected)
   - Root Directory: `./` (default)
7. Click "Deploy"
8. Wait 2-3 minutes
9. **Copy your production URL**: `https://foodyo-[random].vercel.app`

**Option B: GitHub Integration**
1. Create a GitHub repository
2. Push your code:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin [your-github-repo-url]
   git push -u origin main
   ```
3. Go to https://vercel.com
4. Click "Import Project"
5. Select your GitHub repository
6. Click "Deploy"
7. **Copy your production URL**

### 2. Configure Pi Developer Portal (3 minutes)

1. Go to https://developers.pi.network
2. Login with your Pi Network account
3. Navigate to your app dashboard
4. Click on "Foodyo" app (or create new app)
5. Go to **Settings** or **Configuration**
6. Find the **"Production URL"** or **"App URL"** field
7. Paste your Vercel URL: `https://foodyo-[random].vercel.app`
8. Set **Network**: Select **"Pi Testnet"**
9. Click **"Save"** or **"Update"**
10. Wait 2-5 minutes for changes to propagate

### 3. Test in Pi Browser (2 minutes)

1. Open **Pi Browser** app on your mobile device
2. Go to **Pi Utilities** → **Your Apps**
3. Find and tap **"Foodyo"**
4. The app should load your production URL
5. Wait for "Pi Network Ready" green checkmark
6. Tap **"Sign in with Pi Network"**
7. Approve the authentication request
8. You should be logged in and see the home screen

## Detailed Configuration

### Environment Variables

Foodyo does not require environment variables for basic Pi authentication. The app automatically:
- Detects sandbox mode based on hostname
- Initializes Pi SDK with appropriate settings
- Handles authentication and user sessions

### Custom Domain (Optional)

To use a custom domain like `foodyo.com`:

1. In Vercel dashboard, go to your project
2. Click "Settings" → "Domains"
3. Add your custom domain
4. Follow DNS configuration instructions
5. Update Pi Developer Portal with new domain

### Pi Network Configuration

**Required Settings in Pi Developer Portal:**
- **App Name**: Foodyo
- **Production URL**: Your Vercel URL
- **Network**: Pi Testnet
- **Permissions**: Username, Payments

**Optional Settings:**
- **Development URL**: `http://localhost:3000` (for local testing)
- **Logo**: Upload Foodyo logo
- **Description**: "Fast and easy food delivery app"

### Sandbox Testing (Development)

To test locally with Pi SDK:

1. Add development URL in Pi Developer Portal:
   ```
   http://localhost:3000
   ```

2. Run the app locally:
   ```bash
   npm install
   npm run dev
   ```

3. Authorize sandbox in Pi Browser:
   - Open Pi Mining App
   - Go to "Pi Utilities"
   - Tap "Authorize Sandbox"
   - Enter the code from your browser
   - Click "Continue"

4. Open `http://localhost:3000` in your browser
5. Test Pi authentication

## Troubleshooting

### Pi SDK Not Loading

**Symptoms**: Button stays inactive, shows "Initializing..." forever

**Solutions**:
1. Check browser console for errors
2. Verify you're in Pi Browser (not regular browser)
3. Check Pi Developer Portal URL is correct
4. Wait 5 minutes after saving Portal settings
5. Try clearing browser cache
6. Re-authorize sandbox mode

### Authentication Fails

**Symptoms**: "Pi SDK is not available" error

**Solutions**:
1. Confirm app is opened through Pi Browser
2. Verify Network is set to "Pi Testnet" in Portal
3. Check production URL matches exactly
4. Ensure Pi account is verified
5. Try logging out and back into Pi Browser

### Images Not Showing

**Symptoms**: Placeholder or broken images

**Solutions**:
1. Check `/public/images/` folder exists in deployment
2. Verify Next.js image optimization is disabled (already configured)
3. Check browser network tab for 404 errors
4. Re-deploy to Vercel

### Deployment Build Fails

**Symptoms**: Vercel build error

**Solutions**:
1. Check `package.json` has all dependencies
2. Verify `next.config.mjs` is present
3. Ensure TypeScript errors are ignored (already configured)
4. Check build logs in Vercel dashboard
5. Try local build: `npm run build`

## Production Checklist

Before going live:

- [ ] App deploys successfully to Vercel
- [ ] Production URL added to Pi Developer Portal
- [ ] Network set to "Pi Testnet"
- [ ] App opens in Pi Browser
- [ ] Pi SDK initializes (green checkmark appears)
- [ ] "Sign in with Pi Network" works
- [ ] User can browse restaurants
- [ ] Cart functionality works
- [ ] All images load correctly
- [ ] Mobile responsive design works
- [ ] No console errors in Pi Browser

## Mainnet Migration

When ready to move to Mainnet:

1. Complete all Testnet testing
2. Complete Pi Developer Portal checklist
3. Apply for Mainnet approval
4. Update Network setting to "Pi Mainnet"
5. Test thoroughly on Mainnet
6. Claim `foodyo.pi` domain

## Support

- **Pi Network Documentation**: https://pi-apps.github.io/community-developer-guide/
- **Vercel Documentation**: https://vercel.com/docs
- **Pi Developer Portal**: https://developers.pi.network
- **Pi Community**: https://pinetwork.com

---

**Deployment Time**: ~10 minutes total
**Cost**: $0 (Vercel free tier)
**Requirements**: Pi Network account, verified email

Good luck with your deployment! 🚀
