"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { toast } from "sonner"

export interface CartItem {
  id: string
  name: string
  restaurant: string
  price: number
  image: string
  quantity: number
  addons?: Array<{ id: number; name: string; price: number }>
}

export interface FavoriteItem {
  id: string
  name: string
  restaurant: string
  price: number | undefined // Keep as required number, but handle undefined in UI
  image: string
  description: string
}

interface CartContextType {
  items: CartItem[]
  itemCount: number
  favorites: FavoriteItem[]
  addToCart: (item: Omit<CartItem, "quantity">) => void
  removeFromCart: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  addToFavorites: (item: FavoriteItem) => void
  removeFromFavorites: (id: string) => void
  isFavorite: (id: string) => boolean
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [favorites, setFavorites] = useState<FavoriteItem[]>([])

  useEffect(() => {
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      setItems(JSON.parse(savedCart))
    }
    const savedFavorites = localStorage.getItem("favorites")
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(items))
  }, [items])

  useEffect(() => {
    localStorage.setItem("favorites", JSON.stringify(favorites))
  }, [favorites])

  const addToCart = (item: Omit<CartItem, "quantity">) => {
    setItems((prevItems) => {
      const baseId = item.id.split("-addons-")[0]
      const existingItem = prevItems.find((i) => i.id === item.id)

      if (existingItem) {
        toast.success(`Added another ${item.name} to cart!`)
        return prevItems.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i))
      }
      toast.success(`${item.name} added to cart!`)
      return [...prevItems, { ...item, quantity: 1 }]
    })
  }

  const removeFromCart = (id: string) => {
    setItems((prevItems) => prevItems.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity < 1) {
      removeFromCart(id)
      return
    }
    setItems((prevItems) => prevItems.map((item) => (item.id === id ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setItems([])
    localStorage.removeItem("cart")
  }

  const addToFavorites = (item: FavoriteItem) => {
    setFavorites((prevFavorites) => {
      const existingFavorite = prevFavorites.find((f) => f.id === item.id)
      if (existingFavorite) {
        toast.info(`${item.name} is already in favorites!`)
        return prevFavorites
      }
      toast.success(`${item.name} added to favorites!`, {
        icon: "❤️",
      })
      return [...prevFavorites, item]
    })
  }

  const removeFromFavorites = (id: string) => {
    setFavorites((prevFavorites) => {
      const item = prevFavorites.find((f) => f.id === id)
      if (item) {
        toast.success(`${item.name} removed from favorites`)
      }
      return prevFavorites.filter((favorite) => favorite.id !== id)
    })
  }

  const isFavorite = (id: string) => {
    return favorites.some((f) => f.id === id)
  }

  const itemCount = items.reduce((total, item) => total + item.quantity, 0)

  return (
    <CartContext.Provider
      value={{
        items,
        itemCount,
        favorites,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        addToFavorites,
        removeFromFavorites,
        isFavorite,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
