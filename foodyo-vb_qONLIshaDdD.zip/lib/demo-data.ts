export type Restaurant = {
  id: number
  name: string
  category: string
  image: string
  description: string
  rating: number
  deliveryTime: string
  address: string
  isOpen: boolean
  status: "pending" | "approved" | "rejected"
  phone: string
  website: string
  cuisineType: string
  createdAt: string
}

export type Meal = {
  id: number
  restaurantId: number
  name: string
  description: string
  price: number
  image: string
  category: string
  availabilityStatus: "available" | "sold_out"
  detailedIngredients?: string
}

const DEFAULT_IMAGE = "https://i.imgur.com/3d2fY8P.jpeg"

const DEMO_RESTAURANTS: Restaurant[] = [
  {
    id: 1,
    name: "Pizza Palace",
    category: "Pizza",
    image: "/images/restaurants/pizza-palace.jpg", // Using local generated image
    description: "Authentic Italian pizzas with fresh ingredients and wood-fired oven",
    rating: 4.8,
    deliveryTime: "20-30 min",
    address: "123 Main St, Downtown",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 123-4567",
    website: "www.pizzapalace.com",
    cuisineType: "Italian",
    createdAt: new Date().toISOString(),
  },
  {
    id: 2,
    name: "Burger Kingdom",
    category: "Burgers",
    image: "/images/restaurants/burger-kingdom.jpg", // Using local generated image
    description: "Juicy gourmet burgers made with premium Angus beef",
    rating: 4.7,
    deliveryTime: "25-35 min",
    address: "456 Park Avenue",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 234-5678",
    website: "www.burgerkingdom.com",
    cuisineType: "American",
    createdAt: new Date().toISOString(),
  },
  {
    id: 3,
    name: "Shawarma Express",
    category: "Shawarma",
    image: "/images/restaurants/shawarma-express.jpg", // Using local generated image
    description: "Traditional Middle Eastern shawarma with authentic spices",
    rating: 4.9,
    deliveryTime: "15-25 min",
    address: "789 East Street",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 345-6789",
    website: "www.shawarmaexpress.com",
    cuisineType: "Arabic",
    createdAt: new Date().toISOString(),
  },
  {
    id: 4,
    name: "Crispy Chicken House",
    category: "Fried Chicken",
    image: "/images/restaurants/crispy-chicken.jpg", // Using local generated image
    description: "Crispy fried chicken with secret blend of 11 herbs and spices",
    rating: 4.6,
    deliveryTime: "20-30 min",
    address: "321 South Boulevard",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 456-7890",
    website: "www.crispychicken.com",
    cuisineType: "American",
    createdAt: new Date().toISOString(),
  },
  {
    id: 5,
    name: "BBQ Masters",
    category: "BBQ",
    image: "/images/restaurants/bbq-masters.jpg", // Using local generated image
    description: "Slow-smoked BBQ meats with house-made sauces",
    rating: 4.8,
    deliveryTime: "30-40 min",
    address: "654 West End Road",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 567-8901",
    website: "www.bbqmasters.com",
    cuisineType: "American",
    createdAt: new Date().toISOString(),
  },
  {
    id: 6,
    name: "Sweet Dreams Desserts",
    category: "Desserts",
    image: "/images/restaurants/sweet-dreams.jpg", // Using local generated image
    description: "Handcrafted desserts, cakes, and pastries made fresh daily",
    rating: 4.9,
    deliveryTime: "25-35 min",
    address: "987 Sugar Lane",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 678-9012",
    website: "www.sweetdreamsdesserts.com",
    cuisineType: "Desserts",
    createdAt: new Date().toISOString(),
  },
  {
    id: 7,
    name: "Cafe Mocha",
    category: "Coffee Shop",
    image: "/images/restaurants/cafe-mocha.jpg", // Using local generated image
    description: "Premium coffee, fresh pastries, and cozy atmosphere",
    rating: 4.7,
    deliveryTime: "15-20 min",
    address: "159 Coffee Street",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 789-0123",
    website: "www.cafemocha.com",
    cuisineType: "Café",
    createdAt: new Date().toISOString(),
  },
  {
    id: 8,
    name: "Ocean Breeze Seafood",
    category: "Seafood",
    image: "/images/restaurants/ocean-breeze.jpg", // Using local generated image
    description: "Fresh seafood delivered daily from the coast",
    rating: 4.8,
    deliveryTime: "35-45 min",
    address: "753 Harbor View",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 890-1234",
    website: "www.oceanbreezeseafood.com",
    cuisineType: "Seafood",
    createdAt: new Date().toISOString(),
  },
  {
    id: 9,
    name: "Green Life Kitchen",
    category: "Healthy Food",
    image: "/images/restaurants/green-life.jpg", // Using local generated image
    description: "Organic, nutritious meals for a healthy lifestyle",
    rating: 4.9,
    deliveryTime: "20-30 min",
    address: "357 Wellness Avenue",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 901-2345",
    website: "www.greenlifekitchen.com",
    cuisineType: "Healthy",
    createdAt: new Date().toISOString(),
  },
  {
    id: 10,
    name: "Heritage Traditional Meals",
    category: "Traditional Meals",
    image: "/images/restaurants/heritage-meals.jpg", // Using local generated image
    description: "Authentic home-style cooking with traditional recipes",
    rating: 4.8,
    deliveryTime: "25-35 min",
    address: "258 Heritage Road",
    isOpen: true,
    status: "approved",
    phone: "+1 (555) 012-3456",
    website: "www.heritagemeals.com",
    cuisineType: "Traditional",
    createdAt: new Date().toISOString(),
  },
]

const DEMO_MEALS: Meal[] = [
  // Pizza Palace (Restaurant 1)
  {
    id: 1,
    restaurantId: 1,
    name: "Margherita Pizza",
    description: "Fresh mozzarella, tomato sauce, and basil",
    price: 12.99,
    image: "/images/meals/margherita-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
    detailedIngredients: "Tomato sauce, mozzarella, fresh basil, olive oil",
  },
  {
    id: 2,
    restaurantId: 1,
    name: "Pepperoni Deluxe",
    description: "Double pepperoni with extra cheese",
    price: 15.99,
    image: "/images/meals/pepperoni-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 3,
    restaurantId: 1,
    name: "Quattro Formaggi",
    description: "Four cheese blend with truffle oil",
    price: 17.99,
    image: "/images/meals/quattro-formaggi.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 4,
    restaurantId: 1,
    name: "BBQ Chicken Pizza",
    description: "Grilled chicken with BBQ sauce and onions",
    price: 16.99,
    image: "/images/meals/bbq-chicken-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 5,
    restaurantId: 1,
    name: "Vegetarian Supreme",
    description: "Fresh vegetables with mozzarella",
    price: 14.99,
    image: "/images/meals/vegetarian-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 6,
    restaurantId: 1,
    name: "Hawaiian Paradise",
    description: "Ham and pineapple classic combination",
    price: 14.99,
    image: "/images/meals/hawaiian-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 7,
    restaurantId: 1,
    name: "Meat Lovers",
    description: "Loaded with pepperoni, sausage, and bacon",
    price: 18.99,
    image: "/images/meals/meat-lovers-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 8,
    restaurantId: 1,
    name: "Spicy Italian",
    description: "Hot salami, jalapeños, and chili flakes",
    price: 16.99,
    image: "/images/meals/spicy-italian-pizza.jpg", // Using local generated image
    category: "Pizza",
    availabilityStatus: "available",
  },
  {
    id: 9,
    restaurantId: 1,
    name: "Garlic Bread Sticks",
    description: "Freshly baked with garlic butter",
    price: 5.99,
    image: "/images/meals/garlic-bread.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 10,
    restaurantId: 1,
    name: "Caesar Salad",
    description: "Crispy romaine with parmesan and croutons",
    price: 8.99,
    image: "/images/meals/caesar-salad.jpg", // Using local generated image
    category: "Salads",
    availabilityStatus: "available",
  },

  // Burger Kingdom (Restaurant 2)
  {
    id: 11,
    restaurantId: 2,
    name: "Classic Beef Burger",
    description: "100% Angus beef patty with lettuce, tomato, pickles",
    price: 11.99,
    image: "/images/meals/beef-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 12,
    restaurantId: 2,
    name: "Cheese Burger",
    description: "Classic burger with melted cheddar cheese",
    price: 12.99,
    image: "/images/meals/cheese-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 13,
    restaurantId: 2,
    name: "Double Bacon Burger",
    description: "Double patty with crispy bacon and BBQ sauce",
    price: 15.99,
    image: "/images/meals/bacon-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 14,
    restaurantId: 2,
    name: "Mushroom Swiss Burger",
    description: "Sautéed mushrooms with Swiss cheese",
    price: 14.99,
    image: "/images/meals/mushroom-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 15,
    restaurantId: 2,
    name: "Spicy Jalapeño Burger",
    description: "Jalapeños, pepper jack cheese, and spicy mayo",
    price: 13.99,
    image: "/images/meals/jalapeno-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 16,
    restaurantId: 2,
    name: "Veggie Burger",
    description: "Plant-based patty with fresh vegetables",
    price: 12.99,
    image: "/images/meals/veggie-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 17,
    restaurantId: 2,
    name: "Chicken Burger",
    description: "Crispy fried chicken breast with mayo",
    price: 11.99,
    image: "/images/meals/chicken-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 18,
    restaurantId: 2,
    name: "Fish Burger",
    description: "Breaded fish fillet with tartar sauce",
    price: 12.99,
    image: "/images/meals/fish-burger.jpg", // Using local generated image
    category: "Burgers",
    availabilityStatus: "available",
  },
  {
    id: 19,
    restaurantId: 2,
    name: "French Fries",
    description: "Crispy golden fries with sea salt",
    price: 4.99,
    image: "/images/meals/french-fries.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 20,
    restaurantId: 2,
    name: "Onion Rings",
    description: "Crispy battered onion rings",
    price: 5.99,
    image: "/images/meals/onion-rings.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },

  // Shawarma Express (Restaurant 3)
  {
    id: 21,
    restaurantId: 3,
    name: "Chicken Shawarma Wrap",
    description: "Marinated chicken with garlic sauce and pickles",
    price: 9.99,
    image: "/images/meals/chicken-shawarma.jpg", // Using local generated image
    category: "Shawarma",
    availabilityStatus: "available",
  },
  {
    id: 22,
    restaurantId: 3,
    name: "Beef Shawarma Plate",
    description: "Tender beef with rice, salad, and tahini",
    price: 13.99,
    image: "/images/meals/beef-shawarma.jpg", // Using local generated image
    category: "Shawarma",
    availabilityStatus: "available",
  },
  {
    id: 23,
    restaurantId: 3,
    name: "Mixed Shawarma",
    description: "Chicken and beef combo with all sides",
    price: 15.99,
    image: "/images/meals/mixed-shawarma.jpg", // Using local generated image
    category: "Shawarma",
    availabilityStatus: "available",
  },
  {
    id: 24,
    restaurantId: 3,
    name: "Falafel Wrap",
    description: "Crispy falafel with hummus and vegetables",
    price: 8.99,
    image: "/images/meals/falafel-wrap.jpg", // Using local generated image
    category: "Vegetarian",
    availabilityStatus: "available",
  },
  {
    id: 25,
    restaurantId: 3,
    name: "Hummus Bowl",
    description: "Creamy hummus with olive oil and pita bread",
    price: 7.99,
    image: "/images/meals/hummus-bowl.jpg", // Using local generated image
    category: "Appetizers",
    availabilityStatus: "available",
  },
  {
    id: 26,
    restaurantId: 3,
    name: "Tabbouleh Salad",
    description: "Fresh parsley salad with bulgur and lemon",
    price: 6.99,
    image: "/images/meals/tabbouleh.jpg", // Using local generated image
    category: "Salads",
    availabilityStatus: "available",
  },
  {
    id: 27,
    restaurantId: 3,
    name: "Lamb Kebab",
    description: "Grilled lamb skewers with spices",
    price: 16.99,
    image: "/images/meals/lamb-kebab.jpg", // Using local generated image
    category: "Grills",
    availabilityStatus: "available",
  },
  {
    id: 28,
    restaurantId: 3,
    name: "Chicken Kebab",
    description: "Marinated chicken skewers",
    price: 14.99,
    image: "/images/meals/chicken-kebab.jpg", // Using local generated image
    category: "Grills",
    availabilityStatus: "available",
  },
  {
    id: 29,
    restaurantId: 3,
    name: "Baklava",
    description: "Sweet pastry with honey and nuts",
    price: 5.99,
    image: "/images/meals/baklava.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 30,
    restaurantId: 3,
    name: "Arabic Coffee",
    description: "Traditional cardamom-infused coffee",
    price: 3.99,
    image: "/images/meals/arabic-coffee.jpg", // Using local generated image
    category: "Beverages",
    availabilityStatus: "available",
  },

  // Crispy Chicken House (Restaurant 4)
  {
    id: 31,
    restaurantId: 4,
    name: "Original Fried Chicken",
    description: "Classic crispy fried chicken pieces",
    price: 10.99,
    image: "/images/meals/fried-chicken.jpg", // Using local generated image
    category: "Chicken",
    availabilityStatus: "available",
  },
  {
    id: 32,
    restaurantId: 4,
    name: "Spicy Hot Wings",
    description: "Extra spicy buffalo wings",
    price: 11.99,
    image: "/images/meals/hot-wings.jpg", // Using local generated image
    category: "Chicken",
    availabilityStatus: "available",
  },
  {
    id: 33,
    restaurantId: 4,
    name: "Chicken Tenders",
    description: "Tender chicken strips with dipping sauce",
    price: 9.99,
    image: "/images/meals/chicken-tenders.jpg", // Using local generated image
    category: "Chicken",
    availabilityStatus: "available",
  },
  {
    id: 34,
    restaurantId: 4,
    name: "Family Bucket",
    description: "12 pieces of mixed fried chicken",
    price: 25.99,
    image: "/images/meals/chicken-bucket.jpg", // Using local generated image
    category: "Chicken",
    availabilityStatus: "available",
  },
  {
    id: 35,
    restaurantId: 4,
    name: "Chicken Sandwich",
    description: "Crispy chicken with lettuce and mayo",
    price: 8.99,
    image: "/images/meals/chicken-sandwich.jpg", // Using local generated image
    category: "Sandwiches",
    availabilityStatus: "available",
  },
  {
    id: 36,
    restaurantId: 4,
    name: "Coleslaw",
    description: "Fresh cabbage slaw with creamy dressing",
    price: 3.99,
    image: "/images/meals/coleslaw.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 37,
    restaurantId: 4,
    name: "Mashed Potatoes",
    description: "Creamy mashed potatoes with gravy",
    price: 4.99,
    image: "/images/meals/mashed-potatoes.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 38,
    restaurantId: 4,
    name: "Corn on the Cob",
    description: "Buttered sweet corn",
    price: 3.99,
    image: "/images/meals/corn-on-cob.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 39,
    restaurantId: 4,
    name: "Biscuits",
    description: "Warm buttery biscuits",
    price: 2.99,
    image: "/images/meals/biscuits.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 40,
    restaurantId: 4,
    name: "Apple Pie",
    description: "Classic apple pie with cinnamon",
    price: 4.99,
    image: "/images/meals/apple-pie.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },

  // BBQ Masters (Restaurant 5)
  {
    id: 41,
    restaurantId: 5,
    name: "Smoked Brisket",
    description: "Slow-smoked Texas-style brisket",
    price: 18.99,
    image: "/images/meals/smoked-brisket.jpg", // Using local generated image
    category: "BBQ",
    availabilityStatus: "available",
  },
  {
    id: 42,
    restaurantId: 5,
    name: "BBQ Ribs",
    description: "Fall-off-the-bone pork ribs",
    price: 21.99,
    image: "/images/meals/bbq-ribs.jpg", // Using local generated image
    category: "BBQ",
    availabilityStatus: "available",
  },
  {
    id: 43,
    restaurantId: 5,
    name: "Pulled Pork Sandwich",
    description: "Tender pulled pork with BBQ sauce",
    price: 12.99,
    image: "/images/meals/pulled-pork.jpg", // Using local generated image
    category: "BBQ",
    availabilityStatus: "available",
  },
  {
    id: 44,
    restaurantId: 5,
    name: "BBQ Chicken",
    description: "Half chicken with smoky BBQ glaze",
    price: 15.99,
    image: "/images/meals/bbq-chicken.jpg", // Using local generated image
    category: "BBQ",
    availabilityStatus: "available",
  },
  {
    id: 45,
    restaurantId: 5,
    name: "Smoked Sausage",
    description: "House-made smoked sausage links",
    price: 10.99,
    image: "/images/meals/smoked-sausage.jpg", // Using local generated image
    category: "BBQ",
    availabilityStatus: "available",
  },
  {
    id: 46,
    restaurantId: 5,
    name: "Mac and Cheese",
    description: "Creamy smoked cheese macaroni",
    price: 6.99,
    image: "/images/meals/mac-cheese.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 47,
    restaurantId: 5,
    name: "Baked Beans",
    description: "Sweet and smoky baked beans",
    price: 5.99,
    image: "/images/meals/baked-beans.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 48,
    restaurantId: 5,
    name: "Potato Salad",
    description: "Classic creamy potato salad",
    price: 5.99,
    image: "/images/meals/potato-salad.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 49,
    restaurantId: 5,
    name: "Cornbread",
    description: "Sweet and moist cornbread",
    price: 3.99,
    image: "/images/meals/cornbread.jpg", // Using local generated image
    category: "Sides",
    availabilityStatus: "available",
  },
  {
    id: 50,
    restaurantId: 5,
    name: "Pecan Pie",
    description: "Southern-style pecan pie",
    price: 6.99,
    image: "/images/meals/pecan-pie.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },

  // Sweet Dreams Desserts (Restaurant 6)
  {
    id: 51,
    restaurantId: 6,
    name: "Chocolate Cake",
    description: "Rich chocolate layer cake",
    price: 8.99,
    image: "/images/meals/chocolate-cake.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 52,
    restaurantId: 6,
    name: "Red Velvet Cake",
    description: "Classic red velvet with cream cheese frosting",
    price: 9.99,
    image: "/images/meals/red-velvet-cake.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 53,
    restaurantId: 6,
    name: "Cheesecake",
    description: "New York style cheesecake",
    price: 10.99,
    image: "/images/meals/cheesecake.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 54,
    restaurantId: 6,
    name: "Tiramisu",
    description: "Classic Italian tiramisu",
    price: 9.99,
    image: "/images/meals/tiramisu.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 55,
    restaurantId: 6,
    name: "French Macarons",
    description: "Assorted colorful macarons",
    price: 12.99,
    image: "/images/meals/macarons.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 56,
    restaurantId: 6,
    name: "Brownies",
    description: "Fudgy chocolate brownies",
    price: 6.99,
    image: "/images/meals/brownies.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 57,
    restaurantId: 6,
    name: "Cupcakes",
    description: "Assorted decorated cupcakes",
    price: 7.99,
    image: "/images/meals/cupcakes.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 58,
    restaurantId: 6,
    name: "Crème Brûlée",
    description: "Classic French custard with caramelized sugar",
    price: 8.99,
    image: "/images/meals/creme-brulee.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 59,
    restaurantId: 6,
    name: "Chocolate Mousse",
    description: "Light and airy chocolate mousse",
    price: 7.99,
    image: "/images/meals/chocolate-mousse.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
  {
    id: 60,
    restaurantId: 6,
    name: "Fruit Tart",
    description: "Fresh fruit tart with custard",
    price: 9.99,
    image: "/images/meals/fruit-tart.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },

  // Cafe Mocha (Restaurant 7)
  {
    id: 61,
    restaurantId: 7,
    name: "Espresso",
    description: "Double shot espresso",
    price: 3.99,
    image: "/images/meals/espresso.jpg", // Using local generated image
    category: "Coffee",
    availabilityStatus: "available",
  },
  {
    id: 62,
    restaurantId: 7,
    name: "Cappuccino",
    description: "Espresso with steamed milk and foam",
    price: 4.99,
    image: "/images/meals/cappuccino.jpg", // Using local generated image
    category: "Coffee",
    availabilityStatus: "available",
  },
  {
    id: 63,
    restaurantId: 7,
    name: "Latte",
    description: "Smooth espresso with steamed milk",
    price: 5.99,
    image: "/images/meals/latte.jpg", // Using local generated image
    category: "Coffee",
    availabilityStatus: "available",
  },
  {
    id: 64,
    restaurantId: 7,
    name: "Americano",
    description: "Espresso with hot water",
    price: 3.99,
    image: "/images/meals/americano.jpg", // Using local generated image
    category: "Coffee",
    availabilityStatus: "available",
  },
  {
    id: 65,
    restaurantId: 7,
    name: "Mocha",
    description: "Espresso with chocolate and steamed milk",
    price: 5.99,
    image: "/images/meals/mocha.jpg", // Using local generated image
    category: "Coffee",
    availabilityStatus: "available",
  },
  {
    id: 66,
    restaurantId: 7,
    name: "Iced Coffee",
    description: "Cold brew with ice and cream",
    price: 4.99,
    image: "/images/meals/iced-coffee.jpg", // Using local generated image
    category: "Coffee",
    availabilityStatus: "available",
  },
  {
    id: 67,
    restaurantId: 7,
    name: "Croissant",
    description: "Buttery French croissant",
    price: 3.99,
    image: "/images/meals/croissant.jpg", // Using local generated image
    category: "Pastries",
    availabilityStatus: "available",
  },
  {
    id: 68,
    restaurantId: 7,
    name: "Blueberry Muffin",
    description: "Fresh baked blueberry muffin",
    price: 4.99,
    image: "/images/meals/muffin.jpg", // Using local generated image
    category: "Pastries",
    availabilityStatus: "available",
  },
  {
    id: 69,
    restaurantId: 7,
    name: "Cinnamon Roll",
    description: "Warm cinnamon roll with icing",
    price: 5.99,
    image: "/images/meals/cinnamon-roll.jpg", // Using local generated image
    category: "Pastries",
    availabilityStatus: "available",
  },
  {
    id: 70,
    restaurantId: 7,
    name: "Avocado Toast",
    description: "Smashed avocado on sourdough with poached egg",
    price: 8.99,
    image: "/images/meals/avocado-toast.jpg", // Using local generated image
    category: "Breakfast",
    availabilityStatus: "available",
  },

  // Ocean Breeze Seafood (Restaurant 8)
  {
    id: 71,
    restaurantId: 8,
    name: "Grilled Salmon",
    description: "Fresh Atlantic salmon fillet",
    price: 19.99,
    image: "/images/meals/grilled-salmon.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 72,
    restaurantId: 8,
    name: "Fish and Chips",
    description: "Crispy battered fish with fries",
    price: 15.99,
    image: "/images/meals/fish-chips.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 73,
    restaurantId: 8,
    name: "Shrimp Scampi",
    description: "Garlic butter shrimp with pasta",
    price: 17.99,
    image: "/images/meals/shrimp-scampi.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 74,
    restaurantId: 8,
    name: "Lobster Roll",
    description: "Fresh lobster meat in a toasted bun",
    price: 24.99,
    image: "/images/meals/lobster-roll.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 75,
    restaurantId: 8,
    name: "Crab Cakes",
    description: "Maryland-style crab cakes",
    price: 18.99,
    image: "/images/meals/crab-cakes.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 76,
    restaurantId: 8,
    name: "Clam Chowder",
    description: "Creamy New England clam chowder",
    price: 9.99,
    image: "/images/meals/clam-chowder.jpg", // Using local generated image
    category: "Soups",
    availabilityStatus: "available",
  },
  {
    id: 77,
    restaurantId: 8,
    name: "Tuna Poke Bowl",
    description: "Fresh tuna with rice and vegetables",
    price: 16.99,
    image: "/images/meals/tuna-poke.jpg", // Using local generated image
    category: "Bowls",
    availabilityStatus: "available",
  },
  {
    id: 78,
    restaurantId: 8,
    name: "Grilled Octopus",
    description: "Tender grilled octopus with lemon",
    price: 22.99,
    image: "/images/meals/grilled-octopus.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 79,
    restaurantId: 8,
    name: "Seafood Platter",
    description: "Mixed seafood platter for sharing",
    price: 45.99,
    image: "/images/meals/seafood-platter.jpg", // Using local generated image
    category: "Seafood",
    availabilityStatus: "available",
  },
  {
    id: 80,
    restaurantId: 8,
    name: "Fresh Oysters",
    description: "Half dozen fresh oysters on ice",
    price: 18.99,
    image: "/images/meals/oysters.jpg", // Using local generated image
    category: "Appetizers",
    availabilityStatus: "available",
  },

  // Green Life Kitchen (Restaurant 9)
  {
    id: 81,
    restaurantId: 9,
    name: "Quinoa Power Bowl",
    description: "Quinoa with roasted vegetables and tahini",
    price: 12.99,
    image: "/images/meals/quinoa-bowl.jpg", // Using local generated image
    category: "Bowls",
    availabilityStatus: "available",
  },
  {
    id: 82,
    restaurantId: 9,
    name: "Acai Bowl",
    description: "Acai smoothie bowl with berries and granola",
    price: 11.99,
    image: "/images/meals/acai-bowl.jpg", // Using local generated image
    category: "Bowls",
    availabilityStatus: "available",
  },
  {
    id: 83,
    restaurantId: 9,
    name: "Green Smoothie",
    description: "Spinach, banana, and mango smoothie",
    price: 7.99,
    image: "/images/meals/green-smoothie.jpg", // Using local generated image
    category: "Smoothies",
    availabilityStatus: "available",
  },
  {
    id: 84,
    restaurantId: 9,
    name: "Protein Bowl",
    description: "Grilled chicken with brown rice and vegetables",
    price: 14.99,
    image: "/images/meals/protein-bowl.jpg", // Using local generated image
    category: "Bowls",
    availabilityStatus: "available",
  },
  {
    id: 85,
    restaurantId: 9,
    name: "Kale Salad",
    description: "Fresh kale with cranberries and almonds",
    price: 10.99,
    image: "/images/meals/kale-salad.jpg", // Using local generated image
    category: "Salads",
    availabilityStatus: "available",
  },
  {
    id: 86,
    restaurantId: 9,
    name: "Buddha Bowl",
    description: "Chickpeas, avocado, and hummus bowl",
    price: 13.99,
    image: "/images/meals/buddha-bowl.jpg", // Using local generated image
    category: "Bowls",
    availabilityStatus: "available",
  },
  {
    id: 87,
    restaurantId: 9,
    name: "Vegetable Stir Fry",
    description: "Mixed vegetables with tofu",
    price: 11.99,
    image: "/images/meals/vegetable-stir-fry.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 88,
    restaurantId: 9,
    name: "Grilled Chicken Salad",
    description: "Grilled chicken with mixed greens",
    price: 13.99,
    image: "/images/meals/grilled-chicken-salad.jpg", // Using local generated image
    category: "Salads",
    availabilityStatus: "available",
  },
  {
    id: 89,
    restaurantId: 9,
    name: "Sweet Potato Bowl",
    description: "Roasted sweet potato with black beans",
    price: 10.99,
    image: "/images/meals/sweet-potato.jpg", // Using local generated image
    category: "Bowls",
    availabilityStatus: "available",
  },
  {
    id: 90,
    restaurantId: 9,
    name: "Energy Bars",
    description: "House-made energy bars with nuts and dates",
    price: 5.99,
    image: "/images/meals/energy-bar.jpg", // Using local generated image
    category: "Snacks",
    availabilityStatus: "available",
  },

  // Heritage Traditional Meals (Restaurant 10)
  {
    id: 91,
    restaurantId: 10,
    name: "Pot Roast",
    description: "Slow-cooked pot roast with vegetables",
    price: 16.99,
    image: "/images/meals/pot-roast.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 92,
    restaurantId: 10,
    name: "Meatloaf",
    description: "Classic meatloaf with mashed potatoes",
    price: 14.99,
    image: "/images/meals/meatloaf.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 93,
    restaurantId: 10,
    name: "Fried Catfish",
    description: "Southern fried catfish with hush puppies",
    price: 15.99,
    image: "/images/meals/fried-catfish.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 94,
    restaurantId: 10,
    name: "Chicken Pot Pie",
    description: "Homemade chicken pot pie with flaky crust",
    price: 13.99,
    image: "/images/meals/chicken-pot-pie.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 95,
    restaurantId: 10,
    name: "Beef Stew",
    description: "Hearty beef stew with vegetables",
    price: 12.99,
    image: "/images/meals/beef-stew.jpg", // Using local generated image
    category: "Soups",
    availabilityStatus: "available",
  },
  {
    id: 96,
    restaurantId: 10,
    name: "Lasagna",
    description: "Homemade lasagna with meat sauce",
    price: 14.99,
    image: "/images/meals/lasagna.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 97,
    restaurantId: 10,
    name: "Shepherd's Pie",
    description: "Ground beef with mashed potato topping",
    price: 13.99,
    image: "/images/meals/shepherds-pie.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 98,
    restaurantId: 10,
    name: "Stuffed Peppers",
    description: "Bell peppers stuffed with rice and meat",
    price: 12.99,
    image: "/images/meals/stuffed-peppers.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 99,
    restaurantId: 10,
    name: "Country Fried Steak",
    description: "Breaded steak with country gravy",
    price: 15.99,
    image: "/images/meals/country-fried-steak.jpg", // Using local generated image
    category: "Main Courses",
    availabilityStatus: "available",
  },
  {
    id: 100,
    restaurantId: 10,
    name: "Apple Cobbler",
    description: "Warm apple cobbler with vanilla ice cream",
    price: 7.99,
    image: "/images/meals/apple-cobbler.jpg", // Using local generated image
    category: "Desserts",
    availabilityStatus: "available",
  },
]

export function initializeDemoData() {
  const existingRestaurants = localStorage.getItem("restaurants")

  // Force update demo data to include new images
  console.log("[v0] Initializing demo restaurants data with Unsplash images")
  localStorage.setItem("restaurants", JSON.stringify(DEMO_RESTAURANTS))
  localStorage.setItem("meals", JSON.stringify(DEMO_MEALS))
  console.log("[v0] Demo data initialized: 10 restaurants, 100 meals with images")
}

// Get all restaurants
export function getAllRestaurants(): Restaurant[] {
  const data = localStorage.getItem("restaurants")
  return data ? JSON.parse(data) : []
}

// Get restaurant by ID
export function getRestaurantById(id: number): Restaurant | null {
  const restaurants = getAllRestaurants()
  return restaurants.find((r) => r.id === id) || null
}

// Get meals for a restaurant
export function getMealsByRestaurantId(restaurantId: number): Meal[] {
  const data = localStorage.getItem("meals")
  const allMeals: Meal[] = data ? JSON.parse(data) : []
  return allMeals.filter((m) => m.restaurantId === restaurantId)
}

// Get all meals
export function getAllMeals(): Meal[] {
  const data = localStorage.getItem("meals")
  return data ? JSON.parse(data) : []
}

// Update restaurant
export function updateRestaurant(id: number, updates: Partial<Restaurant>): boolean {
  const restaurants = getAllRestaurants()
  const index = restaurants.findIndex((r) => r.id === id)

  if (index === -1) return false

  restaurants[index] = { ...restaurants[index], ...updates }
  localStorage.setItem("restaurants", JSON.stringify(restaurants))
  console.log("[v0] Restaurant updated:", id)
  return true
}

// Delete restaurant
export function deleteRestaurant(id: number): boolean {
  const restaurants = getAllRestaurants()
  const filtered = restaurants.filter((r) => r.id !== id)

  if (filtered.length === restaurants.length) return false

  localStorage.setItem("restaurants", JSON.stringify(filtered))

  // Also delete meals
  const meals = getAllMeals()
  const filteredMeals = meals.filter((m) => m.restaurantId !== id)
  localStorage.setItem("meals", JSON.stringify(filteredMeals))

  console.log("[v0] Restaurant deleted:", id)
  return true
}

// Update meal
export function updateMeal(id: number, updates: Partial<Meal>): boolean {
  const meals = getAllMeals()
  const index = meals.findIndex((m) => m.id === id)

  if (index === -1) return false

  meals[index] = { ...meals[index], ...updates }
  localStorage.setItem("meals", JSON.stringify(meals))
  console.log("[v0] Meal updated:", id)
  return true
}
