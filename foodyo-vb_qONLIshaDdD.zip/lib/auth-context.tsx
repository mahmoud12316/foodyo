"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { PiAuthResult } from "./pi-sdk"

interface User {
  name: string
  email: string
  phone: string
  avatar?: string
  role?: "user" | "admin"
  piUid?: string
  piUsername?: string
}

interface Settings {
  language: "en" | "ar"
  theme: "light" | "dark"
  notifications: boolean
}

interface AuthContextType {
  isAuthenticated: boolean
  isGuest: boolean
  isAdmin: boolean
  userName: string | null
  user: User | null
  settings: Settings
  login: (name: string, role?: "user" | "admin") => void
  logout: () => void
  updateUser: (user: User) => void
  updateSettings: (settings: Settings) => void
  requireAuth: () => boolean
  loginWithPi: (username: string, piAuth: PiAuthResult) => void
  isPiUser: boolean
}

const defaultSettings: Settings = {
  language: "en",
  theme: "light",
  notifications: true,
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [userName, setUserName] = useState<string | null>(null)
  const [user, setUser] = useState<User | null>(null)
  const [settings, setSettings] = useState<Settings>(defaultSettings)
  const [isGuestMode, setIsGuestMode] = useState(false)
  const [isPiUser, setIsPiUser] = useState(false)

  useEffect(() => {
    // Check if user has an active session
    const authToken = localStorage.getItem("authToken")
    const savedUserData = localStorage.getItem("userData")
    const savedSettings = localStorage.getItem("userSettings")
    const guestMode = localStorage.getItem("isGuestMode")
    const piAuth = localStorage.getItem("pi_auth")

    if (guestMode === "true") {
      setIsGuestMode(true)
      setIsAuthenticated(false)
    } else if (authToken && savedUserData) {
      const userData = JSON.parse(savedUserData)
      setIsAuthenticated(true)
      setUserName(userData.name)
      setUser(userData)
      setIsAdmin(userData.role === "admin")
      setIsGuestMode(false)
      setIsPiUser(!!userData.piUid)
    }

    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const login = (name: string, role: "user" | "admin" = "user") => {
    const userData: User = {
      name,
      email: role === "admin" ? "admin@foodyo.com" : `${name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
      phone: "+1 (555) 123-4567",
      role,
    }

    setIsAuthenticated(true)
    setUserName(name)
    setUser(userData)
    setIsAdmin(role === "admin")
    setIsGuestMode(false)
    setIsPiUser(false)
    localStorage.removeItem("isGuestMode")
    localStorage.setItem("authToken", "demo-token-" + Date.now())
    localStorage.setItem("userName", name)
    localStorage.setItem("userData", JSON.stringify(userData))
  }

  const loginWithPi = (username: string, piAuth: PiAuthResult) => {
    const userData: User = {
      name: username,
      email: `${username.toLowerCase().replace(/\s+/g, ".")}@pi.network`,
      phone: "+1 (555) 123-4567",
      role: "user",
      piUid: piAuth.user.uid,
      piUsername: piAuth.user.username,
    }

    setIsAuthenticated(true)
    setUserName(username)
    setUser(userData)
    setIsAdmin(false)
    setIsGuestMode(false)
    setIsPiUser(true)
    localStorage.removeItem("isGuestMode")
    localStorage.setItem("authToken", piAuth.accessToken)
    localStorage.setItem("userName", username)
    localStorage.setItem("userData", JSON.stringify(userData))
    console.log("[v0] Pi user logged in:", username)
  }

  const logout = () => {
    // Clear only session-related data
    localStorage.removeItem("authToken")
    localStorage.removeItem("sessionId")
    localStorage.removeItem("userId")
    localStorage.removeItem("userName")
    localStorage.removeItem("userData")
    localStorage.removeItem("isGuestMode")
    localStorage.removeItem("pi_auth")
    localStorage.removeItem("pi_incomplete_payment")
    // Note: userSettings is NOT removed to preserve preferences

    setIsAuthenticated(false)
    setUserName(null)
    setUser(null)
    setIsAdmin(false)
    setIsGuestMode(false)
    setIsPiUser(false)
  }

  const updateUser = (updatedUser: User) => {
    setUser(updatedUser)
    setUserName(updatedUser.name)
    localStorage.setItem("userData", JSON.stringify(updatedUser))
    localStorage.setItem("userName", updatedUser.name)
  }

  const updateSettings = (newSettings: Settings) => {
    setSettings(newSettings)
    localStorage.setItem("userSettings", JSON.stringify(newSettings))
  }

  const requireAuth = () => {
    return isAuthenticated
  }

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isGuest: isGuestMode || !isAuthenticated,
        isAdmin,
        userName,
        user,
        settings,
        login,
        logout,
        updateUser,
        updateSettings,
        requireAuth,
        loginWithPi,
        isPiUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
