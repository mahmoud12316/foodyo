// Pi Network SDK Integration for Foodyo
// This file handles Pi authentication and payment functionality

declare global {
  interface Window {
    Pi: any
  }
}

export interface PiAuthResult {
  accessToken: string
  user: {
    uid: string
    username?: string
  }
}

export interface PiPaymentData {
  amount: number
  memo: string
  metadata: any
}

export interface PiPaymentCallbacks {
  onReadyForServerApproval: (paymentId: string) => void
  onReadyForServerCompletion: (paymentId: string, txid: string) => void
  onCancel: (paymentId: string) => void
  onError: (error: any, payment: any) => void
}

export const isPiSDKAvailable = (): boolean => {
  return typeof window !== "undefined" && typeof window.Pi !== "undefined"
}

export const initPiSDK = (sandbox = true) => {
  if (!isPiSDKAvailable()) {
    console.error("[Foodyo] Pi SDK not available - make sure pi-sdk.js is loaded")
    return false
  }

  try {
    window.Pi.init({ version: "2.0", sandbox })
    console.log("[Foodyo] Pi SDK initialized successfully", { sandbox })
    ;(window as any).piSDKInitialized = true
    return true
  } catch (error) {
    console.error("[Foodyo] Failed to initialize Pi SDK:", error)
    return false
  }
}

export const authenticateWithPi = async (
  requestUsername = true,
  requestPayments = true,
): Promise<PiAuthResult | null> => {
  if (!isPiSDKAvailable()) {
    console.error("[Foodyo] Pi SDK not available")
    throw new Error(
      "Pi SDK is not available. Please make sure you're running in Pi Browser or sandbox mode is authorized.",
    )
  }

  const waitForInit = async (maxWait = 5000): Promise<boolean> => {
    const startTime = Date.now()
    while (Date.now() - startTime < maxWait) {
      if (typeof window !== "undefined" && (window as any).piSDKInitialized) {
        return true
      }
      await new Promise((resolve) => setTimeout(resolve, 100))
    }
    return false
  }

  const isInitialized = await waitForInit()
  if (!isInitialized) {
    throw new Error("Pi Network SDK initialization timeout. Please refresh the page and try again.")
  }

  const scopes: string[] = []
  if (requestUsername) scopes.push("username")
  if (requestPayments) scopes.push("payments")

  console.log("[Foodyo] Requesting Pi authentication with scopes:", scopes)

  // Callback for incomplete payments
  const onIncompletePaymentFound = (payment: any) => {
    console.log("[Foodyo] Incomplete payment found:", payment)
    // Store incomplete payment for handling
    localStorage.setItem("pi_incomplete_payment", JSON.stringify(payment))
  }

  try {
    const auth = await window.Pi.authenticate(scopes, onIncompletePaymentFound)
    console.log("[Foodyo] Pi authentication successful:", auth)

    if (!auth || !auth.user) {
      throw new Error("Authentication returned invalid data")
    }

    // Store Pi auth data
    localStorage.setItem("pi_auth", JSON.stringify(auth))

    return auth
  } catch (error: any) {
    console.error("[Foodyo] Pi authentication failed:", error)

    // Provide more specific error messages
    if (error.message && error.message.includes("cancelled")) {
      throw new Error("Authentication was cancelled by user")
    } else if (error.message && error.message.includes("network")) {
      throw new Error("Network error - please check your connection")
    } else {
      throw new Error(`Authentication failed: ${error.message || "Unknown error"}`)
    }
  }
}

// Create a payment with Pi Network
export const createPiPayment = async (paymentData: PiPaymentData, callbacks: PiPaymentCallbacks): Promise<any> => {
  if (typeof window === "undefined" || !window.Pi) {
    console.error("[v0] Pi SDK not available")
    throw new Error("Pi SDK not available")
  }

  try {
    const payment = await window.Pi.createPayment(paymentData, callbacks)
    console.log("[v0] Pi payment created:", payment)
    return payment
  } catch (error) {
    console.error("[v0] Pi payment creation failed:", error)
    throw error
  }
}

// Get stored Pi auth data
export const getPiAuth = (): PiAuthResult | null => {
  if (typeof window === "undefined") return null

  const authData = localStorage.getItem("pi_auth")
  if (!authData) return null

  try {
    return JSON.parse(authData)
  } catch {
    return null
  }
}

// Check if user is authenticated with Pi
export const isPiAuthenticated = (): boolean => {
  return getPiAuth() !== null
}

// Logout from Pi
export const logoutFromPi = () => {
  if (typeof window !== "undefined") {
    localStorage.removeItem("pi_auth")
    localStorage.removeItem("pi_incomplete_payment")
    console.log("[v0] Logged out from Pi")
  }
}
