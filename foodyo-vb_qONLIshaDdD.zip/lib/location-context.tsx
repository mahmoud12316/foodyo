"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface LocationContextType {
  currentLocation: {
    address: string
    lat?: number
    lng?: number
  }
  setLocation: (address: string, lat?: number, lng?: number) => void
  isLocationModalOpen: boolean
  openLocationModal: () => void
  closeLocationModal: () => void
}

const LocationContext = createContext<LocationContextType | undefined>(undefined)

export function LocationProvider({ children }: { children: React.ReactNode }) {
  const [currentLocation, setCurrentLocationState] = useState({
    address: "Zarqa, Jordan",
    lat: 32.0728,
    lng: 36.0881,
  })
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false)

  useEffect(() => {
    // Load saved location from localStorage
    const savedLocation = localStorage.getItem("userLocation")
    if (savedLocation) {
      const location = JSON.parse(savedLocation)
      console.log("[v0] Loaded saved location:", location)
      setCurrentLocationState(location)
    }
  }, [])

  const setLocation = (address: string, lat?: number, lng?: number) => {
    const location = { address, lat, lng }
    console.log("[v0] Saving location:", location)
    setCurrentLocationState(location)
    localStorage.setItem("userLocation", JSON.stringify(location))
    setIsLocationModalOpen(false)
  }

  const openLocationModal = () => {
    console.log("[v0] Opening location modal")
    setIsLocationModalOpen(true)
  }

  const closeLocationModal = () => {
    console.log("[v0] Closing location modal")
    setIsLocationModalOpen(false)
  }

  return (
    <LocationContext.Provider
      value={{
        currentLocation,
        setLocation,
        isLocationModalOpen,
        openLocationModal,
        closeLocationModal,
      }}
    >
      {children}
    </LocationContext.Provider>
  )
}

export function useLocation() {
  const context = useContext(LocationContext)
  if (context === undefined) {
    throw new Error("useLocation must be used within a LocationProvider")
  }
  return context
}
