export function getRestaurantImage(category: string, name: string): string {
  // Use Unsplash Source API which always returns a valid image
  const keyword = encodeURIComponent(category.toLowerCase().replace(/\s+/g, "+"))
  return `https://source.unsplash.com/800x600/?${keyword},restaurant,food`
}

export function getMealImage(mealName: string, category: string): string {
  const keyword = encodeURIComponent(`${mealName.toLowerCase().replace(/\s+/g, "+")}+food`)
  return `https://source.unsplash.com/400x400/?${keyword}`
}

export function getFallbackImage(type: "restaurant" | "meal"): string {
  if (type === "restaurant") {
    return "https://source.unsplash.com/800x600/?restaurant,interior,food"
  }
  return "https://source.unsplash.com/400x400/?delicious,food,meal"
}
