// Utility functions for sending notifications

export async function sendOrderNotification(
  recipientType: "customer" | "driver",
  recipientId: string,
  notificationType: string,
  orderId: string,
  title: string,
  message: string,
) {
  try {
    await fetch("/api/notifications", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recipientType,
        recipientId,
        title,
        message,
        notificationType,
        orderId,
      }),
    })
  } catch (error) {
    console.error("[v0] Failed to send notification:", error)
  }
}

export async function sendBroadcastNotification(
  recipientType: "all_customers" | "all_drivers",
  title: string,
  message: string,
) {
  try {
    const response = await fetch("/api/notifications/broadcast", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        recipientType,
        title,
        message,
      }),
    })

    return response.ok
  } catch (error) {
    console.error("[v0] Failed to send broadcast:", error)
    return false
  }
}
