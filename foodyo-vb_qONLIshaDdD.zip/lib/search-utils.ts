import { type Restaurant, type Meal, getAllRestaurants, getAllMeals } from "./demo-data"

export interface SearchResult {
  restaurants: Restaurant[]
  meals: Meal[]
  totalResults: number
}

export interface PopularSuggestion {
  type: "restaurant" | "meal"
  id: number
  name: string
  category: string
  image: string
  rating?: number
  price?: number
}

export function searchFood(query: string): SearchResult {
  if (!query || query.trim() === "") {
    return { restaurants: [], meals: [], totalResults: 0 }
  }

  const normalizedQuery = query.toLowerCase().trim()
  const keywords = normalizedQuery.split(" ").filter((word) => word.length > 0)

  const allRestaurants = getAllRestaurants().filter((r) => r.status === "approved")
  const allMeals = getAllMeals()

  const restaurantMatches = allRestaurants
    .map((restaurant) => {
      let score = 0
      const searchableText =
        `${restaurant.name} ${restaurant.category} ${restaurant.cuisineType} ${restaurant.description}`.toLowerCase()

      // Exact name match - highest priority
      if (restaurant.name.toLowerCase() === normalizedQuery) {
        score += 100
      }

      // Name starts with query - high priority
      if (restaurant.name.toLowerCase().startsWith(normalizedQuery)) {
        score += 50
      }

      // Name contains query - medium priority
      if (restaurant.name.toLowerCase().includes(normalizedQuery)) {
        score += 25
      }

      // Category exact match
      if (restaurant.category.toLowerCase() === normalizedQuery) {
        score += 40
      }

      // Category contains query
      if (restaurant.category.toLowerCase().includes(normalizedQuery)) {
        score += 20
      }

      // Cuisine type match
      if (restaurant.cuisineType.toLowerCase().includes(normalizedQuery)) {
        score += 15
      }

      // Description contains query
      if (restaurant.description.toLowerCase().includes(normalizedQuery)) {
        score += 10
      }

      // Keyword matching - each keyword found adds points
      keywords.forEach((keyword) => {
        if (searchableText.includes(keyword)) {
          score += 5
        }
      })

      return { restaurant, score }
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.restaurant)

  const mealMatches = allMeals
    .map((meal) => {
      let score = 0
      const searchableText = `${meal.name} ${meal.description} ${meal.category}`.toLowerCase()

      // Exact name match
      if (meal.name.toLowerCase() === normalizedQuery) {
        score += 100
      }

      // Name starts with query
      if (meal.name.toLowerCase().startsWith(normalizedQuery)) {
        score += 50
      }

      // Name contains query
      if (meal.name.toLowerCase().includes(normalizedQuery)) {
        score += 25
      }

      // Category match
      if (meal.category.toLowerCase().includes(normalizedQuery)) {
        score += 20
      }

      // Description contains query
      if (meal.description.toLowerCase().includes(normalizedQuery)) {
        score += 10
      }

      // Keyword matching
      keywords.forEach((keyword) => {
        if (searchableText.includes(keyword)) {
          score += 5
        }
      })

      // Only include available meals or give lower priority to sold out
      if (meal.availabilityStatus === "sold_out") {
        score = score * 0.5
      }

      return { meal, score }
    })
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .map((item) => item.meal)

  return {
    restaurants: restaurantMatches,
    meals: mealMatches,
    totalResults: restaurantMatches.length + mealMatches.length,
  }
}

export function getPopularSuggestions(): PopularSuggestion[] {
  const allRestaurants = getAllRestaurants().filter((r) => r.status === "approved")
  const allMeals = getAllMeals().filter((m) => m.availabilityStatus === "available")

  // Get top 3 restaurants by rating
  const topRestaurants = allRestaurants
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 3)
    .map((r) => ({
      type: "restaurant" as const,
      id: r.id,
      name: r.name,
      category: r.category,
      image: r.image,
      rating: r.rating,
    }))

  // Get top 5 popular meals (mix from different restaurants)
  const popularMeals = allMeals
    .sort(() => Math.random() - 0.5) // Random selection for variety
    .slice(0, 5)
    .map((m) => ({
      type: "meal" as const,
      id: m.id,
      name: m.name,
      category: m.category,
      image: m.image,
      price: m.price,
    }))

  return [...topRestaurants, ...popularMeals]
}

export function getSuggestionsByCategory(category: string): PopularSuggestion[] {
  const allRestaurants = getAllRestaurants().filter((r) => r.status === "approved")
  const allMeals = getAllMeals().filter((m) => m.availabilityStatus === "available")

  const categoryLower = category.toLowerCase()

  const restaurantSuggestions = allRestaurants
    .filter(
      (r) => r.category.toLowerCase().includes(categoryLower) || r.cuisineType.toLowerCase().includes(categoryLower),
    )
    .slice(0, 3)
    .map((r) => ({
      type: "restaurant" as const,
      id: r.id,
      name: r.name,
      category: r.category,
      image: r.image,
      rating: r.rating,
    }))

  const mealSuggestions = allMeals
    .filter((m) => m.category.toLowerCase().includes(categoryLower) || m.name.toLowerCase().includes(categoryLower))
    .slice(0, 5)
    .map((m) => ({
      type: "meal" as const,
      id: m.id,
      name: m.name,
      category: m.category,
      image: m.image,
      price: m.price,
    }))

  return [...restaurantSuggestions, ...mealSuggestions]
}
