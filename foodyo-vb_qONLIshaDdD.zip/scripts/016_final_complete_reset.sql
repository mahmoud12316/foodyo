-- ========================================
-- CRITICAL DATA PURGE - DELETE ALL EXISTING DATA
-- ========================================

-- Delete all existing data in correct order (respecting foreign keys)
DELETE FROM notifications;
DELETE FROM favorites;
DELETE FROM saved_locations;
DELETE FROM order_addons;
DELETE FROM meal_addons;
DELETE FROM addons;
DELETE FROM orders;
DELETE FROM meals;
DELETE FROM partners;
DELETE FROM restaurants;
DELETE FROM drivers;
DELETE FROM users;

-- Reset auto-increment counters
ALTER TABLE notifications AUTO_INCREMENT = 1;
ALTER TABLE favorites AUTO_INCREMENT = 1;
ALTER TABLE saved_locations AUTO_INCREMENT = 1;
ALTER TABLE order_addons AUTO_INCREMENT = 1;
ALTER TABLE meal_addons AUTO_INCREMENT = 1;
ALTER TABLE addons AUTO_INCREMENT = 1;
ALTER TABLE orders AUTO_INCREMENT = 1;
ALTER TABLE meals AUTO_INCREMENT = 1;
ALTER TABLE partners AUTO_INCREMENT = 1;
ALTER TABLE restaurants AUTO_INCREMENT = 1;
ALTER TABLE drivers AUTO_INCREMENT = 1;
ALTER TABLE users AUTO_INCREMENT = 1;

-- ========================================
-- DELIVERY PRICING CONFIGURATION (3+ TIERS)
-- ========================================

DELETE FROM delivery_pricing;

INSERT INTO delivery_pricing (distance_max, delivery_fee, created_at) VALUES
(3.0, 2.50, NOW()),   -- 0-3 km: $2.50
(7.0, 4.00, NOW()),   -- 3-7 km: $4.00
(15.0, 6.50, NOW()),  -- 7-15 km: $6.50
(999.0, 10.00, NOW()); -- 15+ km: $10.00

-- ========================================
-- RESTAURANT 1: HAMBURGER RESTAURANT
-- ========================================

INSERT INTO restaurants (name, description, image_url, category, rating, delivery_time, latitude, longitude, is_partner_approved, is_open, created_at) VALUES
('Hamburger Restaurant', 'Premium burgers made with 100% Angus beef, fresh ingredients, and artisan buns. Home of the city''s best burgers.', '/placeholder.svg?height=400&width=600', 'American', 4.8, '25-35 min', 31.9539, 35.9106, TRUE, TRUE, NOW());

SET @hamburger_restaurant_id = LAST_INSERT_ID();

-- Partner account for Hamburger Restaurant
INSERT INTO partners (restaurant_id, name, email, password, restaurant_name, is_partner_approved, created_at) VALUES
(@hamburger_restaurant_id, 'Manager - Hamburger Restaurant', 'hamburger@restaurant.com', 'password123', 'Hamburger Restaurant', TRUE, NOW());

-- Meals for Hamburger Restaurant
INSERT INTO meals (restaurant_id, name, description, price, image_url, category, detailed_ingredients, availability_status, created_at) VALUES
(@hamburger_restaurant_id, 'Classic Cheeseburger', 'Our signature burger with aged cheddar, lettuce, tomato, pickles, and special sauce', 8.99, '/placeholder.svg?height=300&width=400', 'Burgers', 'Angus beef patty, cheddar cheese, lettuce, tomato, pickles, onions, special sauce, sesame seed bun. Allergens: Gluten, Dairy, Eggs', 'Available', NOW()),

(@hamburger_restaurant_id, 'Bacon BBQ Burger', 'Double patty with crispy bacon, BBQ sauce, onion rings, and pepper jack cheese', 11.99, '/placeholder.svg?height=300&width=400', 'Burgers', 'Double Angus beef patty, bacon, pepper jack cheese, BBQ sauce, onion rings, lettuce, brioche bun. Allergens: Gluten, Dairy, Pork', 'Available', NOW()),

(@hamburger_restaurant_id, 'Veggie Burger', 'Plant-based patty with avocado, sprouts, and chipotle mayo', 9.49, '/placeholder.svg?height=300&width=400', 'Burgers', 'Plant-based patty, avocado, sprouts, tomato, lettuce, chipotle mayo, whole wheat bun. Allergens: Gluten, Soy', 'Available', NOW()),

(@hamburger_restaurant_id, 'Loaded Fries', 'Crispy fries topped with cheese sauce, bacon bits, and green onions', 6.99, '/placeholder.svg?height=300&width=400', 'Sides', 'French fries, cheese sauce, bacon bits, sour cream, green onions. Allergens: Dairy, Pork, Gluten', 'Available', NOW()),

(@hamburger_restaurant_id, 'Chocolate Milkshake', 'Thick and creamy chocolate shake made with premium ice cream', 4.99, '/placeholder.svg?height=300&width=400', 'Drinks', 'Vanilla ice cream, chocolate syrup, whole milk, whipped cream. Allergens: Dairy', 'Available', NOW());

-- ========================================
-- RESTAURANT 2: SUSHI RESTAURANT
-- ========================================

INSERT INTO restaurants (name, description, image_url, category, rating, delivery_time, latitude, longitude, is_partner_approved, is_open, created_at) VALUES
('Sushi Restaurant', 'Authentic Japanese sushi crafted by master chefs. Fresh fish delivered daily from premium suppliers.', '/placeholder.svg?height=400&width=600', 'Japanese', 4.9, '30-40 min', 31.9560, 35.9450, TRUE, TRUE, NOW());

SET @sushi_restaurant_id = LAST_INSERT_ID();

-- Partner account for Sushi Restaurant
INSERT INTO partners (restaurant_id, name, email, password, restaurant_name, is_partner_approved, created_at) VALUES
(@sushi_restaurant_id, 'Manager - Sushi Restaurant', 'sushi@restaurant.com', 'password123', 'Sushi Restaurant', TRUE, NOW());

-- Meals for Sushi Restaurant
INSERT INTO meals (restaurant_id, name, description, price, image_url, category, detailed_ingredients, availability_status, created_at) VALUES
(@sushi_restaurant_id, 'Salmon Nigiri Set', 'Eight pieces of fresh Atlantic salmon nigiri with wasabi and pickled ginger', 14.99, '/placeholder.svg?height=300&width=400', 'Sushi', 'Fresh Atlantic salmon, sushi rice, wasabi, pickled ginger, soy sauce. Allergens: Fish, Gluten (soy sauce)', 'Available', NOW()),

(@sushi_restaurant_id, 'Dragon Roll', 'Shrimp tempura and cucumber topped with avocado and eel sauce', 16.99, '/placeholder.svg?height=300&width=400', 'Rolls', 'Shrimp tempura, cucumber, avocado, nori, sushi rice, eel sauce, sesame seeds. Allergens: Shellfish, Gluten, Eggs', 'Available', NOW()),

(@sushi_restaurant_id, 'Spicy Tuna Roll', 'Fresh tuna mixed with spicy mayo, cucumber, and sesame seeds', 12.99, '/placeholder.svg?height=300&width=400', 'Rolls', 'Fresh tuna, spicy mayo, cucumber, nori, sushi rice, sesame seeds. Allergens: Fish, Eggs, Gluten', 'Available', NOW()),

(@sushi_restaurant_id, 'Miso Soup', 'Traditional Japanese soup with tofu, seaweed, and green onions', 3.99, '/placeholder.svg?height=300&width=400', 'Soup', 'Miso paste, tofu, wakame seaweed, green onions, dashi broth. Allergens: Soy', 'Available', NOW()),

(@sushi_restaurant_id, 'Green Tea Ice Cream', 'Premium matcha ice cream with red bean topping', 5.99, '/placeholder.svg?height=300&width=400', 'Dessert', 'Green tea ice cream, red bean paste, mochi pieces. Allergens: Dairy', 'Available', NOW());

-- ========================================
-- RESTAURANT 3: CRISPY CHICKEN RESTAURANT
-- ========================================

INSERT INTO restaurants (name, description, image_url, category, rating, delivery_time, latitude, longitude, is_partner_approved, is_open, created_at) VALUES
('Crispy Chicken Restaurant', 'Perfectly fried chicken with our secret blend of 11 herbs and spices. Crispy outside, juicy inside.', '/placeholder.svg?height=400&width=600', 'American', 4.7, '20-30 min', 31.9520, 35.9300, TRUE, TRUE, NOW());

SET @chicken_restaurant_id = LAST_INSERT_ID();

-- Partner account for Crispy Chicken Restaurant
INSERT INTO partners (restaurant_id, name, email, password, restaurant_name, is_partner_approved, created_at) VALUES
(@chicken_restaurant_id, 'Manager - Crispy Chicken Restaurant', 'chicken@restaurant.com', 'password123', 'Crispy Chicken Restaurant', TRUE, NOW());

-- Meals for Crispy Chicken Restaurant
INSERT INTO meals (restaurant_id, name, description, price, image_url, category, detailed_ingredients, availability_status, created_at) VALUES
(@chicken_restaurant_id, 'Original Fried Chicken', '4 pieces of our signature crispy fried chicken with your choice of sides', 10.99, '/placeholder.svg?height=300&width=400', 'Chicken', 'Chicken pieces, buttermilk marinade, special breading (flour, 11 herbs and spices), vegetable oil. Allergens: Gluten, Dairy, Eggs', 'Available', NOW()),

(@chicken_restaurant_id, 'Spicy Wings', '8 buffalo wings tossed in hot sauce with ranch dipping sauce', 9.99, '/placeholder.svg?height=300&width=400', 'Chicken', 'Chicken wings, hot sauce, butter, ranch dressing, celery sticks. Allergens: Dairy, Gluten', 'Available', NOW()),

(@chicken_restaurant_id, 'Chicken Tenders Basket', '5 hand-breaded chicken tenders with honey mustard and fries', 11.49, '/placeholder.svg?height=300&width=400', 'Chicken', 'Chicken breast strips, buttermilk, breading, honey mustard sauce, french fries. Allergens: Gluten, Dairy, Eggs', 'Available', NOW()),

(@chicken_restaurant_id, 'Coleslaw', 'Creamy homemade coleslaw made fresh daily', 3.49, '/placeholder.svg?height=300&width=400', 'Sides', 'Cabbage, carrots, mayonnaise, vinegar, sugar, celery seeds. Allergens: Eggs', 'Available', NOW()),

(@chicken_restaurant_id, 'Biscuits', 'Two fluffy buttermilk biscuits with honey butter', 2.99, '/placeholder.svg?height=300&width=400', 'Sides', 'Flour, buttermilk, butter, baking powder, salt, honey. Allergens: Gluten, Dairy', 'Available', NOW());

-- ========================================
-- RESTAURANT 4: TACO RESTAURANT
-- ========================================

INSERT INTO restaurants (name, description, image_url, category, rating, delivery_time, latitude, longitude, is_partner_approved, is_open, created_at) VALUES
('Taco Restaurant', 'Authentic Mexican street tacos with fresh ingredients and homemade salsas. A taste of Mexico in every bite.', '/placeholder.svg?height=400&width=600', 'Mexican', 4.8, '25-35 min', 31.9580, 35.9250, TRUE, TRUE, NOW());

SET @taco_restaurant_id = LAST_INSERT_ID();

-- Partner account for Taco Restaurant
INSERT INTO partners (restaurant_id, name, email, password, restaurant_name, is_partner_approved, created_at) VALUES
(@taco_restaurant_id, 'Manager - Taco Restaurant', 'taco@restaurant.com', 'password123', 'Taco Restaurant', TRUE, NOW());

-- Meals for Taco Restaurant
INSERT INTO meals (restaurant_id, name, description, price, image_url, category, detailed_ingredients, availability_status, created_at) VALUES
(@taco_restaurant_id, 'Carne Asada Tacos', 'Three soft tacos with grilled steak, onions, cilantro, and lime', 11.99, '/placeholder.svg?height=300&width=400', 'Tacos', 'Grilled beef, corn tortillas, onions, cilantro, lime, salsa verde. Allergens: None (Gluten-free available)', 'Available', NOW()),

(@taco_restaurant_id, 'Fish Tacos', 'Beer-battered fish with cabbage slaw, pico de gallo, and chipotle mayo', 12.99, '/placeholder.svg?height=300&width=400', 'Tacos', 'Beer-battered white fish, cabbage, pico de gallo, chipotle mayo, corn tortillas. Allergens: Fish, Gluten, Eggs', 'Available', NOW()),

(@taco_restaurant_id, 'Chicken Burrito', 'Large flour tortilla filled with seasoned chicken, rice, beans, cheese, and guacamole', 10.99, '/placeholder.svg?height=300&width=400', 'Burritos', 'Grilled chicken, flour tortilla, rice, black beans, cheese, guacamole, sour cream, salsa. Allergens: Gluten, Dairy', 'Available', NOW()),

(@taco_restaurant_id, 'Chips and Guacamole', 'Fresh tortilla chips with house-made guacamole', 6.99, '/placeholder.svg?height=300&width=400', 'Appetizers', 'Avocado, tomatoes, onions, cilantro, lime juice, tortilla chips, jalapeños. Allergens: None', 'Available', NOW()),

(@taco_restaurant_id, 'Churros', 'Four cinnamon sugar churros with chocolate dipping sauce', 5.99, '/placeholder.svg?height=300&width=400', 'Dessert', 'Flour, eggs, butter, cinnamon, sugar, chocolate sauce. Allergens: Gluten, Dairy, Eggs', 'Available', NOW());

-- ========================================
-- RESTAURANT 5: PIZZA RESTAURANT
-- ========================================

INSERT INTO restaurants (name, description, image_url, category, rating, delivery_time, latitude, longitude, is_partner_approved, is_open, created_at) VALUES
('Pizza Restaurant', 'New York style pizza with hand-tossed dough and premium toppings. Wood-fired to perfection.', '/placeholder.svg?height=400&width=600', 'Italian', 4.9, '30-40 min', 31.9500, 35.9350, TRUE, TRUE, NOW());

SET @pizza_restaurant_id = LAST_INSERT_ID();

-- Partner account for Pizza Restaurant
INSERT INTO partners (restaurant_id, name, email, password, restaurant_name, is_partner_approved, created_at) VALUES
(@pizza_restaurant_id, 'Manager - Pizza Restaurant', 'pizza@restaurant.com', 'password123', 'Pizza Restaurant', TRUE, NOW());

-- Meals for Pizza Restaurant
INSERT INTO meals (restaurant_id, name, description, price, image_url, category, detailed_ingredients, availability_status, created_at) VALUES
(@pizza_restaurant_id, 'Margherita Pizza', 'Classic pizza with fresh mozzarella, basil, and San Marzano tomato sauce', 13.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough, San Marzano tomatoes, fresh mozzarella, basil, olive oil, garlic. Allergens: Gluten, Dairy', 'Available', NOW()),

(@pizza_restaurant_id, 'Pepperoni Pizza', 'Loaded with premium pepperoni and three-cheese blend', 15.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough, tomato sauce, mozzarella, provolone, parmesan, pepperoni. Allergens: Gluten, Dairy, Pork', 'Available', NOW()),

(@pizza_restaurant_id, 'BBQ Chicken Pizza', 'Grilled chicken, BBQ sauce, red onions, and cilantro', 16.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough, BBQ sauce, grilled chicken, mozzarella, red onions, cilantro. Allergens: Gluten, Dairy', 'Available', NOW()),

(@pizza_restaurant_id, 'Caesar Salad', 'Crisp romaine lettuce with Caesar dressing, croutons, and parmesan', 7.99, '/placeholder.svg?height=300&width=400', 'Salads', 'Romaine lettuce, Caesar dressing, croutons, parmesan cheese, lemon. Allergens: Gluten, Dairy, Eggs, Fish (anchovies)', 'Available', NOW()),

(@pizza_restaurant_id, 'Tiramisu', 'Classic Italian dessert with espresso-soaked ladyfingers and mascarpone', 6.99, '/placeholder.svg?height=300&width=400', 'Dessert', 'Ladyfinger cookies, mascarpone cheese, espresso, cocoa powder, eggs, sugar. Allergens: Gluten, Dairy, Eggs', 'Available', NOW());

-- ========================================
-- FINAL VERIFICATION MESSAGE
-- ========================================

SELECT 'Database Reset Complete!' as Status;
SELECT COUNT(*) as 'Total Restaurants' FROM restaurants WHERE is_partner_approved = TRUE AND is_open = TRUE;
SELECT COUNT(*) as 'Total Meals' FROM meals WHERE availability_status = 'Available';
SELECT COUNT(*) as 'Delivery Price Tiers' FROM delivery_pricing;
