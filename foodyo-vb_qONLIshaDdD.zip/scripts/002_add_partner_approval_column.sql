-- Add isPartnerApproved column to partners table
-- This column tracks whether a partner's application has been approved by admin

-- Create partners table if it doesn't exist
CREATE TABLE IF NOT EXISTS partners (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  restaurant_name VARCHAR(255) NOT NULL,
  is_partner_approved BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add index for faster email lookups
CREATE INDEX IF NOT EXISTS idx_partners_email ON partners(email);

-- Add index for filtering by approval status
CREATE INDEX IF NOT EXISTS idx_partners_approval ON partners(is_partner_approved);
