-- Add rating columns to orders table
ALTER TABLE orders ADD COLUMN IF NOT EXISTS restaurant_rating INTEGER CHECK (restaurant_rating >= 1 AND restaurant_rating <= 5);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS driver_rating INTEGER CHECK (driver_rating >= 1 AND driver_rating <= 5);
ALTER TABLE orders ADD COLUMN IF NOT EXISTS rated_at TIMESTAMP;

-- Add index for faster rating queries
CREATE INDEX IF NOT EXISTS idx_orders_restaurant_rating ON orders(restaurant_id, restaurant_rating);
CREATE INDEX IF NOT EXISTS idx_orders_driver_rating ON orders(driver_id, driver_rating);
