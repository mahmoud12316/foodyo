-- Add driver assignment and new status to orders table

-- Add driver_id column to track assigned driver
ALTER TABLE orders ADD COLUMN IF NOT EXISTS driver_id INTEGER REFERENCES drivers(id);

-- Add index for faster driver lookups
CREATE INDEX IF NOT EXISTS idx_orders_driver_id ON orders(driver_id);

-- Add index for status filtering
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);

-- Update any existing "Ready for Pickup/Delivery" orders to support the new "Assigned to Driver" status
-- Note: New status will be "Assigned to Driver" after a driver is assigned
