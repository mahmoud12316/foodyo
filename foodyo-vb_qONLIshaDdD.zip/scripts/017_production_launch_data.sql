-- ============================================
-- PRODUCTION LAUNCH DATA INITIALIZATION
-- ============================================
-- This script completely resets the database and loads production-ready data
-- with 5 specific restaurants and 25 meals

-- ============================================
-- STEP 1: CRITICAL DATA PURGE
-- ============================================

-- Delete all existing data (in correct order to respect foreign keys)
DELETE FROM order_items;
DELETE FROM orders;
DELETE FROM meal_addons;
DELETE FROM addons;
DELETE FROM favorites;
DELETE FROM saved_locations;
DELETE FROM notifications;
DELETE FROM meals;
DELETE FROM partners;
DELETE FROM restaurants;
DELETE FROM drivers;

-- Reset sequences if using PostgreSQL
ALTER SEQUENCE IF EXISTS restaurants_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS meals_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS partners_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS drivers_id_seq RESTART WITH 1;
ALTER SEQUENCE IF EXISTS orders_id_seq RESTART WITH 1;

-- ============================================
-- STEP 2: DELIVERY PRICING TIERS
-- ============================================

-- Clear and repopulate delivery pricing
DELETE FROM delivery_pricing;

INSERT INTO delivery_pricing (distance_max_km, delivery_fee, description) VALUES
(3.0, 2.00, 'Short distance (0-3 km)'),
(7.0, 4.00, 'Medium distance (3-7 km)'),
(15.0, 7.00, 'Long distance (7-15 km)'),
(9999.0, 12.00, 'Very long distance (15+ km)');

-- ============================================
-- STEP 3: CREATE 5 SPECIFIC RESTAURANTS
-- ============================================

-- 1. King Burger (Hamburger Restaurant)
INSERT INTO restaurants (name, category, image_url, description, is_partner_approved, is_open, latitude, longitude, created_at) VALUES
('King Burger', 'Fast Food', '/placeholder.svg?height=200&width=400', 'Home of the juiciest burgers in town! Premium beef patties, fresh ingredients, and secret sauces that keep you coming back.', true, true, 32.0369, 35.8781, NOW());

-- 2. Osaka Rolls (Sushi Restaurant)
INSERT INTO restaurants (name, category, image_url, description, is_partner_approved, is_open, latitude, longitude, created_at) VALUES
('Osaka Rolls', 'Asian', '/placeholder.svg?height=200&width=400', 'Authentic Japanese sushi crafted by master chefs. Fresh fish daily, traditional recipes, and modern fusion rolls.', true, true, 32.0385, 35.8795, NOW());

-- 3. Cluck Factory (Crispy Chicken Restaurant)
INSERT INTO restaurants (name, category, image_url, description, is_partner_approved, is_open, latitude, longitude, created_at) VALUES
('Cluck Factory', 'Fast Food', '/placeholder.svg?height=200&width=400', 'Perfectly crispy chicken every time! Our secret blend of spices and cooking technique creates irresistible crunch.', true, true, 32.0355, 35.8770, NOW());

-- 4. El Fuego Tacos (Taco Restaurant)
INSERT INTO restaurants (name, category, image_url, description, is_partner_approved, is_open, latitude, longitude, created_at) VALUES
('El Fuego Tacos', 'Mexican', '/placeholder.svg?height=200&width=400', 'Authentic Mexican street tacos with bold flavors! Fresh tortillas made daily, premium meats, and traditional salsas.', true, true, 32.0375, 35.8765, NOW());

-- 5. Vito''s Pizza (Pizza Restaurant)
INSERT INTO restaurants (name, category, image_url, description, is_partner_approved, is_open, latitude, longitude, created_at) VALUES
('Vito''s Pizza', 'Italian', '/placeholder.svg?height=200&width=400', 'Traditional Italian pizza from our wood-fired oven. Authentic recipes from Naples, fresh mozzarella, and imported ingredients.', true, true, 32.0390, 35.8800, NOW());

-- ============================================
-- STEP 4: CREATE 25 MEALS (5 PER RESTAURANT)
-- ============================================

-- KING BURGER - 5 Meals
INSERT INTO meals (restaurant_id, name, description, price, category, image_url, detailed_ingredients, availability_status, created_at) VALUES
(1, 'Classic King Burger', 'Our signature 1/4 lb beef patty with lettuce, tomato, onion, pickles, special sauce on a toasted brioche bun', 8.99, 'Burgers', '/placeholder.svg?height=300&width=300', 'Beef patty (200g), brioche bun, lettuce, tomato, onion, pickles, special sauce (mayo, ketchup, mustard). ALLERGENS: Gluten, eggs, dairy', 'Available', NOW()),
(1, 'Double Bacon Cheeseburger', 'Two juicy patties topped with crispy bacon, melted cheddar cheese, lettuce, and BBQ sauce', 12.99, 'Burgers', '/placeholder.svg?height=300&width=300', 'Two beef patties (400g total), bacon strips, cheddar cheese, lettuce, BBQ sauce, sesame bun. ALLERGENS: Gluten, dairy, pork', 'Available', NOW()),
(1, 'Spicy Jalapeño Burger', 'Beef patty with pepper jack cheese, jalapeños, spicy mayo, and crispy onion rings', 10.99, 'Burgers', '/placeholder.svg?height=300&width=300', 'Beef patty, pepper jack cheese, jalapeños, spicy mayo, onion rings, chipotle sauce. ALLERGENS: Gluten, dairy, eggs, contains spicy peppers', 'Available', NOW()),
(1, 'Crispy Chicken Burger', 'Golden fried chicken breast with coleslaw, pickles, and honey mustard on a soft bun', 9.49, 'Chicken', '/placeholder.svg?height=300&width=300', 'Breaded chicken breast, coleslaw (cabbage, carrots, mayo), pickles, honey mustard sauce. ALLERGENS: Gluten, eggs, dairy, mustard', 'Available', NOW()),
(1, 'King''s Loaded Fries', 'Crispy golden fries topped with melted cheese, bacon bits, jalapeños, and ranch dressing', 6.99, 'Sides', '/placeholder.svg?height=300&width=300', 'French fries, cheddar cheese sauce, bacon bits, jalapeños, ranch dressing, green onions. ALLERGENS: Dairy, pork', 'Available', NOW());

-- OSAKA ROLLS - 5 Meals
INSERT INTO meals (restaurant_id, name, description, price, category, image_url, detailed_ingredients, availability_status, created_at) VALUES
(2, 'Dragon Roll', 'Shrimp tempura, avocado, topped with eel, eel sauce, and sesame seeds', 14.99, 'Specialty Rolls', '/placeholder.svg?height=300&width=300', 'Shrimp tempura, avocado, eel, sushi rice, nori, eel sauce, sesame seeds. ALLERGENS: Shellfish, fish, gluten, soy, sesame', 'Available', NOW()),
(2, 'Rainbow Sashimi Platter', 'Assorted fresh sashimi - salmon, tuna, yellowtail, served with wasabi and soy sauce', 18.99, 'Sashimi', '/placeholder.svg?height=300&width=300', 'Fresh salmon, tuna, yellowtail, octopus, wasabi, soy sauce, pickled ginger. ALLERGENS: Fish, shellfish, soy', 'Available', NOW()),
(2, 'Spicy Tuna Roll', 'Fresh tuna mixed with spicy mayo, cucumber, topped with crunchy tempura flakes', 11.99, 'Classic Rolls', '/placeholder.svg?height=300&width=300', 'Fresh tuna, spicy mayo, cucumber, sushi rice, nori, tempura flakes, scallions. ALLERGENS: Fish, eggs, gluten, soy, contains spicy elements', 'Available', NOW()),
(2, 'Vegetable Tempura Roll', 'Assorted vegetables in light tempura batter, served with tempura dipping sauce', 9.99, 'Vegetarian', '/placeholder.svg?height=300&width=300', 'Sweet potato, asparagus, carrots, tempura batter, sushi rice, nori, tempura sauce. ALLERGENS: Gluten, eggs, soy', 'Available', NOW()),
(2, 'California Roll Combo', 'Traditional California roll with miso soup and edamame', 12.99, 'Combo Meals', '/placeholder.svg?height=300&width=300', 'Imitation crab, avocado, cucumber, sushi rice, nori, miso soup, edamame. ALLERGENS: Shellfish, soy, gluten, sesame', 'Available', NOW());

-- CLUCK FACTORY - 5 Meals
INSERT INTO meals (restaurant_id, name, description, price, category, image_url, detailed_ingredients, availability_status, created_at) VALUES
(3, 'Original Crispy Chicken', '4 pieces of our signature crispy fried chicken with secret spice blend', 10.99, 'Fried Chicken', '/placeholder.svg?height=300&width=300', 'Chicken pieces (4), secret spice blend, buttermilk marinade, crispy coating. ALLERGENS: Gluten, dairy, eggs', 'Available', NOW()),
(3, 'Spicy Buffalo Wings', '8 jumbo wings tossed in fiery buffalo sauce, served with ranch dip', 11.99, 'Wings', '/placeholder.svg?height=300&width=300', 'Chicken wings (8), buffalo sauce (hot peppers, butter, vinegar), ranch dressing, celery sticks. ALLERGENS: Dairy, contains very spicy peppers', 'Available', NOW()),
(3, 'Chicken Tenders Box', '6 golden chicken tenders with honey mustard and BBQ sauce', 9.49, 'Tenders', '/placeholder.svg?height=300&width=300', 'Chicken breast strips (6), breading, honey mustard sauce, BBQ sauce. ALLERGENS: Gluten, eggs, dairy, mustard', 'Available', NOW()),
(3, 'Mega Family Bucket', '12 pieces of mixed chicken (legs, thighs, wings) with coleslaw and biscuits', 24.99, 'Family Meals', '/placeholder.svg?height=300&width=300', 'Mixed chicken pieces (12), coleslaw, buttermilk biscuits (4), honey butter. ALLERGENS: Gluten, dairy, eggs', 'Available', NOW()),
(3, 'Crispy Chicken Wrap', 'Crispy chicken strips wrapped with lettuce, tomato, ranch, and cheddar cheese', 8.99, 'Wraps', '/placeholder.svg?height=300&width=300', 'Crispy chicken strips, flour tortilla, lettuce, tomato, ranch dressing, cheddar cheese. ALLERGENS: Gluten, dairy, eggs', 'Available', NOW());

-- EL FUEGO TACOS - 5 Meals
INSERT INTO meals (restaurant_id, name, description, price, category, image_url, detailed_ingredients, availability_status, created_at) VALUES
(4, 'Carne Asada Tacos', '3 soft corn tortillas filled with grilled marinated steak, cilantro, onions, and lime', 11.99, 'Tacos', '/placeholder.svg?height=300&width=300', 'Grilled steak, corn tortillas (3), cilantro, white onion, lime, salsa verde. ALLERGENS: None (gluten-free)', 'Available', NOW()),
(4, 'Al Pastor Tacos', '3 tacos with marinated pork, pineapple, onions, cilantro, and chipotle sauce', 10.99, 'Tacos', '/placeholder.svg?height=300&width=300', 'Marinated pork, pineapple, corn tortillas (3), cilantro, onion, chipotle sauce. ALLERGENS: Pork, contains spicy peppers', 'Available', NOW()),
(4, 'Fish Tacos Supreme', '3 crispy battered fish tacos with cabbage slaw, pico de gallo, and chipotle mayo', 12.99, 'Tacos', '/placeholder.svg?height=300&width=300', 'Battered white fish, corn tortillas (3), cabbage slaw, pico de gallo, chipotle mayo, lime. ALLERGENS: Fish, eggs, gluten (batter)', 'Available', NOW()),
(4, 'Chicken Burrito Bowl', 'Grilled chicken over cilantro-lime rice with black beans, cheese, guacamole, and salsa', 10.99, 'Bowls', '/placeholder.svg?height=300&width=300', 'Grilled chicken, cilantro-lime rice, black beans, cheddar cheese, guacamole, pico de gallo, sour cream. ALLERGENS: Dairy', 'Available', NOW()),
(4, 'Loaded Nachos Grande', 'Crispy tortilla chips piled high with cheese, jalapeños, beans, sour cream, and guacamole', 9.99, 'Appetizers', '/placeholder.svg?height=300&width=300', 'Tortilla chips, cheese sauce, jalapeños, black beans, sour cream, guacamole, salsa. ALLERGENS: Dairy, contains spicy peppers', 'Available', NOW());

-- VITO'S PIZZA - 5 Meals
INSERT INTO meals (restaurant_id, name, description, price, category, image_url, detailed_ingredients, availability_status, created_at) VALUES
(5, 'Margherita Classica', 'Traditional pizza with San Marzano tomatoes, fresh mozzarella, basil, and extra virgin olive oil', 13.99, 'Classic Pizzas', '/placeholder.svg?height=300&width=300', 'Pizza dough, San Marzano tomato sauce, fresh mozzarella, fresh basil, olive oil. ALLERGENS: Gluten, dairy', 'Available', NOW()),
(5, 'Quattro Formaggi', 'Four cheese pizza - mozzarella, gorgonzola, parmesan, and fontina', 15.99, 'Specialty Pizzas', '/placeholder.svg?height=300&width=300', 'Pizza dough, mozzarella, gorgonzola, parmesan, fontina cheese, olive oil. ALLERGENS: Gluten, dairy', 'Available', NOW()),
(5, 'Pepperoni Supreme', 'Classic pepperoni pizza with extra cheese and Italian herbs', 14.99, 'Classic Pizzas', '/placeholder.svg?height=300&width=300', 'Pizza dough, tomato sauce, mozzarella, pepperoni, Italian herbs, parmesan. ALLERGENS: Gluten, dairy, pork', 'Available', NOW()),
(5, 'Veggie Garden Pizza', 'Loaded with mushrooms, bell peppers, onions, olives, tomatoes, and spinach', 13.99, 'Vegetarian', '/placeholder.svg?height=300&width=300', 'Pizza dough, tomato sauce, mozzarella, mushrooms, bell peppers, onions, black olives, tomatoes, spinach. ALLERGENS: Gluten, dairy', 'Available', NOW()),
(5, 'Italian Calzone', 'Folded pizza filled with ricotta, mozzarella, ham, and marinara for dipping', 12.99, 'Calzones', '/placeholder.svg?height=300&width=300', 'Pizza dough, ricotta cheese, mozzarella, Italian ham, marinara sauce. ALLERGENS: Gluten, dairy, pork', 'Available', NOW());

-- ============================================
-- VERIFICATION QUERIES
-- ============================================
-- Run these to verify the data

-- SELECT 'Restaurants' as entity, COUNT(*) as count FROM restaurants;
-- SELECT 'Meals' as entity, COUNT(*) as count FROM meals;
-- SELECT 'Delivery Pricing Tiers' as entity, COUNT(*) as count FROM delivery_pricing;
-- SELECT name, category, is_partner_approved, is_open FROM restaurants ORDER BY id;
-- SELECT r.name as restaurant, COUNT(m.id) as meal_count FROM restaurants r LEFT JOIN meals m ON r.id = m.restaurant_id GROUP BY r.name ORDER BY r.id;
