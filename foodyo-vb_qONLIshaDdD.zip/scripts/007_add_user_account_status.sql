-- Add account status column to users table
ALTER TABLE users
ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE,
ADD COLUMN IF NOT EXISTS phone VARCHAR(20);

-- Add index for faster queries
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- Update existing users to be active by default
UPDATE users SET is_active = TRUE WHERE is_active IS NULL;

COMMENT ON COLUMN users.is_active IS 'Whether the user account is active or deactivated';
COMMENT ON COLUMN users.phone IS 'User phone number for contact';
