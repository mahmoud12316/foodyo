-- =====================================================
-- LAUNCH DATA INITIALIZATION SCRIPT
-- =====================================================
-- This script cleans all existing data and loads the initial 5 restaurants
-- with 25 meals (5 per restaurant) and delivery pricing configuration.

-- =====================================================
-- STEP 1: DATA PURGE - Clean existing data
-- =====================================================

-- Delete existing data in reverse order of dependencies
DELETE FROM order_items WHERE 1=1;
DELETE FROM orders WHERE 1=1;
DELETE FROM favorites WHERE 1=1;
DELETE FROM meal_addons_assignments WHERE 1=1;
DELETE FROM meal_addons WHERE 1=1;
DELETE FROM meals WHERE 1=1;
DELETE FROM restaurants WHERE 1=1;
DELETE FROM partners WHERE 1=1;
DELETE FROM drivers WHERE 1=1;
DELETE FROM saved_locations WHERE 1=1;
DELETE FROM notifications WHERE 1=1;

-- Reset delivery pricing (we'll repopulate)
DELETE FROM delivery_pricing WHERE 1=1;

-- =====================================================
-- STEP 2: DELIVERY PRICING SETUP
-- =====================================================

INSERT INTO delivery_pricing (distance_max_km, delivery_fee, created_at) VALUES
(3.0, 5.00, NOW()),
(7.0, 8.00, NOW()),
(15.0, 12.00, NOW()),
(999.0, 20.00, NOW());

-- =====================================================
-- STEP 3: RESTAURANT CREATION (5 Restaurants)
-- =====================================================

-- Restaurant 1: Hamburger Restaurant
INSERT INTO restaurants (
  name, 
  category, 
  description, 
  image, 
  rating, 
  delivery_time, 
  latitude, 
  longitude, 
  is_partner_approved, 
  is_open,
  created_at
) VALUES (
  'Burger Haven',
  'Fast Food',
  'Premium burgers crafted with 100% Angus beef, artisan buns, and fresh toppings. Home of the legendary double-stack burger.',
  '/placeholder.svg?height=400&width=600',
  4.8,
  '25-35 min',
  32.0667,
  36.0833,
  TRUE,
  TRUE,
  NOW()
);

-- Restaurant 2: Sushi Restaurant
INSERT INTO restaurants (
  name, 
  category, 
  description, 
  image, 
  rating, 
  delivery_time, 
  latitude, 
  longitude, 
  is_partner_approved, 
  is_open,
  created_at
) VALUES (
  'Tokyo Sushi House',
  'Asian',
  'Authentic Japanese sushi prepared by master chefs. Fresh daily catches and traditional recipes passed down through generations.',
  '/placeholder.svg?height=400&width=600',
  4.9,
  '30-40 min',
  32.0700,
  36.0900,
  TRUE,
  TRUE,
  NOW()
);

-- Restaurant 3: Crispy Chicken Restaurant
INSERT INTO restaurants (
  name, 
  category, 
  description, 
  image, 
  rating, 
  delivery_time, 
  latitude, 
  longitude, 
  is_partner_approved, 
  is_open,
  created_at
) VALUES (
  'Golden Crispy Chicken',
  'Fast Food',
  'Perfectly seasoned, golden-fried chicken with a secret spice blend. Crispy on the outside, juicy on the inside.',
  '/placeholder.svg?height=400&width=600',
  4.7,
  '20-30 min',
  32.0650,
  36.0750,
  TRUE,
  TRUE,
  NOW()
);

-- Restaurant 4: Taco Restaurant
INSERT INTO restaurants (
  name, 
  category, 
  description, 
  image, 
  rating, 
  delivery_time, 
  latitude, 
  longitude, 
  is_partner_approved, 
  is_open,
  created_at
) VALUES (
  'Casa de Tacos',
  'Mexican',
  'Street-style tacos with authentic Mexican flavors. Handmade tortillas, fresh salsa, and traditional recipes from Mexico City.',
  '/placeholder.svg?height=400&width=600',
  4.6,
  '25-35 min',
  32.0620,
  36.0820,
  TRUE,
  TRUE,
  NOW()
);

-- Restaurant 5: Pizza Restaurant
INSERT INTO restaurants (
  name, 
  category, 
  description, 
  image, 
  rating, 
  delivery_time, 
  latitude, 
  longitude, 
  is_partner_approved, 
  is_open,
  created_at
) VALUES (
  'Napoli Pizza Kitchen',
  'Italian',
  'Wood-fired Neapolitan pizza with imported Italian ingredients. Thin, crispy crust with authentic Italian flavors.',
  '/placeholder.svg?height=400&width=600',
  4.8,
  '30-40 min',
  32.0680,
  36.0880,
  TRUE,
  TRUE,
  NOW()
);

-- =====================================================
-- STEP 4: MEALS CREATION (25 Meals - 5 per Restaurant)
-- =====================================================

-- BURGER HAVEN MEALS (Restaurant ID: 1)
-- =====================================================

INSERT INTO meals (restaurant_id, name, description, price, category, image, availability_status, detailed_ingredients, created_at) VALUES
(1, 'Classic Angus Burger', 'Premium Angus beef patty with lettuce, tomato, pickles, onions, and our signature sauce on a toasted brioche bun', 12.99, 'Burgers', '/placeholder.svg?height=300&width=400', 'Available', 'Angus beef (150g), brioche bun, lettuce, tomato, pickles, red onions, house sauce. Contains: Gluten, Dairy, Eggs. May contain traces of soy.', NOW()),
(1, 'Double Stack Burger', 'Two juicy beef patties, double cheese, bacon strips, caramelized onions, and BBQ sauce', 16.99, 'Burgers', '/placeholder.svg?height=300&width=400', 'Available', 'Angus beef patties (2x150g), cheddar cheese, bacon, caramelized onions, BBQ sauce, sesame bun. Contains: Gluten, Dairy. Allergens: Soy in BBQ sauce.', NOW()),
(1, 'Mushroom Swiss Burger', 'Beef patty topped with sautéed mushrooms, Swiss cheese, and truffle aioli', 14.99, 'Burgers', '/placeholder.svg?height=300&width=400', 'Available', 'Angus beef (150g), Swiss cheese, sautéed mushrooms, truffle aioli, arugula. Contains: Gluten, Dairy, Eggs. May contain traces of nuts.', NOW()),
(1, 'Crispy Chicken Burger', 'Buttermilk fried chicken breast with coleslaw, pickles, and spicy mayo', 13.99, 'Burgers', '/placeholder.svg?height=300&width=400', 'Available', 'Chicken breast, buttermilk coating, coleslaw, pickles, spicy mayo, potato bun. Contains: Gluten, Dairy, Eggs. Allergens: May contain sesame.', NOW()),
(1, 'Loaded Cheese Fries', 'Golden fries topped with melted cheddar, bacon bits, jalapeños, and sour cream', 8.99, 'Sides', '/placeholder.svg?height=300&width=400', 'Available', 'French fries, cheddar cheese sauce, bacon, jalapeños, sour cream, green onions. Contains: Dairy. May contain gluten cross-contamination.', NOW());

-- TOKYO SUSHI HOUSE MEALS (Restaurant ID: 2)
-- =====================================================

INSERT INTO meals (restaurant_id, name, description, price, category, image, availability_status, detailed_ingredients, created_at) VALUES
(2, 'Salmon Nigiri Set', 'Fresh Atlantic salmon nigiri (8 pieces) with wasabi and pickled ginger', 18.99, 'Sushi', '/placeholder.svg?height=300&width=400', 'Available', 'Atlantic salmon, sushi rice, nori, wasabi, pickled ginger. Contains: Fish, Sesame. Gluten-free rice vinegar used.', NOW()),
(2, 'Dragon Roll', 'Shrimp tempura, avocado, topped with eel and eel sauce', 16.99, 'Sushi', '/placeholder.svg?height=300&width=400', 'Available', 'Shrimp tempura, avocado, freshwater eel, cucumber, eel sauce, sesame seeds, sushi rice, nori. Contains: Shellfish, Fish, Gluten, Sesame, Soy.', NOW()),
(2, 'California Roll Combo', 'Classic California rolls (12 pieces) with crab, avocado, and cucumber', 14.99, 'Sushi', '/placeholder.svg?height=300&width=400', 'Available', 'Imitation crab, avocado, cucumber, tobiko, sushi rice, nori. Contains: Fish, Shellfish, Eggs. May contain gluten in crab stick.', NOW()),
(2, 'Tuna Sashimi Platter', 'Premium bluefin tuna sashimi (10 pieces) served with soy sauce', 22.99, 'Sashimi', '/placeholder.svg?height=300&width=400', 'Available', 'Bluefin tuna (200g), wasabi, pickled ginger, soy sauce. Contains: Fish, Soy. Gluten-free soy sauce available upon request.', NOW()),
(2, 'Miso Soup', 'Traditional Japanese miso soup with tofu, seaweed, and green onions', 4.99, 'Soups', '/placeholder.svg?height=300&width=400', 'Available', 'Miso paste, dashi broth, tofu, wakame seaweed, green onions. Contains: Soy. May contain traces of fish (dashi).', NOW());

-- GOLDEN CRISPY CHICKEN MEALS (Restaurant ID: 3)
-- =====================================================

INSERT INTO meals (restaurant_id, name, description, price, category, image, availability_status, detailed_ingredients, created_at) VALUES
(3, 'Original Fried Chicken', '4 pieces of our signature golden fried chicken with secret spice blend', 11.99, 'Chicken', '/placeholder.svg?height=300&width=400', 'Available', 'Chicken pieces (4), secret spice coating, vegetable oil. Contains: Gluten, Dairy, Eggs. Allergens: Cooked in shared fryer with shellfish.', NOW()),
(3, 'Spicy Wings Bucket', '12 buffalo-style spicy wings with ranch dressing', 13.99, 'Chicken', '/placeholder.svg?height=300&width=400', 'Available', 'Chicken wings (12), buffalo sauce, ranch dressing, celery sticks. Contains: Dairy, Eggs. Allergens: Contains hot pepper extract.', NOW()),
(3, 'Chicken Tenders Meal', '6 crispy chicken tenders with choice of 2 dipping sauces', 10.99, 'Chicken', '/placeholder.svg?height=300&width=400', 'Available', 'Chicken breast tenders (6), panko breading, choice of honey mustard/BBQ/ranch sauce. Contains: Gluten, Dairy, Eggs, Soy.', NOW()),
(3, 'Family Feast Box', '12 pieces of mixed chicken, large fries, coleslaw, and 4 biscuits', 34.99, 'Combo Meals', '/placeholder.svg?height=300&width=400', 'Available', 'Mixed chicken pieces (12), french fries, coleslaw, buttermilk biscuits (4). Contains: Gluten, Dairy, Eggs. May contain soy and sesame.', NOW()),
(3, 'Buttermilk Biscuits', '4 warm, fluffy buttermilk biscuits with honey butter', 5.99, 'Sides', '/placeholder.svg?height=300&width=400', 'Available', 'Flour, buttermilk, butter, baking powder, honey butter. Contains: Gluten, Dairy. May contain traces of eggs.', NOW());

-- CASA DE TACOS MEALS (Restaurant ID: 4)
-- =====================================================

INSERT INTO meals (restaurant_id, name, description, price, category, image, availability_status, detailed_ingredients, created_at) VALUES
(4, 'Carne Asada Tacos', '3 authentic street tacos with grilled steak, onions, cilantro, and lime', 12.99, 'Tacos', '/placeholder.svg?height=300&width=400', 'Available', 'Grilled beef, corn tortillas (handmade), white onions, cilantro, lime, salsa verde. Contains: None of the major allergens. Gluten-free corn tortillas.', NOW()),
(4, 'Al Pastor Tacos', '3 tacos with marinated pork, pineapple, and chipotle sauce', 11.99, 'Tacos', '/placeholder.svg?height=300&width=400', 'Available', 'Marinated pork, grilled pineapple, corn tortillas, onions, cilantro, chipotle sauce. Contains: None of the major allergens. May contain traces of soy.', NOW()),
(4, 'Baja Fish Tacos', '3 crispy fish tacos with cabbage slaw and creamy lime sauce', 13.99, 'Tacos', '/placeholder.svg?height=300&width=400', 'Available', 'Battered white fish, cabbage slaw, lime crema, pico de gallo, corn tortillas. Contains: Fish, Gluten, Dairy, Eggs. May contain shellfish.', NOW()),
(4, 'Loaded Nachos Supreme', 'Crispy tortilla chips loaded with cheese, beans, jalapeños, guacamole, and sour cream', 10.99, 'Appetizers', '/placeholder.svg?height=300&width=400', 'Available', 'Corn tortilla chips, cheese sauce, refried beans, jalapeños, guacamole, sour cream, pico de gallo. Contains: Dairy. Gluten-free chips.', NOW()),
(4, 'Churros with Chocolate', '5 cinnamon-sugar churros served with rich chocolate dipping sauce', 6.99, 'Desserts', '/placeholder.svg?height=300&width=400', 'Available', 'Churro dough, cinnamon sugar coating, chocolate sauce. Contains: Gluten, Dairy, Eggs. May contain traces of nuts.', NOW());

-- NAPOLI PIZZA KITCHEN MEALS (Restaurant ID: 5)
-- =====================================================

INSERT INTO meals (restaurant_id, name, description, price, category, image, availability_status, detailed_ingredients, created_at) VALUES
(5, 'Margherita Pizza', 'Classic Neapolitan pizza with San Marzano tomatoes, fresh mozzarella, and basil', 14.99, 'Pizza', '/placeholder.svg?height=300&width=400', 'Available', 'Pizza dough, San Marzano tomatoes, buffalo mozzarella, fresh basil, extra virgin olive oil. Contains: Gluten, Dairy. Vegetarian.', NOW()),
(5, 'Pepperoni Deluxe', 'Double pepperoni, mozzarella cheese, and Italian herbs on tomato base', 16.99, 'Pizza', '/placeholder.svg?height=300&width=400', 'Available', 'Pizza dough, tomato sauce, mozzarella, double pepperoni, Italian herbs, parmesan. Contains: Gluten, Dairy. Contains pork.', NOW()),
(5, 'Quattro Formaggi', 'Four cheese pizza: mozzarella, gorgonzola, parmesan, and ricotta', 17.99, 'Pizza', '/placeholder.svg?height=300&width=400', 'Available', 'Pizza dough, white sauce base, mozzarella, gorgonzola, parmesan, ricotta, honey drizzle. Contains: Gluten, Dairy. Vegetarian.', NOW()),
(5, 'Prosciutto e Rucola', 'Thin crust pizza with prosciutto, arugula, cherry tomatoes, and parmesan shavings', 18.99, 'Pizza', '/placeholder.svg?height=300&width=400', 'Available', 'Pizza dough, tomato sauce, mozzarella, prosciutto, fresh arugula, cherry tomatoes, parmesan, balsamic glaze. Contains: Gluten, Dairy. Contains pork.', NOW()),
(5, 'Tiramisu', 'Authentic Italian tiramisu with mascarpone, espresso, and cocoa', 7.99, 'Desserts', '/placeholder.svg?height=300&width=400', 'Available', 'Ladyfinger biscuits, mascarpone cheese, espresso, cocoa powder, eggs, marsala wine. Contains: Gluten, Dairy, Eggs. Contains alcohol.', NOW());

-- =====================================================
-- INITIALIZATION COMPLETE
-- =====================================================
-- Summary:
-- - Purged all existing data
-- - Created 5 approved and open restaurants
-- - Created 25 available meals (5 per restaurant)
-- - Configured 4 delivery pricing tiers
-- - All restaurants and meals have high-quality images
-- - All meals include detailed ingredient information
-- =====================================================
