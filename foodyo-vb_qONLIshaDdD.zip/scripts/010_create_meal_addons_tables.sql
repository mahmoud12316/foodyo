-- Create meal_addons table
CREATE TABLE IF NOT EXISTS meal_addons (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
  partner_id INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create meal_addon_assignments junction table (many-to-many relationship)
CREATE TABLE IF NOT EXISTS meal_addon_assignments (
  meal_id INTEGER NOT NULL,
  addon_id INTEGER NOT NULL,
  PRIMARY KEY (meal_id, addon_id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_meal_addons_partner_id ON meal_addons(partner_id);
CREATE INDEX IF NOT EXISTS idx_meal_addon_assignments_meal_id ON meal_addon_assignments(meal_id);
CREATE INDEX IF NOT EXISTS idx_meal_addon_assignments_addon_id ON meal_addon_assignments(addon_id);

-- Insert sample add-ons for testing
INSERT INTO meal_addons (name, price, partner_id) VALUES
  ('Extra Cheese', 1.50, 1),
  ('Avocado', 2.00, 1),
  ('Extra Sauce', 0.50, 1),
  ('Bacon', 2.50, 1),
  ('Grilled Onions', 1.00, 1);
