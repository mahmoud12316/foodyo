-- Create the drivers table for delivery driver management
CREATE TABLE IF NOT EXISTS drivers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  vehicle_type VARCHAR(100) NOT NULL,
  license_plate VARCHAR(100) NOT NULL,
  is_available BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_drivers_email ON drivers(email);
CREATE INDEX IF NOT EXISTS idx_drivers_phone ON drivers(phone);
CREATE INDEX IF NOT EXISTS idx_drivers_is_available ON drivers(is_available);

-- Add a comment
COMMENT ON TABLE drivers IS 'Stores delivery driver registration and availability data';
COMMENT ON COLUMN drivers.is_available IS 'Admin-controlled availability status for driver activation';
