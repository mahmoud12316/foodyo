-- Create delivery_pricing table for distance-based delivery fees
CREATE TABLE IF NOT EXISTS delivery_pricing (
  id SERIAL PRIMARY KEY,
  distance_max DECIMAL(10, 2) NOT NULL, -- Maximum distance in kilometers
  delivery_fee DECIMAL(10, 2) NOT NULL, -- Fee charged for this distance range
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add unique constraint on distance_max to prevent duplicates
CREATE UNIQUE INDEX IF NOT EXISTS idx_delivery_pricing_distance ON delivery_pricing(distance_max);

-- Insert default pricing tiers
INSERT INTO delivery_pricing (distance_max, delivery_fee) VALUES
  (3.0, 5.00),
  (7.0, 8.00),
  (15.0, 12.00),
  (999.0, 20.00)
ON CONFLICT DO NOTHING;

-- Add comment
COMMENT ON TABLE delivery_pricing IS 'Stores distance-based delivery fee tiers';
