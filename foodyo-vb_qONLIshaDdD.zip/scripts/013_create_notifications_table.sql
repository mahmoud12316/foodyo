-- Create notifications table for storing all system notifications
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_type VARCHAR(20) NOT NULL CHECK (recipient_type IN ('customer', 'driver', 'partner', 'admin', 'all_customers', 'all_drivers')),
  recipient_id UUID, -- NULL for broadcast messages
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  notification_type VARCHAR(50) NOT NULL CHECK (notification_type IN ('order_accepted', 'order_preparing', 'order_ready', 'order_assigned', 'order_out_for_delivery', 'order_delivered', 'broadcast', 'system')),
  order_id UUID, -- Reference to related order if applicable
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  read_at TIMESTAMP
);

-- Create indexes for efficient queries
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_type, recipient_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_order_id ON notifications(order_id);

-- Add comment
COMMENT ON TABLE notifications IS 'Stores all system notifications for customers, drivers, partners, and admins';
