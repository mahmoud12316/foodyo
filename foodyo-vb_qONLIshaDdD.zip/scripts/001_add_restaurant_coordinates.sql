-- Add latitude and longitude columns to restaurants table
-- This migration adds geographic coordinates support for restaurant locations

ALTER TABLE restaurants 
ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8),
ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8);

-- Add a comment to describe the columns
COMMENT ON COLUMN restaurants.latitude IS 'Restaurant latitude coordinate (-90 to 90)';
COMMENT ON COLUMN restaurants.longitude IS 'Restaurant longitude coordinate (-180 to 180)';

-- Optional: Add a check constraint to ensure valid coordinate ranges
ALTER TABLE restaurants 
ADD CONSTRAINT valid_latitude CHECK (latitude >= -90 AND latitude <= 90),
ADD CONSTRAINT valid_longitude CHECK (longitude >= -180 AND longitude <= 180);
