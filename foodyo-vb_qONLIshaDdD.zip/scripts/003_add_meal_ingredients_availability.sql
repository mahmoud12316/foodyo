-- Add detailed ingredients/allergens and availability status to meals table

-- Create meals table if it doesn't exist
CREATE TABLE IF NOT EXISTS meals (
  id SERIAL PRIMARY KEY,
  partner_id INTEGER NOT NULL,
  restaurant_name TEXT NOT NULL,
  meal_name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  category TEXT,
  image_url TEXT,
  detailed_ingredients TEXT,
  availability_status TEXT DEFAULT 'Available' CHECK (availability_status IN ('Available', 'Sold Out')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add columns to existing meals table if they don't exist
DO $$ 
BEGIN
  -- Add detailed_ingredients column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'meals' AND column_name = 'detailed_ingredients'
  ) THEN
    ALTER TABLE meals ADD COLUMN detailed_ingredients TEXT;
  END IF;

  -- Add availability_status column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'meals' AND column_name = 'availability_status'
  ) THEN
    ALTER TABLE meals ADD COLUMN availability_status TEXT DEFAULT 'Available' CHECK (availability_status IN ('Available', 'Sold Out'));
  END IF;
END $$;

-- Update existing meals to have default availability status
UPDATE meals 
SET availability_status = 'Available' 
WHERE availability_status IS NULL;
