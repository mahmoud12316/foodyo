-- =====================================================
-- CRITICAL DATA PURGE - DELETE ALL EXISTING DATA
-- =====================================================

-- Disable foreign key checks to allow clean deletion
SET session_replication_role = 'replica';

-- Delete all existing data from all tables
DELETE FROM order_items;
DELETE FROM orders;
DELETE FROM favorites;
DELETE FROM saved_locations;
DELETE FROM meal_addons_assignment;
DELETE FROM meal_addons;
DELETE FROM meals;
DELETE FROM restaurants;
DELETE FROM partners;
DELETE FROM drivers;
DELETE FROM notifications;
DELETE FROM delivery_pricing;

-- Re-enable foreign key checks
SET session_replication_role = 'origin';

-- =====================================================
-- DELIVERY PRICING CONFIGURATION
-- =====================================================

INSERT INTO delivery_pricing (distance_max_km, delivery_fee, created_at) VALUES
(3.0, 2.50, NOW()),
(7.0, 4.50, NOW()),
(15.0, 7.00, NOW()),
(999.0, 12.00, NOW());

-- =====================================================
-- RESTAURANT PARTNERS CREATION (5 SPECIFIC RESTAURANTS)
-- =====================================================

INSERT INTO partners (id, name, email, password, restaurant_name, is_partner_approved, created_at) VALUES
(1, 'John Smith', 'hamburger@restaurant.com', '$2a$10$encrypted_password_hash', 'Hamburger Restaurant', TRUE, NOW()),
(2, 'Yuki Tanaka', 'sushi@restaurant.com', '$2a$10$encrypted_password_hash', 'Sushi Restaurant', TRUE, NOW()),
(3, 'Mike Johnson', 'chicken@restaurant.com', '$2a$10$encrypted_password_hash', 'Crispy Chicken Restaurant', TRUE, NOW()),
(4, 'Carlos Rodriguez', 'taco@restaurant.com', '$2a$10$encrypted_password_hash', 'Taco Restaurant', TRUE, NOW()),
(5, 'Marco Rossi', 'pizza@restaurant.com', '$2a$10$encrypted_password_hash', 'Pizza Restaurant', TRUE, NOW());

-- =====================================================
-- RESTAURANTS CREATION (5 SPECIFIC RESTAURANTS)
-- All set to APPROVED and OPEN
-- =====================================================

INSERT INTO restaurants (id, name, description, image_url, category, address, latitude, longitude, is_partner_approved, is_open, created_at) VALUES
(1, 'Hamburger Restaurant', 'Premium burgers made with 100% fresh beef, artisan buns, and gourmet toppings. Experience burger perfection.', '/placeholder.svg?height=400&width=600', 'American', '123 Burger Lane, Downtown', 31.9539, 35.9106, TRUE, TRUE, NOW()),
(2, 'Sushi Restaurant', 'Authentic Japanese sushi crafted by master chefs using the freshest fish and traditional techniques.', '/placeholder.svg?height=400&width=600', 'Japanese', '456 Sushi Street, East District', 31.9639, 35.9206, TRUE, TRUE, NOW()),
(3, 'Crispy Chicken Restaurant', 'Golden, crispy fried chicken with secret spice blends. Comfort food at its finest.', '/placeholder.svg?height=400&width=600', 'American', '789 Chicken Road, West Side', 31.9439, 35.9006, TRUE, TRUE, NOW()),
(4, 'Taco Restaurant', 'Authentic Mexican tacos with fresh ingredients, homemade salsas, and traditional flavors.', '/placeholder.svg?height=400&width=600', 'Mexican', '321 Taco Avenue, South Quarter', 31.9339, 35.8906, TRUE, TRUE, NOW()),
(5, 'Pizza Restaurant', 'Wood-fired Neapolitan pizzas with imported Italian ingredients and artisan dough.', '/placeholder.svg?height=400&width=600', 'Italian', '654 Pizza Boulevard, North End', 31.9739, 35.9306, TRUE, TRUE, NOW());

-- =====================================================
-- MEALS CREATION (25 TOTAL - 5 PER RESTAURANT)
-- All set to AVAILABLE
-- =====================================================

-- HAMBURGER RESTAURANT MEALS (5)
INSERT INTO meals (restaurant_id, name, description, price, image_url, category, detailed_ingredients, availability_status, created_at) VALUES
(1, 'Classic Cheeseburger', 'Juicy beef patty, melted cheddar cheese, lettuce, tomato, pickles, special sauce on a toasted bun', 8.99, '/placeholder.svg?height=300&width=400', 'Burgers', 'Beef patty (beef, salt, pepper), cheddar cheese (milk), lettuce, tomato, pickles, brioche bun (wheat, eggs), special sauce (mayo, mustard, ketchup). ALLERGENS: Wheat, Dairy, Eggs, Mustard', 'Available', NOW()),
(1, 'Bacon BBQ Burger', 'Double beef patty, crispy bacon, onion rings, BBQ sauce, and smoky cheddar on a pretzel bun', 12.99, '/placeholder.svg?height=300&width=400', 'Burgers', 'Double beef patty, bacon (pork), onion rings (wheat, eggs), cheddar cheese (milk), BBQ sauce (tomatoes, molasses), pretzel bun (wheat). ALLERGENS: Wheat, Dairy, Eggs, Pork', 'Available', NOW()),
(1, 'Mushroom Swiss Burger', 'Premium beef, sautéed mushrooms, Swiss cheese, caramelized onions, and truffle aioli', 11.49, '/placeholder.svg?height=300&width=400', 'Burgers', 'Beef patty, mushrooms, Swiss cheese (milk), caramelized onions, truffle aioli (eggs, truffle oil), artisan bun (wheat). ALLERGENS: Wheat, Dairy, Eggs', 'Available', NOW()),
(1, 'Spicy Jalapeño Burger', 'Beef patty with pepper jack cheese, jalapeños, chipotle mayo, and crispy onions', 10.49, '/placeholder.svg?height=300&width=400', 'Burgers', 'Beef patty, pepper jack cheese (milk), jalapeños, chipotle mayo (eggs, peppers), crispy onions (wheat), bun (wheat). ALLERGENS: Wheat, Dairy, Eggs, Spicy', 'Available', NOW()),
(1, 'Veggie Deluxe Burger', 'Plant-based patty, avocado, arugula, roasted red peppers, and herb mayo on whole wheat', 9.99, '/placeholder.svg?height=300&width=400', 'Burgers', 'Plant-based patty (soy, wheat), avocado, arugula, roasted peppers, herb mayo (eggs, herbs), whole wheat bun (wheat). ALLERGENS: Wheat, Soy, Eggs', 'Available', NOW()),

-- SUSHI RESTAURANT MEALS (5)
(2, 'Salmon Nigiri Set', 'Fresh Atlantic salmon nigiri (8 pieces) with wasabi and pickled ginger', 14.99, '/placeholder.svg?height=300&width=400', 'Sushi', 'Atlantic salmon (fish), sushi rice (rice, rice vinegar, sugar), nori seaweed, wasabi, pickled ginger. ALLERGENS: Fish, May contain traces of shellfish', 'Available', NOW()),
(2, 'California Roll', 'Crab stick, avocado, cucumber, and sesame seeds wrapped in seaweed and rice', 10.99, '/placeholder.svg?height=300&width=400', 'Sushi', 'Crab stick (fish, crab), avocado, cucumber, sushi rice (rice), nori seaweed, sesame seeds, mayo (eggs). ALLERGENS: Fish, Shellfish, Eggs, Sesame', 'Available', NOW()),
(2, 'Spicy Tuna Roll', 'Fresh tuna mixed with spicy mayo, cucumber, and scallions, topped with masago', 13.49, '/placeholder.svg?height=300&width=400', 'Sushi', 'Fresh tuna (fish), spicy mayo (eggs, chili), cucumber, scallions, masago (fish roe), sushi rice (rice), nori. ALLERGENS: Fish, Eggs, Spicy', 'Available', NOW()),
(2, 'Dragon Roll', 'Shrimp tempura, avocado, topped with eel, eel sauce, and sesame seeds', 16.99, '/placeholder.svg?height=300&width=400', 'Sushi', 'Shrimp tempura (shrimp, wheat flour), avocado, eel (fish), eel sauce (soy, mirin), sesame seeds, sushi rice. ALLERGENS: Shellfish, Fish, Wheat, Soy, Sesame, Eggs', 'Available', NOW()),
(2, 'Sashimi Platter', 'Assorted fresh fish slices: salmon, tuna, yellowtail (15 pieces) with soy sauce and wasabi', 22.99, '/placeholder.svg?height=300&width=400', 'Sushi', 'Fresh salmon, tuna, yellowtail (all fish), soy sauce (soy, wheat), wasabi, pickled ginger. ALLERGENS: Fish, Soy, Wheat', 'Available', NOW()),

-- CRISPY CHICKEN RESTAURANT MEALS (5)
(3, 'Classic Fried Chicken', '4 pieces of golden crispy fried chicken with secret spice blend', 11.99, '/placeholder.svg?height=300&width=400', 'Chicken', 'Chicken (chicken meat), coating (wheat flour, corn starch, spices, salt, pepper), vegetable oil. ALLERGENS: Wheat, May contain traces of soy', 'Available', NOW()),
(3, 'Spicy Buffalo Wings', '10 chicken wings tossed in spicy buffalo sauce with ranch dipping sauce', 13.99, '/placeholder.svg?height=300&width=400', 'Chicken', 'Chicken wings, buffalo sauce (hot sauce, butter), ranch dressing (milk, eggs, herbs), celery sticks. ALLERGENS: Dairy, Eggs, Spicy', 'Available', NOW()),
(3, 'Chicken Tenders Basket', '6 crispy chicken tenders with choice of honey mustard, BBQ, or ranch sauce', 10.49, '/placeholder.svg?height=300&width=400', 'Chicken', 'Chicken breast strips, coating (wheat flour, breadcrumbs), dipping sauces (eggs, mustard). ALLERGENS: Wheat, Eggs, Mustard', 'Available', NOW()),
(3, 'Nashville Hot Chicken', 'Extra spicy fried chicken sandwich with pickles and coleslaw on brioche', 12.49, '/placeholder.svg?height=300&width=400', 'Chicken', 'Fried chicken breast, Nashville hot sauce (cayenne, butter), pickles, coleslaw (cabbage, mayo), brioche bun (wheat, eggs). ALLERGENS: Wheat, Dairy, Eggs, Very Spicy', 'Available', NOW()),
(3, 'Chicken & Waffles', 'Crispy fried chicken served on Belgian waffles with maple syrup', 14.99, '/placeholder.svg?height=300&width=400', 'Chicken', 'Fried chicken, Belgian waffles (wheat flour, eggs, milk, butter), maple syrup. ALLERGENS: Wheat, Dairy, Eggs', 'Available', NOW()),

-- TACO RESTAURANT MEALS (5)
(4, 'Carne Asada Tacos', 'Three grilled steak tacos with onions, cilantro, and lime on corn tortillas', 11.99, '/placeholder.svg?height=300&width=400', 'Tacos', 'Grilled beef, corn tortillas (corn), onions, cilantro, lime, salsa verde (tomatillos, peppers). ALLERGENS: None (Gluten-free option)', 'Available', NOW()),
(4, 'Fish Tacos', 'Crispy battered fish, cabbage slaw, pico de gallo, and chipotle mayo in flour tortillas', 12.99, '/placeholder.svg?height=300&width=400', 'Tacos', 'Battered fish (fish, wheat flour), cabbage slaw, pico de gallo (tomatoes, onions, peppers), chipotle mayo (eggs), flour tortillas (wheat). ALLERGENS: Fish, Wheat, Eggs', 'Available', NOW()),
(4, 'Al Pastor Tacos', 'Marinated pork with pineapple, onions, and cilantro on soft corn tortillas', 10.99, '/placeholder.svg?height=300&width=400', 'Tacos', 'Marinated pork, pineapple, corn tortillas (corn), onions, cilantro, salsa roja. ALLERGENS: Pork', 'Available', NOW()),
(4, 'Veggie Black Bean Tacos', 'Seasoned black beans, avocado, lettuce, cheese, and salsa fresca', 9.49, '/placeholder.svg?height=300&width=400', 'Tacos', 'Black beans, avocado, lettuce, cheese (milk), salsa fresca, corn tortillas (corn), sour cream (milk). ALLERGENS: Dairy', 'Available', NOW()),
(4, 'Taco Platter Combo', 'Mix of 6 tacos: 2 carne asada, 2 chicken, 2 carnitas with rice and beans', 18.99, '/placeholder.svg?height=300&width=400', 'Tacos', 'Mixed meats (beef, chicken, pork), corn tortillas, Mexican rice, refried beans, salsa, guacamole. ALLERGENS: Dairy (in beans)', 'Available', NOW()),

-- PIZZA RESTAURANT MEALS (5)
(5, 'Margherita Pizza', 'San Marzano tomato sauce, fresh mozzarella, basil, and extra virgin olive oil', 13.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough (wheat flour, yeast), San Marzano tomato sauce, fresh mozzarella (milk), basil, olive oil. ALLERGENS: Wheat, Dairy', 'Available', NOW()),
(5, 'Pepperoni Pizza', 'Tomato sauce, mozzarella, and premium pepperoni on thin crust', 14.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough (wheat), tomato sauce, mozzarella (milk), pepperoni (pork, beef, spices). ALLERGENS: Wheat, Dairy, Pork', 'Available', NOW()),
(5, 'Quattro Formaggi', 'Four cheese pizza: mozzarella, gorgonzola, parmesan, and ricotta', 15.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough (wheat), mozzarella, gorgonzola, parmesan, ricotta (all dairy). ALLERGENS: Wheat, Dairy', 'Available', NOW()),
(5, 'Prosciutto e Rucola', 'Tomato sauce, mozzarella, prosciutto, arugula, and parmesan shavings', 17.99, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough (wheat), tomato sauce, mozzarella (milk), prosciutto (pork), arugula, parmesan (milk). ALLERGENS: Wheat, Dairy, Pork', 'Available', NOW()),
(5, 'Vegetarian Supreme', 'Tomato sauce, mozzarella, mushrooms, bell peppers, olives, onions, and tomatoes', 14.49, '/placeholder.svg?height=300&width=400', 'Pizza', 'Pizza dough (wheat), tomato sauce, mozzarella (milk), mushrooms, bell peppers, olives, onions, fresh tomatoes. ALLERGENS: Wheat, Dairy', 'Available', NOW());

-- =====================================================
-- FINAL CONFIRMATION MESSAGE
-- =====================================================

DO $$
BEGIN
  RAISE NOTICE '✓ Database purged successfully';
  RAISE NOTICE '✓ 5 restaurants created and approved';
  RAISE NOTICE '✓ 25 meals created (5 per restaurant)';
  RAISE NOTICE '✓ All restaurants set to OPEN status';
  RAISE NOTICE '✓ All meals set to AVAILABLE status';
  RAISE NOTICE '✓ Delivery pricing configured with 4 tiers';
  RAISE NOTICE '✓ System ready for launch!';
END $$;
