-- Add is_open column to restaurants table
-- This allows restaurant partners to control when they are accepting orders

ALTER TABLE restaurants 
ADD COLUMN IF NOT EXISTS is_open BOOLEAN DEFAULT TRUE;

-- Add comment for documentation
COMMENT ON COLUMN restaurants.is_open IS 'Indicates whether the restaurant is currently open and accepting orders';

-- Create index for faster filtering of open restaurants
CREATE INDEX IF NOT EXISTS idx_restaurants_is_open ON restaurants(is_open);

-- Update existing restaurants to be open by default
UPDATE restaurants 
SET is_open = TRUE 
WHERE is_open IS NULL;
